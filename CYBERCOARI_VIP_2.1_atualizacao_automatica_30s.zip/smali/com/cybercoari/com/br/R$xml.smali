.class public final Lcom/cybercoari/com/br/R$xml;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final advanced_settings_preference:I = 0x7f120000

.field public static final app_preferences:I = 0x7f120001

.field public static final network_security_config:I = 0x7f120002

.field public static final sshtunnel_preferences:I = 0x7f120003


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
