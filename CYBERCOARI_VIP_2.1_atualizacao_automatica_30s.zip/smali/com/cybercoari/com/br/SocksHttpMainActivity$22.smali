.class Lcom/cybercoari/com/br/SocksHttpMainActivity$22;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;
.field private final a:Lcom/cybercoari/com/br/SocksHttpMainActivity;
.method public constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0
    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$22;->a:Lcom/cybercoari/com/br/SocksHttpMainActivity;
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method
.method public run()V
    .locals 1
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$22;->a:Lcom/cybercoari/com/br/SocksHttpMainActivity;
    invoke-direct {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->runAutoConfigCheck()V
    return-void
.end method
