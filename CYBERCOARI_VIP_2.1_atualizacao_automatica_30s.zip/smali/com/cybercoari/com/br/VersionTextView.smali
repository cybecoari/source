.class public Lcom/cybercoari/com/br/VersionTextView;
.super Landroid/widget/TextView;
.source "VersionTextView.java"


# instance fields
.field private mContext:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/cybercoari/com/br/VersionTextView;->mContext:Landroid/content/Context;

    invoke-direct {p0}, Lcom/cybercoari/com/br/VersionTextView;->loadAndFetch()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    iput-object p1, p0, Lcom/cybercoari/com/br/VersionTextView;->mContext:Landroid/content/Context;

    invoke-direct {p0}, Lcom/cybercoari/com/br/VersionTextView;->loadAndFetch()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    iput-object p1, p0, Lcom/cybercoari/com/br/VersionTextView;->mContext:Landroid/content/Context;

    invoke-direct {p0}, Lcom/cybercoari/com/br/VersionTextView;->loadAndFetch()V

    return-void
.end method

.method static synthetic access$000(Lcom/cybercoari/com/br/VersionTextView;)Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/VersionTextView;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method private loadAndFetch()V
    .locals 5

    :try_start_0
    iget-object v0, p0, Lcom/cybercoari/com/br/VersionTextView;->mContext:Landroid/content/Context;

    const-string v1, "version_display"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "Version"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_0

    invoke-direct {p0, v0}, Lcom/cybercoari/com/br/VersionTextView;->setVersionDisplay(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    const-string v0, " "

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/VersionTextView;->setText(Ljava/lang/CharSequence;)V

    :goto_0
    new-instance v0, Lcom/cybercoari/com/br/VersionTextView$FetchTask;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/VersionTextView$FetchTask;-><init>(Lcom/cybercoari/com/br/VersionTextView;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    const-string v1, " "

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/VersionTextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private setVersionDisplay(Ljava/lang/String;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/VersionTextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
