.class public final Lcom/cybercoari/com/br/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f0f0000

.field public static final abc_action_bar_up_description:I = 0x7f0f0001

.field public static final abc_action_menu_overflow_description:I = 0x7f0f0002

.field public static final abc_action_mode_done:I = 0x7f0f0003

.field public static final abc_activity_chooser_view_see_all:I = 0x7f0f0004

.field public static final abc_activitychooserview_choose_application:I = 0x7f0f0005

.field public static final abc_capital_off:I = 0x7f0f0006

.field public static final abc_capital_on:I = 0x7f0f0007

.field public static final abc_font_family_body_1_material:I = 0x7f0f0008

.field public static final abc_font_family_body_2_material:I = 0x7f0f0009

.field public static final abc_font_family_button_material:I = 0x7f0f000a

.field public static final abc_font_family_caption_material:I = 0x7f0f000b

.field public static final abc_font_family_display_1_material:I = 0x7f0f000c

.field public static final abc_font_family_display_2_material:I = 0x7f0f000d

.field public static final abc_font_family_display_3_material:I = 0x7f0f000e

.field public static final abc_font_family_display_4_material:I = 0x7f0f000f

.field public static final abc_font_family_headline_material:I = 0x7f0f0010

.field public static final abc_font_family_menu_material:I = 0x7f0f0011

.field public static final abc_font_family_subhead_material:I = 0x7f0f0012

.field public static final abc_font_family_title_material:I = 0x7f0f0013

.field public static final abc_menu_alt_shortcut_label:I = 0x7f0f0014

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f0f0015

.field public static final abc_menu_delete_shortcut_label:I = 0x7f0f0016

.field public static final abc_menu_enter_shortcut_label:I = 0x7f0f0017

.field public static final abc_menu_function_shortcut_label:I = 0x7f0f0018

.field public static final abc_menu_meta_shortcut_label:I = 0x7f0f0019

.field public static final abc_menu_shift_shortcut_label:I = 0x7f0f001a

.field public static final abc_menu_space_shortcut_label:I = 0x7f0f001b

.field public static final abc_menu_sym_shortcut_label:I = 0x7f0f001c

.field public static final abc_prepend_shortcut_label:I = 0x7f0f001d

.field public static final abc_search_hint:I = 0x7f0f001e

.field public static final abc_searchview_description_clear:I = 0x7f0f001f

.field public static final abc_searchview_description_query:I = 0x7f0f0020

.field public static final abc_searchview_description_search:I = 0x7f0f0021

.field public static final abc_searchview_description_submit:I = 0x7f0f0022

.field public static final abc_searchview_description_voice:I = 0x7f0f0023

.field public static final abc_shareactionprovider_share_with:I = 0x7f0f0024

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f0f0025

.field public static final abc_toolbar_collapse_description:I = 0x7f0f0026

.field public static final about:I = 0x7f0f0027

.field public static final actived:I = 0x7f0f0028

.field public static final alert_block_settings:I = 0x7f0f0029

.field public static final alert_clear_settings:I = 0x7f0f002a

.field public static final alert_delete_file:I = 0x7f0f002b

.field public static final alert_exit:I = 0x7f0f002c

.field public static final alert_update_app:I = 0x7f0f002d

.field public static final app_description:I = 0x7f0f002e

.field public static final app_mobile_info:I = 0x7f0f002f

.field public static final app_name:I = 0x7f0f0030

.field public static final appbar_scrolling_view_behavior:I = 0x7f0f0031

.field public static final atencao:I = 0x7f0f0032

.field public static final attention:I = 0x7f0f0033

.field public static final auth_message:I = 0x7f0f0034

.field public static final auth_username:I = 0x7f0f0035

.field public static final authenticating:I = 0x7f0f0036

.field public static final authfailed:I = 0x7f0f0037

.field public static final blocked:I = 0x7f0f0038

.field public static final bottom_sheet_behavior:I = 0x7f0f0039

.field public static final cancel:I = 0x7f0f003a

.field public static final category_advanced_settings:I = 0x7f0f003b

.field public static final category_filter_apps:I = 0x7f0f003c

.field public static final category_forward_dns:I = 0x7f0f003d

.field public static final category_forward_port:I = 0x7f0f003e

.field public static final category_forward_udp:I = 0x7f0f003f

.field public static final category_prompt:I = 0x7f0f0040

.field public static final category_settings_adicionais:I = 0x7f0f0041

.field public static final category_tunnel:I = 0x7f0f0042

.field public static final category_user_interface:I = 0x7f0f0043

.field public static final channel_description_background:I = 0x7f0f0044

.field public static final channel_description_status:I = 0x7f0f0045

.field public static final channel_description_userreq:I = 0x7f0f0046

.field public static final channel_name_background:I = 0x7f0f0047

.field public static final channel_name_status:I = 0x7f0f0048

.field public static final channel_name_userreq:I = 0x7f0f0049

.field public static final character_counter_content_description:I = 0x7f0f004a

.field public static final character_counter_pattern:I = 0x7f0f004b

.field public static final check_block_root:I = 0x7f0f004c

.field public static final check_date_valid:I = 0x7f0f004d

.field public static final check_protect:I = 0x7f0f004e

.field public static final check_show_login_start:I = 0x7f0f004f

.field public static final clear_logs:I = 0x7f0f0050

.field public static final clear_settings:I = 0x7f0f0051

.field public static final close:I = 0x7f0f0052

.field public static final config:I = 0x7f0f0053

.field public static final confirm:I = 0x7f0f0054

.field public static final connected:I = 0x7f0f0055

.field public static final connecting:I = 0x7f0f0056

.field public static final dialog_cancel:I = 0x7f0f0057

.field public static final dialog_default_title:I = 0x7f0f0058

.field public static final dialog_message_dns_primary:I = 0x7f0f0059

.field public static final dialog_ok:I = 0x7f0f005a

.field public static final dir_home_name:I = 0x7f0f005b

.field public static final dir_name:I = 0x7f0f005c

.field public static final disabled:I = 0x7f0f005d

.field public static final disconnected:I = 0x7f0f005e

.field public static final dns_1:I = 0x7f0f005f

.field public static final dns_1_summary:I = 0x7f0f0060

.field public static final dns_2:I = 0x7f0f0061

.field public static final dns_2_summary:I = 0x7f0f0062

.field public static final error_date_selected_invalid:I = 0x7f0f0063

.field public static final error_delete_file:I = 0x7f0f0064

.field public static final error_empty_name_file:I = 0x7f0f0065

.field public static final error_empty_payload:I = 0x7f0f0066

.field public static final error_empty_settings:I = 0x7f0f0067

.field public static final error_export_settings:I = 0x7f0f0068

.field public static final error_file_config_incompatible:I = 0x7f0f0069

.field public static final error_file_invalid:I = 0x7f0f006a

.field public static final error_file_not_found:I = 0x7f0f006b

.field public static final error_file_settings_invalid:I = 0x7f0f006c

.field public static final error_internet_off:I = 0x7f0f006d

.field public static final error_invalid_settings:I = 0x7f0f006e

.field public static final error_no_supported:I = 0x7f0f006f

.field public static final error_permission_writer_required:I = 0x7f0f0070

.field public static final error_proxy_invalid:I = 0x7f0f0071

.field public static final error_request_permission:I = 0x7f0f0072

.field public static final error_root_detected:I = 0x7f0f0073

.field public static final error_save_settings:I = 0x7f0f0074

.field public static final error_server_ip_invalid:I = 0x7f0f0075

.field public static final error_settings_blocked:I = 0x7f0f0076

.field public static final error_settings_expired:I = 0x7f0f0077

.field public static final error_tunnel_service_execution:I = 0x7f0f0078

.field public static final error_userpass_empty:I = 0x7f0f0079

.field public static final error_vpn_sniffer_detected:I = 0x7f0f007a

.field public static final exit:I = 0x7f0f007b

.field public static final expand_button_title:I = 0x7f0f007c

.field public static final expired:I = 0x7f0f007d

.field public static final export_button:I = 0x7f0f007e

.field public static final fab_transformation_scrim_behavior:I = 0x7f0f007f

.field public static final fab_transformation_sheet_behavior:I = 0x7f0f0080

.field public static final feedback:I = 0x7f0f0081

.field public static final first_start_msg:I = 0x7f0f0082

.field public static final hide_bottom_view_on_scroll_behavior:I = 0x7f0f0083

.field public static final importing_settings:I = 0x7f0f0084

.field public static final input_note_msg:I = 0x7f0f0085

.field public static final jsocks_version:I = 0x7f0f0086

.field public static final log_conection_lost:I = 0x7f0f0087

.field public static final log_server_banner:I = 0x7f0f0088

.field public static final log_settings_valid:I = 0x7f0f0089

.field public static final message_permission_request:I = 0x7f0f008a

.field public static final method_connection:I = 0x7f0f008b

.field public static final minimize:I = 0x7f0f008c

.field public static final mobile_info:I = 0x7f0f008d

.field public static final more:I = 0x7f0f008e

.field public static final msg:I = 0x7f0f008f

.field public static final mtrl_chip_close_icon_content_description:I = 0x7f0f0090

.field public static final name_file:I = 0x7f0f0091

.field public static final network_mobile:I = 0x7f0f0092

.field public static final no:I = 0x7f0f0093

.field public static final no_value:I = 0x7f0f0094

.field public static final no_vpn_support_image:I = 0x7f0f0095

.field public static final nonetwork:I = 0x7f0f0096

.field public static final nought_alwayson_warning:I = 0x7f0f0097

.field public static final ok:I = 0x7f0f0098

.field public static final open:I = 0x7f0f0099

.field public static final open_with:I = 0x7f0f009a

.field public static final password:I = 0x7f0f009b

.field public static final password_toggle_content_description:I = 0x7f0f009c

.field public static final path_password_eye:I = 0x7f0f009d

.field public static final path_password_eye_mask_strike_through:I = 0x7f0f009e

.field public static final path_password_eye_mask_visible:I = 0x7f0f009f

.field public static final path_password_strike_through:I = 0x7f0f00a0

.field public static final payload:I = 0x7f0f00a1

.field public static final payload_details:I = 0x7f0f00a2

.field public static final payload_details_msg:I = 0x7f0f00a3

.field public static final project_home:I = 0x7f0f00a4

.field public static final project_urls:I = 0x7f0f00a5

.field public static final proxy_auth:I = 0x7f0f00a6

.field public static final proxy_ip:I = 0x7f0f00a7

.field public static final proxy_pass:I = 0x7f0f00a8

.field public static final proxy_port:I = 0x7f0f00a9

.field public static final proxy_remote:I = 0x7f0f00aa

.field public static final proxy_user:I = 0x7f0f00ab

.field public static final rate_app:I = 0x7f0f00ac

.field public static final reconnect:I = 0x7f0f00ad

.field public static final save:I = 0x7f0f00ae

.field public static final save_password:I = 0x7f0f00af

.field public static final search_menu_title:I = 0x7f0f00b0

.field public static final select_file_setting:I = 0x7f0f00b1

.field public static final servicestop:I = 0x7f0f00b2

.field public static final settings:I = 0x7f0f00b3

.field public static final settings_ImportExport:I = 0x7f0f00b4

.field public static final settings_export:I = 0x7f0f00b5

.field public static final settings_import:I = 0x7f0f00b6

.field public static final settings_ssh:I = 0x7f0f00b7

.field public static final show_license:I = 0x7f0f00b8

.field public static final show_password:I = 0x7f0f00b9

.field public static final sni:I = 0x7f0f00ba

.field public static final ssh_port:I = 0x7f0f00bb

.field public static final ssh_porta_local:I = 0x7f0f00bc

.field public static final ssh_server:I = 0x7f0f00bd

.field public static final start:I = 0x7f0f00be

.field public static final starting_service_ssh:I = 0x7f0f00bf

.field public static final state_add_routes:I = 0x7f0f00c0

.field public static final state_assign_ip:I = 0x7f0f00c1

.field public static final state_auntenticado:I = 0x7f0f00c2

.field public static final state_auth:I = 0x7f0f00c3

.field public static final state_auth_failed:I = 0x7f0f00c4

.field public static final state_auth_pending:I = 0x7f0f00c5

.field public static final state_auth_success:I = 0x7f0f00c6

.field public static final state_connected:I = 0x7f0f00c7

.field public static final state_connecting:I = 0x7f0f00c8

.field public static final state_disconnected:I = 0x7f0f00c9

.field public static final state_get_config:I = 0x7f0f00ca

.field public static final state_nonetwork:I = 0x7f0f00cb

.field public static final state_noprocess:I = 0x7f0f00cc

.field public static final state_proxy_inject:I = 0x7f0f00cd

.field public static final state_proxy_running:I = 0x7f0f00ce

.field public static final state_reconnecting:I = 0x7f0f00cf

.field public static final state_resolve:I = 0x7f0f00d0

.field public static final state_starting:I = 0x7f0f00d1

.field public static final state_stopping:I = 0x7f0f00d2

.field public static final state_tcp_connect:I = 0x7f0f00d3

.field public static final state_user_vpn_password:I = 0x7f0f00d4

.field public static final state_user_vpn_password_cancelled:I = 0x7f0f00d5

.field public static final state_user_vpn_permission:I = 0x7f0f00d6

.field public static final state_user_vpn_permission_cancelled:I = 0x7f0f00d7

.field public static final state_wait:I = 0x7f0f00d8

.field public static final state_waitconnectretry:I = 0x7f0f00d9

.field public static final status_bar_notification_info_overflow:I = 0x7f0f00da

.field public static final stop:I = 0x7f0f00db

.field public static final stopping_service_ssh:I = 0x7f0f00dc

.field public static final success_clear_settings:I = 0x7f0f00dd

.field public static final success_export_settings:I = 0x7f0f00de

.field public static final success_import_settings:I = 0x7f0f00df

.field public static final summary_apps_list:I = 0x7f0f00e0

.field public static final summary_auto_clear_log:I = 0x7f0f00e1

.field public static final summary_autopinger:I = 0x7f0f00e2

.field public static final summary_bypass_modo:I = 0x7f0f00e3

.field public static final summary_collapsed_preference_list:I = 0x7f0f00e4

.field public static final summary_disable_delay_ssh:I = 0x7f0f00e5

.field public static final summary_dns_primary:I = 0x7f0f00e6

.field public static final summary_forward_dns:I = 0x7f0f00e7

.field public static final summary_forward_udp:I = 0x7f0f00e8

.field public static final summary_hide_log:I = 0x7f0f00e9

.field public static final summary_mode_debug:I = 0x7f0f00ea

.field public static final summary_number_max_threads:I = 0x7f0f00eb

.field public static final summary_resolver_udp:I = 0x7f0f00ec

.field public static final summary_speedmeter:I = 0x7f0f00ed

.field public static final summary_sshcompres:I = 0x7f0f00ee

.field public static final summary_tethering_subnet:I = 0x7f0f00ef

.field public static final summary_tlsversion:I = 0x7f0f00f0

.field public static final summary_wakelock_service:I = 0x7f0f00f1

.field public static final third_party_software:I = 0x7f0f00f2

.field public static final title_agradecimento_especial:I = 0x7f0f00f3

.field public static final title_apps_list:I = 0x7f0f00f4

.field public static final title_auth:I = 0x7f0f00f5

.field public static final title_auto_clear_log:I = 0x7f0f00f6

.field public static final title_autopinger:I = 0x7f0f00f7

.field public static final title_bypass_mode:I = 0x7f0f00f8

.field public static final title_delete_file:I = 0x7f0f00f9

.field public static final title_disable_delay_ssh:I = 0x7f0f00fa

.field public static final title_dns_primary:I = 0x7f0f00fb

.field public static final title_extra:I = 0x7f0f00fc

.field public static final title_filter_apps:I = 0x7f0f00fd

.field public static final title_forward_dns:I = 0x7f0f00fe

.field public static final title_forward_udp:I = 0x7f0f00ff

.field public static final title_hide_log:I = 0x7f0f0100

.field public static final title_language:I = 0x7f0f0101

.field public static final title_login_main:I = 0x7f0f0102

.field public static final title_mode_debug:I = 0x7f0f0103

.field public static final title_mode_night:I = 0x7f0f0104

.field public static final title_number_max_threads:I = 0x7f0f0105

.field public static final title_permission_request:I = 0x7f0f0106

.field public static final title_ping_time:I = 0x7f0f0107

.field public static final title_resolver_udp:I = 0x7f0f0108

.field public static final title_security:I = 0x7f0f0109

.field public static final title_speedmeter:I = 0x7f0f010a

.field public static final title_sshcompres:I = 0x7f0f010b

.field public static final title_tethering_subnet:I = 0x7f0f010c

.field public static final title_tlsversion:I = 0x7f0f010d

.field public static final title_wakelock_service:I = 0x7f0f010e

.field public static final trileadssh2_version:I = 0x7f0f010f

.field public static final unknown_state:I = 0x7f0f0110

.field public static final v7_preference_off:I = 0x7f0f0111

.field public static final v7_preference_on:I = 0x7f0f0112

.field public static final wait:I = 0x7f0f0113

.field public static final wizard_details:I = 0x7f0f0114

.field public static final wizard_details_msg:I = 0x7f0f0115

.field public static final yes:I = 0x7f0f0116


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
