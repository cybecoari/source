.class Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1$1;->this$2:Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1$1;->this$2:Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;->this$1:Lcom/cybercoari/com/br/SocksHttpMainActivity$18;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$1700(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;

    move-result-object v0

    const-string v1, "<strong><font color=\"red\">Usu\u00e1rio n\u00e3o encontrado no banco de dados!</strong>"

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1$1;->this$2:Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;->this$1:Lcom/cybercoari/com/br/SocksHttpMainActivity$18;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$1800(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1$1;->this$2:Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18$1;->this$1:Lcom/cybercoari/com/br/SocksHttpMainActivity$18;

    iget-object v0, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$18;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$1900(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
