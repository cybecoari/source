.class Lcom/cybercoari/com/br/SocksHttpMainActivity$9;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateState(Ljava/lang/String;Ljava/lang/String;ILcom/romzkie/ultrasshservice/logger/ConnectionStatus;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$9;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$9;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$1200(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$9;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f080064

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method
