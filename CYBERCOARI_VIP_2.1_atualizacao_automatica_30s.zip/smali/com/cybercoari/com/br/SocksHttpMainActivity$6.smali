.class Lcom/cybercoari/com/br/SocksHttpMainActivity$6;
.super Ljava/lang/Object;

# interfaces
.implements Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/SocksHttpMainActivity;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$6;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Lcn/pedant/SweetAlert/widget/SweetAlertDialog;)V
    .locals 2

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$6;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$100(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcom/cybercoari/com/br/util/ConfigUtil;

    move-result-object p1

    invoke-virtual {p1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getUrlContato()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Landroid/content/Intent;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 p1, 0x10000000

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$6;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    const v1, 0x7f0f009a

    invoke-virtual {p1, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
