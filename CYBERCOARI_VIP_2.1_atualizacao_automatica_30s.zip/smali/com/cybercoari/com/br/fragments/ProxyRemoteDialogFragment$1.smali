.class Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;->onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 0

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;

    invoke-static {p1, p2}, Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;->access$002(Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;Z)Z

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;

    invoke-static {p1, p2}, Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;->access$100(Lcom/cybercoari/com/br/fragments/ProxyRemoteDialogFragment;Z)V

    return-void
.end method
