.class Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$2;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$2;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->dismiss()V

    return-void
.end method
