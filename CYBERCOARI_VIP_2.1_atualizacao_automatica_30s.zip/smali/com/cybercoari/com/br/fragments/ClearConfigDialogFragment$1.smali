.class Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/romzkie/ultrasshservice/config/Settings;->clearSettings(Landroid/content/Context;)V

    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->clearLog()V

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateMainViews(Landroid/content/Context;)V

    iget-object p1, p0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment$1;->this$0:Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p1

    const p2, 0x7f0f00dd

    const/4 v0, 0x0

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method
