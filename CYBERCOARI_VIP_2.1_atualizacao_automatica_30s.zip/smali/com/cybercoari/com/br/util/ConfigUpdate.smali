.class public Lcom/cybercoari/com/br/util/ConfigUpdate;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private config:Lcom/cybercoari/com/br/util/ConfigUtil;

.field private context:Landroid/content/Context;

.field private isOnCreate:Z

.field private listener:Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;

.field private pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

.field private progressDialog:Landroid/app/ProgressDialog;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;)V
    .locals 0

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p1, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->context:Landroid/content/Context;

    iput-object p2, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->listener:Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    new-instance p1, Lcom/cybercoari/com/br/util/ConfigUtil;

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->context:Landroid/content/Context;

    invoke-direct {p1, v0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getUrlUpdate()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const-string v1, "GET"

    invoke-virtual {p1, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->connect()V

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    invoke-direct {v2, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Error on getting data: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    iget-boolean v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->isOnCreate:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->dismiss()V

    :cond_0
    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->listener:Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;

    if-eqz v0, :cond_1

    invoke-interface {v0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;->onUpdateListener(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method protected onPreExecute()V
    .locals 3

    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    iget-boolean v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->isOnCreate:Z

    if-nez v0, :cond_0

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v1, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->context:Landroid/content/Context;

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->getProgressHelper()Lcn/pedant/SweetAlert/widget/ProgressHelper;

    move-result-object v0

    const-string v1, "#A5DC86"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/ProgressHelper;->setBarColor(I)V

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Verificando Atualiza\u00e7\u00e3o"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Carregando."

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelable(Z)V

    iget-object v0, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    :cond_0
    return-void
.end method

.method public start(Z)V
    .locals 0

    iput-boolean p1, p0, Lcom/cybercoari/com/br/util/ConfigUpdate;->isOnCreate:Z

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
