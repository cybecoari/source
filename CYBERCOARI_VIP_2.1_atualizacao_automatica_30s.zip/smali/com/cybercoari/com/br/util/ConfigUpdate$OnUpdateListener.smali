.class public interface abstract Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/util/ConfigUpdate;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnUpdateListener"
.end annotation


# virtual methods
.method public abstract onUpdateListener(Ljava/lang/String;)V
.end method
