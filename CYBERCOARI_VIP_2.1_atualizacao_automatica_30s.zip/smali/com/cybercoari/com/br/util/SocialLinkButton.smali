.class public Lcom/cybercoari/com/br/util/SocialLinkButton;
.super Landroid/widget/Button;

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->init()V

    return-void
.end method

.method private fallbackUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "Zap"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v0, "https://wa.me/5597984189502"

    return-object v0

    :cond_0
    const-string v0, "Pix"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, "https://cybercoari.com.br/vpn/pix.php"

    return-object v0

    :cond_1
    const-string v0, "Tele"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v0, "https://t.me/cybercoaribr"

    return-object v0

    :cond_2
    const-string v0, "YouTube"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const-string v0, "https://m.youtube.com/"

    return-object v0

    :cond_3
    const-string v0, "Insta"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    const-string v0, "https://m.instagram.com/"

    return-object v0

    :cond_4
    const-string v0, "https://m.facebook.com/"

    return-object v0
.end method

.method private init()V
    .locals 0

    invoke-virtual {p0, p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    invoke-virtual {p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Lcom/cybercoari/com/br/util/SocialLinkButton;->getTag()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_1

    check-cast v1, Ljava/lang/String;

    new-instance v2, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v2, v0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getSocialLink(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_0

    goto :goto_0

    :cond_0
    invoke-direct {p0, v1}, Lcom/cybercoari/com/br/util/SocialLinkButton;->fallbackUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_0
    if-eqz v2, :cond_1

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-direct {v2, v3, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v2, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_1
    return-void
.end method
