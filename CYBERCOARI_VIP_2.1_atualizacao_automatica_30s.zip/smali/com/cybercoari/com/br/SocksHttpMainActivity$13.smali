.class Lcom/cybercoari/com/br/SocksHttpMainActivity$13;
.super Ljava/lang/Object;

# interfaces
.implements Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/SocksHttpMainActivity;->onBackPressed()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$13;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Lcn/pedant/SweetAlert/widget/SweetAlertDialog;)V
    .locals 0

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$13;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-static {p1}, Lcom/cybercoari/com/br/util/Utils;->exitAll(Landroid/app/Activity;)V

    return-void
.end method
