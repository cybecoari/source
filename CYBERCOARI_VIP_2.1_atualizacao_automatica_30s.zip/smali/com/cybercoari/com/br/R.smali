.class public final Lcom/cybercoari/com/br/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cybercoari/com/br/R$anim;,
        Lcom/cybercoari/com/br/R$animator;,
        Lcom/cybercoari/com/br/R$array;,
        Lcom/cybercoari/com/br/R$attr;,
        Lcom/cybercoari/com/br/R$bool;,
        Lcom/cybercoari/com/br/R$color;,
        Lcom/cybercoari/com/br/R$dimen;,
        Lcom/cybercoari/com/br/R$drawable;,
        Lcom/cybercoari/com/br/R$id;,
        Lcom/cybercoari/com/br/R$integer;,
        Lcom/cybercoari/com/br/R$interpolator;,
        Lcom/cybercoari/com/br/R$layout;,
        Lcom/cybercoari/com/br/R$menu;,
        Lcom/cybercoari/com/br/R$raw;,
        Lcom/cybercoari/com/br/R$string;,
        Lcom/cybercoari/com/br/R$style;,
        Lcom/cybercoari/com/br/R$styleable;,
        Lcom/cybercoari/com/br/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
