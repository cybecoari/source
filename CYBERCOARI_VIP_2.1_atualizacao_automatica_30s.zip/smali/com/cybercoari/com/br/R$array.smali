.class public final Lcom/cybercoari/com/br/R$array;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "array"
.end annotation


# static fields
.field public static final pref_idioma_option_labels:I = 0x7f030000

.field public static final pref_idioma_option_values:I = 0x7f030001

.field public static final pref_maxThreads_option_labels:I = 0x7f030002

.field public static final pref_maxThreads_option_values:I = 0x7f030003

.field public static final pref_modoNoturno_option_labels:I = 0x7f030004

.field public static final pref_modoNoturno_option_values:I = 0x7f030005


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
