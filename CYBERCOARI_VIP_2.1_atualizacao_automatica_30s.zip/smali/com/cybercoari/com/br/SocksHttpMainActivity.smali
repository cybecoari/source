.class public Lcom/cybercoari/com/br/SocksHttpMainActivity;
.super Lcom/cybercoari/com/br/activities/BaseActivity;

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;
.implements Lcom/romzkie/ultrasshservice/logger/SkStatus$StateListener;
.implements Lcom/cybercoari/com/br/PayloadGenerator$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/cybercoari/com/br/SocksHttpMainActivity$OneSocks;,
        Lcom/cybercoari/com/br/SocksHttpMainActivity$MyAdapter;,
        Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;
    }
.end annotation


# static fields
.field public static final OPEN_LOGS:Ljava/lang/String; = "com.cybercoari.com.br:openLogs"

.field private static final TAG:Ljava/lang/String; = "SocksHttpMainActivity"

.field private static final UPDATE_VIEWS:Ljava/lang/String; = "MainUpdate"

.field private static final tabTitle:[Ljava/lang/String;


# instance fields
.field private LinearCheck:Landroid/widget/LinearLayout;

.field private Vencimento:Landroid/widget/TextView;

.field private btn_att:Landroid/widget/ImageView;

.field private btn_config:Landroid/widget/ImageView;

.field private config:Lcom/cybercoari/com/br/util/ConfigUtil;

.field private configMsgLayout:Landroid/widget/LinearLayout;

.field private configMsgText:Landroid/widget/TextView;

.field countryNames:[Ljava/lang/String;

.field private customPayloadSwitch:Landroidx/appcompat/widget/SwitchCompat;

.field private dialog:Landroidx/appcompat/app/AlertDialog;

.field private dias_check:Landroid/widget/TextView;

.field private idAtual:I

.field private inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

.field private inputPwShowPass:Landroid/widget/ImageButton;

.field private inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

.field private isMostrarSenha:Z

.field private logList:Landroidx/recyclerview/widget/RecyclerView;

.field private loginLayout:Landroid/widget/LinearLayout;

.field private mActivityReceiver:Landroid/content/BroadcastReceiver;

.field private mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

.field private mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

.field private mHandler:Landroid/os/Handler;

.field private mHandler2:Landroid/os/Handler;

.field private mLogAdapter:Lcom/cybercoari/com/br/adapter/LogsAdapter;

.field private mRunnable:Ljava/lang/Runnable;

.field private mainLayout:Landroid/widget/LinearLayout;

.field private makefat:[Ljava/lang/String;

.field private metodoConexaoRadio:Landroid/widget/RadioGroup;

.field private pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

.field private payloadAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

.field private payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

.field private payloadLayout:Landroid/widget/LinearLayout;

.field private payloadList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field private payloadSpinner:Landroid/widget/Spinner;

.field private proxyInputLayout:Landroid/widget/LinearLayout;

.field private proxyText:Landroid/widget/TextView;

.field private reloadIU:Landroid/widget/ImageView;

.field private serverAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

.field private serverList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field private serverSpinner:Landroid/widget/Spinner;

.field private sslEdit:Lcom/google/android/material/textfield/TextInputEditText;

.field private ssl_layout:Landroid/widget/LinearLayout;

.field private starterButton:Landroid/widget/Button;

.field private status:Landroid/widget/TextView;

.field private tabs:Lcom/google/android/material/tabs/TabLayout;

.field private toolbar_main:Landroidx/appcompat/widget/Toolbar;

.field private typenetwork:Z

.field private udpList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field private user_limite:Landroid/widget/TextView;

.field private vp:Landroidx/viewpager/widget/ViewPager;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "INICIO"

    const-string v1, "REGISTRO"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabTitle:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 16

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Lcom/cybercoari/com/br/activities/BaseActivity;-><init>()V

    const-string v1, "Custom Payload"

    const-string v2, "Custom SNI"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->countryNames:[Ljava/lang/String;

    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler2:Landroid/os/Handler;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->isMostrarSenha:Z

    new-instance v2, Lcom/cybercoari/com/br/SocksHttpMainActivity$11;

    invoke-direct {v2, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$11;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    iput-object v2, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mActivityReceiver:Landroid/content/BroadcastReceiver;

    const/16 v2, 0x34

    new-array v2, v2, [Ljava/lang/String;

    new-instance v3, Ljava/lang/String;

    const/16 v4, 0x1b

    new-array v5, v4, [B

    fill-array-data v5, :array_0

    invoke-direct {v3, v5}, Ljava/lang/String;-><init>([B)V

    aput-object v3, v2, v1

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0x20

    new-array v5, v3, [B

    fill-array-data v5, :array_1

    invoke-direct {v1, v5}, Ljava/lang/String;-><init>([B)V

    const/4 v5, 0x1

    aput-object v1, v2, v5

    new-instance v1, Ljava/lang/String;

    new-array v5, v4, [B

    fill-array-data v5, :array_2

    invoke-direct {v1, v5}, Ljava/lang/String;-><init>([B)V

    const/4 v5, 0x2

    aput-object v1, v2, v5

    new-instance v1, Ljava/lang/String;

    const/16 v5, 0x15

    new-array v6, v5, [B

    fill-array-data v6, :array_3

    invoke-direct {v1, v6}, Ljava/lang/String;-><init>([B)V

    const/4 v6, 0x3

    aput-object v1, v2, v6

    new-instance v1, Ljava/lang/String;

    const/16 v6, 0x10

    new-array v7, v6, [B

    fill-array-data v7, :array_4

    invoke-direct {v1, v7}, Ljava/lang/String;-><init>([B)V

    const/4 v7, 0x4

    aput-object v1, v2, v7

    new-instance v1, Ljava/lang/String;

    const/16 v7, 0x19

    new-array v8, v7, [B

    fill-array-data v8, :array_5

    invoke-direct {v1, v8}, Ljava/lang/String;-><init>([B)V

    const/4 v8, 0x5

    aput-object v1, v2, v8

    new-instance v1, Ljava/lang/String;

    new-array v8, v7, [B

    fill-array-data v8, :array_6

    invoke-direct {v1, v8}, Ljava/lang/String;-><init>([B)V

    const/4 v8, 0x6

    aput-object v1, v2, v8

    new-instance v1, Ljava/lang/String;

    const/16 v8, 0x18

    new-array v9, v8, [B

    fill-array-data v9, :array_7

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/4 v9, 0x7

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    const/16 v10, 0x13

    new-array v11, v10, [B

    fill-array-data v11, :array_8

    invoke-direct {v1, v11}, Ljava/lang/String;-><init>([B)V

    const/16 v11, 0x8

    aput-object v1, v2, v11

    new-instance v1, Ljava/lang/String;

    const/16 v11, 0x17

    new-array v12, v11, [B

    fill-array-data v12, :array_9

    invoke-direct {v1, v12}, Ljava/lang/String;-><init>([B)V

    const/16 v12, 0x9

    aput-object v1, v2, v12

    new-instance v1, Ljava/lang/String;

    new-array v12, v5, [B

    fill-array-data v12, :array_a

    invoke-direct {v1, v12}, Ljava/lang/String;-><init>([B)V

    const/16 v12, 0xa

    aput-object v1, v2, v12

    new-instance v1, Ljava/lang/String;

    new-array v9, v9, [B

    fill-array-data v9, :array_b

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/16 v9, 0xb

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    new-array v9, v9, [B

    fill-array-data v9, :array_c

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/16 v9, 0xc

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    const/16 v12, 0x1e

    new-array v13, v12, [B

    fill-array-data v13, :array_d

    invoke-direct {v1, v13}, Ljava/lang/String;-><init>([B)V

    const/16 v13, 0xd

    aput-object v1, v2, v13

    new-instance v1, Ljava/lang/String;

    const/16 v14, 0x1d

    new-array v15, v14, [B

    fill-array-data v15, :array_e

    invoke-direct {v1, v15}, Ljava/lang/String;-><init>([B)V

    const/16 v15, 0xe

    aput-object v1, v2, v15

    new-instance v1, Ljava/lang/String;

    const/16 v15, 0x22

    new-array v9, v15, [B

    fill-array-data v9, :array_f

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/16 v9, 0xf

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    new-array v9, v5, [B

    fill-array-data v9, :array_10

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v6

    new-instance v1, Ljava/lang/String;

    new-array v9, v8, [B

    fill-array-data v9, :array_11

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/16 v9, 0x11

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    new-array v9, v13, [B

    fill-array-data v9, :array_12

    invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V

    const/16 v9, 0x12

    aput-object v1, v2, v9

    new-instance v1, Ljava/lang/String;

    new-array v6, v7, [B

    fill-array-data v6, :array_13

    invoke-direct {v1, v6}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v10

    new-instance v1, Ljava/lang/String;

    new-array v6, v7, [B

    fill-array-data v6, :array_14

    invoke-direct {v1, v6}, Ljava/lang/String;-><init>([B)V

    const/16 v6, 0x14

    aput-object v1, v2, v6

    new-instance v1, Ljava/lang/String;

    const/16 v15, 0x1c

    new-array v3, v15, [B

    fill-array-data v3, :array_15

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v5

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0x27

    new-array v5, v3, [B

    fill-array-data v5, :array_16

    invoke-direct {v1, v5}, Ljava/lang/String;-><init>([B)V

    const/16 v5, 0x16

    aput-object v1, v2, v5

    new-instance v1, Ljava/lang/String;

    new-array v3, v15, [B

    fill-array-data v3, :array_17

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v11

    new-instance v1, Ljava/lang/String;

    new-array v3, v7, [B

    fill-array-data v3, :array_18

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v8

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_19

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v7

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_1a

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x1a

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v8, v13, [B

    fill-array-data v8, :array_1b

    invoke-direct {v1, v8}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v4

    new-instance v1, Ljava/lang/String;

    new-array v8, v9, [B

    fill-array-data v8, :array_1c

    invoke-direct {v1, v8}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v15

    new-instance v1, Ljava/lang/String;

    new-array v3, v3, [B

    fill-array-data v3, :array_1d

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v14

    new-instance v1, Ljava/lang/String;

    new-array v3, v10, [B

    fill-array-data v3, :array_1e

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    aput-object v1, v2, v12

    new-instance v1, Ljava/lang/String;

    new-array v3, v6, [B

    fill-array-data v3, :array_1f

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x1f

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v6, [B

    fill-array-data v3, :array_20

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x20

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v15, [B

    fill-array-data v3, :array_21

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x21

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v14, [B

    fill-array-data v3, :array_22

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x22

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v5, [B

    fill-array-data v3, :array_23

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x23

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0x10

    new-array v3, v3, [B

    fill-array-data v3, :array_24

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x24

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_25

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x25

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v4, [B

    fill-array-data v3, :array_26

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x26

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_27

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x27

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v6, [B

    fill-array-data v3, :array_28

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x28

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v5, [B

    fill-array-data v3, :array_29

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x29

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v6, [B

    fill-array-data v3, :array_2a

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2a

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v4, [B

    fill-array-data v3, :array_2b

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2b

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0x15

    new-array v4, v3, [B

    fill-array-data v4, :array_2c

    invoke-direct {v1, v4}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2c

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_2d

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2d

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_2e

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2e

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v11, [B

    fill-array-data v3, :array_2f

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x2f

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v7, [B

    fill-array-data v3, :array_30

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x30

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v5, [B

    fill-array-data v3, :array_31

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x31

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    const/16 v3, 0xc

    new-array v3, v3, [B

    fill-array-data v3, :array_32

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x32

    aput-object v1, v2, v3

    new-instance v1, Ljava/lang/String;

    new-array v3, v9, [B

    fill-array-data v3, :array_33

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/16 v3, 0x33

    aput-object v1, v2, v3

    iput-object v2, v0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->makefat:[Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x78t
        0x75t
        0x6et
        0x6ct
        0x65t
        0x69t
        0x2et
        0x64t
        0x6ft
        0x77t
        0x6et
        0x6ct
        0x6ft
        0x61t
        0x64t
        0x70t
        0x72t
        0x6ft
        0x76t
        0x69t
        0x64t
        0x65t
        0x72t
    .end array-data

    :array_1
    .array-data 1
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x76t
        0x69t
        0x6ct
        0x6ct
        0x61t
        0x6ct
        0x69t
        0x74t
        0x65t
        0x2et
        0x72t
        0x6ft
        0x6dt
        0x72t
        0x65t
        0x76t
        0x69t
        0x65t
        0x77t
        0x65t
        0x72t
        0x2et
        0x63t
        0x6ft
        0x6dt
    .end array-data

    :array_2
    .array-data 1
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x76t
        0x69t
        0x6ct
        0x6ct
        0x61t
        0x2et
        0x72t
        0x6ft
        0x6dt
        0x72t
        0x65t
        0x76t
        0x69t
        0x77t
        0x65t
        0x72t
        0x2et
        0x63t
        0x6ft
        0x6dt
    .end array-data

    :array_3
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x65t
        0x70t
        0x69t
        0x63t
        0x2et
        0x61t
        0x70t
        0x70t
        0x2et
        0x69t
        0x54t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_4
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x75t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x77t
        0x65t
        0x62t
    .end array-data

    :array_5
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x70t
        0x61t
        0x6ft
        0x6ct
        0x6ft
        0x64t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x73t
        0x65t
        0x61t
        0x72t
        0x63t
        0x68t
        0x32t
    .end array-data

    nop

    :array_6
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x69t
        0x74t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x63t
        0x6ct
        0x69t
        0x65t
        0x6et
        0x74t
        0x2et
        0x70t
        0x72t
        0x6ft
    .end array-data

    nop

    :array_7
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x6ft
        0x62t
        0x69t
        0x6ct
        0x69t
        0x74t
        0x79t
        0x66t
        0x6ct
        0x6ft
        0x77t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    :array_8
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x75t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x63t
        0x6ct
        0x69t
        0x65t
        0x6et
        0x74t
    .end array-data

    :array_9
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x75t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x63t
        0x6ct
        0x69t
        0x65t
        0x6et
        0x74t
        0x2et
        0x70t
        0x72t
        0x6ft
    .end array-data

    :array_a
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x69t
        0x74t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x63t
        0x6ct
        0x69t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    :array_c
    .array-data 1
        0x6dt
        0x65t
        0x67t
        0x61t
        0x62t
        0x79t
        0x74t
        0x65t
        0x2et
        0x64t
        0x6dt
    .end array-data

    :array_d
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x66t
        0x67t
        0x72t
        0x6ft
        0x75t
        0x70t
        0x74t
        0x65t
        0x63t
        0x68t
        0x2et
        0x6bt
        0x69t
        0x63t
        0x6bt
        0x61t
        0x73t
        0x73t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x73t
    .end array-data

    nop

    :array_e
    .array-data 1
        0x69t
        0x6et
        0x2et
        0x67t
        0x6ft
        0x70t
        0x61t
        0x6ct
        0x61t
        0x6bt
        0x72t
        0x69t
        0x73t
        0x68t
        0x6et
        0x61t
        0x72t
        0x65t
        0x64t
        0x64t
        0x79t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_f
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6at
        0x72t
        0x75t
        0x6dt
        0x6dt
        0x79t
        0x61t
        0x70t
        0x70t
        0x73t
        0x2et
        0x72t
        0x6ft
        0x6ft
        0x74t
        0x62t
        0x72t
        0x6ft
        0x77t
        0x73t
        0x65t
        0x72t
        0x2et
        0x63t
        0x6ct
        0x61t
        0x73t
        0x73t
        0x69t
        0x63t
    .end array-data

    nop

    :array_10
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x69t
        0x74t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x63t
        0x6ct
        0x69t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_11
    .array-data 1
        0x68t
        0x75t
        0x2et
        0x74t
        0x61t
        0x67t
        0x73t
        0x6ft
        0x66t
        0x74t
        0x2et
        0x74t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x6ct
        0x69t
        0x74t
        0x65t
    .end array-data

    :array_12
    .array-data 1
        0x63t
        0x6ft
        0x2et
        0x77t
        0x65t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_13
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x69t
        0x6et
        0x68t
        0x75t
        0x69t
        0x2et
        0x6et
        0x65t
        0x74t
        0x77t
        0x6ft
        0x72t
        0x6bt
        0x63t
        0x61t
        0x70t
        0x74t
        0x75t
        0x72t
        0x65t
    .end array-data

    nop

    :array_14
    .array-data 1
        0x61t
        0x70t
        0x70t
        0x2et
        0x67t
        0x72t
        0x65t
        0x79t
        0x73t
        0x68t
        0x69t
        0x72t
        0x74t
        0x73t
        0x2et
        0x73t
        0x73t
        0x6ct
        0x63t
        0x61t
        0x70t
        0x74t
        0x75t
        0x72t
        0x65t
    .end array-data

    nop

    :array_15
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x70t
        0x61t
        0x63t
        0x6bt
        0x61t
        0x67t
        0x65t
        0x73t
        0x6et
        0x69t
        0x66t
        0x66t
        0x65t
        0x72t
        0x2et
        0x66t
        0x72t
        0x74t
        0x70t
        0x61t
        0x72t
        0x6ct
        0x61t
        0x6bt
    .end array-data

    :array_16
    .array-data 1
        0x6at
        0x70t
        0x2et
        0x63t
        0x6ft
        0x2et
        0x74t
        0x61t
        0x6ft
        0x73t
        0x6ft
        0x66t
        0x74t
        0x77t
        0x61t
        0x72t
        0x65t
        0x2et
        0x61t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x2et
        0x70t
        0x61t
        0x63t
        0x6bt
        0x65t
        0x74t
        0x63t
        0x61t
        0x70t
        0x74t
        0x75t
        0x72t
        0x65t
    .end array-data

    :array_17
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x65t
        0x6dt
        0x61t
        0x6et
        0x75t
        0x65t
        0x6ct
        0x65t
        0x66t
        0x2et
        0x72t
        0x65t
        0x6dt
        0x6ft
        0x74t
        0x65t
        0x5ft
        0x63t
        0x61t
        0x70t
        0x74t
        0x75t
        0x72t
        0x65t
    .end array-data

    :array_18
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x67t
        0x6ft
        0x6ft
        0x67t
        0x6ct
        0x65t
        0x63t
        0x6ft
        0x64t
        0x65t
        0x2et
        0x6et
        0x65t
        0x74t
        0x77t
        0x6ft
        0x72t
        0x6bt
        0x6ct
        0x6ft
        0x67t
    .end array-data

    nop

    :array_19
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x61t
        0x72t
        0x75t
        0x74t
        0x69t
        0x67t
        0x72t
        0x6ft
        0x75t
        0x70t
        0x2et
        0x64t
        0x6ft
        0x77t
        0x6et
        0x74t
        0x6ft
        0x72t
    .end array-data

    :array_1a
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x69t
        0x6et
        0x68t
        0x75t
        0x69t
        0x2et
        0x77t
        0x69t
        0x66t
        0x69t
        0x61t
        0x6et
        0x61t
        0x6ct
        0x79t
        0x7at
        0x65t
        0x72t
    .end array-data

    :array_1b
    .array-data 1
        0x74t
        0x76t
        0x2et
        0x62t
        0x69t
        0x74t
        0x78t
        0x2et
        0x6dt
        0x65t
        0x64t
        0x69t
        0x61t
    .end array-data

    nop

    :array_1c
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x44t
        0x72t
        0x6ft
        0x69t
        0x44t
        0x6ft
        0x77t
        0x6et
        0x6ct
        0x6ft
        0x61t
        0x64t
        0x65t
        0x72t
    .end array-data

    nop

    :array_1d
    .array-data 1
        0x62t
        0x69t
        0x74t
        0x6bt
        0x69t
        0x6et
        0x67t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x64t
        0x6ft
        0x77t
        0x6et
        0x6ct
        0x6ft
        0x61t
        0x64t
        0x65t
        0x72t
    .end array-data

    nop

    :array_1e
    .array-data 1
        0x6ft
        0x72t
        0x67t
        0x2et
        0x74t
        0x72t
        0x61t
        0x6et
        0x73t
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x2et
        0x6ct
        0x69t
        0x74t
        0x65t
    .end array-data

    :array_1f
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x64t
        0x65t
        0x6ct
        0x70t
        0x68t
        0x69t
        0x63t
        0x6ft
        0x64t
        0x65t
        0x72t
        0x2et
        0x66t
        0x6ct
        0x75t
        0x64t
    .end array-data

    :array_20
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x6ft
        0x62t
        0x69t
        0x6ct
        0x69t
        0x74t
        0x79t
        0x66t
        0x6ct
        0x6ft
        0x77t
        0x2et
        0x74t
        0x76t
        0x70t
    .end array-data

    :array_21
    .array-data 1
        0x68t
        0x75t
        0x2et
        0x62t
        0x75t
        0x74t
        0x65t
        0x2et
        0x64t
        0x61t
        0x61t
        0x69t
        0x2et
        0x61t
        0x6dt
        0x6ft
        0x72t
        0x67t
        0x2et
        0x64t
        0x72t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    :array_22
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x6ft
        0x62t
        0x69t
        0x6ct
        0x69t
        0x74t
        0x79t
        0x66t
        0x6ct
        0x6ft
        0x77t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x70t
        0x72t
        0x6ft
        0x66t
    .end array-data

    nop

    :array_23
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x72t
        0x75t
        0x74t
        0x65t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x6ft
        0x6ct
        0x69t
        0x74t
        0x65t
    .end array-data

    nop

    :array_24
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6et
        0x65t
        0x62t
        0x75t
        0x6ct
        0x61t
        0x2et
        0x73t
        0x77t
        0x69t
        0x66t
        0x74t
    .end array-data

    :array_25
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6dt
        0x61t
        0x72t
        0x75t
        0x74t
        0x69t
        0x67t
        0x72t
        0x6ft
        0x75t
        0x70t
        0x2et
        0x64t
        0x6ft
        0x77t
        0x6et
        0x74t
        0x6ft
        0x72t
    .end array-data

    :array_26
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x41t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x41t
        0x2et
        0x44t
        0x72t
        0x6ft
        0x69t
        0x44t
        0x6ft
        0x77t
        0x6et
        0x6ct
        0x6ft
        0x61t
        0x64t
        0x65t
        0x72t
    .end array-data

    :array_27
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x69t
        0x6et
        0x64t
        0x72t
        0x69t
        0x73t
        0x2et
        0x79t
        0x69t
        0x66t
        0x79t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x73t
    .end array-data

    :array_28
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x64t
        0x65t
        0x6ct
        0x70t
        0x68t
        0x69t
        0x63t
        0x6ft
        0x64t
        0x65t
        0x72t
        0x2et
        0x66t
        0x6ct
        0x75t
        0x64t
    .end array-data

    :array_29
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x6ft
        0x69t
        0x64t
        0x61t
        0x70t
        0x70t
        0x73t
        0x2et
        0x62t
        0x69t
        0x74t
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_2a
    .array-data 1
        0x64t
        0x77t
        0x6ct
        0x65t
        0x65t
        0x65t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x73t
        0x65t
        0x61t
        0x72t
        0x63t
        0x68t
    .end array-data

    :array_2b
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x76t
        0x75t
        0x7at
        0x65t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
        0x2et
        0x64t
        0x6ft
        0x77t
        0x6et
        0x6ct
        0x6ft
        0x61t
        0x64t
        0x65t
        0x72t
    .end array-data

    :array_2c
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x67t
        0x75t
        0x6ft
        0x73t
        0x68t
        0x69t
        0x2et
        0x68t
        0x74t
        0x74t
        0x70t
        0x63t
        0x61t
        0x6et
        0x61t
        0x72t
        0x79t
    .end array-data

    nop

    :array_2d
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x67t
        0x61t
        0x62t
        0x6ft
        0x72t
        0x64t
        0x65t
        0x6dt
        0x6bt
        0x6ft
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x6et
        0x61t
        0x64t
        0x6ft
    .end array-data

    :array_2e
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x66t
        0x72t
        0x6ft
        0x73t
        0x74t
        0x77t
        0x69t
        0x72t
        0x65t
        0x2et
        0x61t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
    .end array-data

    nop

    :array_2f
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x76t
        0x75t
        0x7at
        0x65t
        0x2et
        0x61t
        0x6et
        0x64t
        0x72t
        0x6ft
        0x69t
        0x64t
        0x2et
        0x72t
        0x65t
        0x6dt
        0x6ft
        0x74t
        0x65t
    .end array-data

    :array_30
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x64t
        0x65t
        0x6ct
        0x70t
        0x68t
        0x69t
        0x63t
        0x6ft
        0x64t
        0x65t
        0x72t
        0x2et
        0x66t
        0x6ct
        0x75t
        0x64t
        0x2et
        0x70t
        0x61t
        0x69t
        0x64t
    .end array-data

    nop

    :array_31
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x74t
        0x65t
        0x65t
        0x6ft
        0x6et
        0x73t
        0x6ft
        0x66t
        0x74t
        0x2et
        0x7at
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_32
    .array-data 1
        0x6dt
        0x65t
        0x67t
        0x61t
        0x62t
        0x79t
        0x74t
        0x65t
        0x2et
        0x74t
        0x64t
        0x6dt
    .end array-data

    :array_33
    .array-data 1
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x61t
        0x6bt
        0x69t
        0x6et
        0x67t
        0x69t
        0x2et
        0x74t
        0x6ft
        0x72t
        0x72t
        0x65t
        0x6et
        0x74t
    .end array-data
.end method

.method private AvisoexNotif(ILjava/lang/String;)V
    .locals 5

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    new-instance v1, Landroid/app/Notification$Builder;

    invoke-direct {v1, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".sockshttpmainactivity"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setChannelId(Ljava/lang/String;)Landroid/app/Notification$Builder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->createNotification(Landroid/app/NotificationManager;Ljava/lang/String;)V

    :cond_0
    const-string v2, "Aten\u00e7\u00e3o"

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Restam "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " para o termino da sua internet."

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object p1

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const v2, 0x7f0800a5

    invoke-static {p2, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    move-result-object p1

    const p2, 0x7f08005a

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    const/16 p1, 0x1023

    invoke-virtual {v1}, Landroid/app/Notification$Builder;->getNotification()Landroid/app/Notification;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    return-void
.end method

.method private ExpiradoNotif()V
    .locals 5

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    new-instance v1, Landroid/app/Notification$Builder;

    invoke-direct {v1, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".sockshttpmainactivity"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setChannelId(Ljava/lang/String;)Landroid/app/Notification$Builder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->createNotification(Landroid/app/NotificationManager;Ljava/lang/String;)V

    :cond_0
    const-string v2, "Aten\u00e7\u00e3o"

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const-string v3, "Sua internet est\u00e1 vencida, renove o acesso com seu vendedor."

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0800a5

    invoke-static {v3, v4}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const v3, 0x7f08005a

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    const/16 v2, 0x1022

    invoke-virtual {v1}, Landroid/app/Notification$Builder;->getNotification()Landroid/app/Notification;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    return-void
.end method

.method private LimiteNotif()V
    .locals 5

    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    new-instance v1, Landroid/app/Notification$Builder;

    invoke-direct {v1, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".sockshttpmainactivity"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setChannelId(Ljava/lang/String;)Landroid/app/Notification$Builder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->createNotification(Landroid/app/NotificationManager;Ljava/lang/String;)V

    :cond_0
    new-instance v2, Landroid/app/Notification$BigTextStyle;

    invoke-direct {v2, v1}, Landroid/app/Notification$BigTextStyle;-><init>(Landroid/app/Notification$Builder;)V

    const-string v3, "N\u00e3o permitidos conex\u00f5es multiplas por login, usuarios que compartilham seus dados de login poderam perder acesso por violar nossos termos de uso."

    invoke-virtual {v2, v3}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object v2

    const-string v3, "SEU USUARIO JA EST\u00c1 EM USO!"

    invoke-virtual {v2, v3}, Landroid/app/Notification$BigTextStyle;->setBigContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object v2

    const-string v4, "ADM"

    invoke-virtual {v2, v4}, Landroid/app/Notification$BigTextStyle;->setSummaryText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const-string v3, "N\u00e3o permitidos conex\u00f5es multiplas por login. Usuarios que compartilham seus dados de login poderam perder acesso por violar nossos termos de uso."

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f0800a5

    invoke-static {v3, v4}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    move-result-object v2

    const v3, 0x7f08005c

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    const/16 v2, 0x1024

    invoke-virtual {v1}, Landroid/app/Notification$Builder;->getNotification()Landroid/app/Notification;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    const-string v0, "vibrator"

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Vibrator;

    const-wide/16 v1, 0x7d0

    invoke-virtual {v0, v1, v2}, Landroid/os/Vibrator;->vibrate(J)V

    return-void
.end method

.method private PayloadGenerator()V
    .locals 2

    new-instance v0, Lcom/cybercoari/com/br/PayloadGenerator;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/PayloadGenerator;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p0}, Lcom/cybercoari/com/br/PayloadGenerator;->setDismissListener(Lcom/cybercoari/com/br/PayloadGenerator$OnDismissListener;)V

    new-instance v1, Landroidx/appcompat/app/AlertDialog$Builder;

    invoke-direct {v1, p0}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object v1

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->dialog:Landroidx/appcompat/app/AlertDialog;

    invoke-virtual {v1, v0}, Landroidx/appcompat/app/AlertDialog;->setView(Landroid/view/View;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->dialog:Landroidx/appcompat/app/AlertDialog;

    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private ShowMsgUpdate()V
    .locals 2

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "App Atualizado com sucesso"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Seu aplicativo foi atualizado.\n\nCaso apresente algum bug limpe os dados do aplicativo.\n\n"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Certo"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelable(Z)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$1;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$1;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method static synthetic access$000(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->restart_app()V

    return-void
.end method

.method static synthetic access$100(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcom/cybercoari/com/br/util/ConfigUtil;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    return-object p0
.end method

.method static synthetic access$1000(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcom/google/android/material/textfield/TextInputEditText;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->sslEdit:Lcom/google/android/material/textfield/TextInputEditText;

    return-object p0
.end method

.method static synthetic access$1100(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcom/google/android/material/textfield/TextInputEditText;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

    return-object p0
.end method

.method static synthetic access$1200(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$1300(Lcom/cybercoari/com/br/SocksHttpMainActivity;Z)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateConfig(Z)V

    return-void
.end method

.method static synthetic access$1400(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroidx/viewpager/widget/ViewPager;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->vp:Landroidx/viewpager/widget/ViewPager;

    return-object p0
.end method

.method static synthetic access$1500(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    return-object p0
.end method

.method static synthetic access$1502(Lcom/cybercoari/com/br/SocksHttpMainActivity;Lcn/pedant/SweetAlert/widget/SweetAlertDialog;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    return-object p1
.end method

.method static synthetic access$1600(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/LinearLayout;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->LinearCheck:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static synthetic access$1700(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->Vencimento:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$1800(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->user_limite:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$1900(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->dias_check:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$200(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Lcom/romzkie/ultrasshservice/config/Settings;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    return-object p0
.end method

.method static synthetic access$2000(Lcom/cybercoari/com/br/SocksHttpMainActivity;II)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->alertlimiter(II)V

    return-void
.end method

.method static synthetic access$2100(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->LimiteNotif()V

    return-void
.end method

.method static synthetic access$2200(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->alertdiasexpirado()V

    return-void
.end method

.method static synthetic access$2300(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->ExpiradoNotif()V

    return-void
.end method

.method static synthetic access$2400(Lcom/cybercoari/com/br/SocksHttpMainActivity;ILjava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->AvisoexNotif(ILjava/lang/String;)V

    return-void
.end method

.method static synthetic access$2500(Lcom/cybercoari/com/br/SocksHttpMainActivity;ILjava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->alertdias(ILjava/lang/String;)V

    return-void
.end method

.method static synthetic access$2600(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->checkUser()V

    return-void
.end method

.method static synthetic access$300(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/lang/String;)Z
    .locals 0

    invoke-direct {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->isNewVersion(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$400(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;,
            Ljava/security/GeneralSecurityException;,
            Ljava/security/GeneralSecurityException;
        }
    .end annotation

    invoke-direct {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->newUpdateDialog(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$500(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->noUpdateDialog()V

    return-void
.end method

.method static synthetic access$600(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->errorUpdateDialog(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$700(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doUpdateLayout()V

    return-void
.end method

.method static synthetic access$800(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/Spinner;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    return-object p0
.end method

.method static synthetic access$900(Lcom/cybercoari/com/br/SocksHttpMainActivity;)Landroid/widget/Spinner;
    .locals 0

    iget-object p0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    return-object p0
.end method

.method private alertdias(ILjava/lang/String;)V
    .locals 3

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "ATEN\u00c7\u00c3O!!"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "RESTAM "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " PARA O \nTERMINO DA SUA INTERNET\n\nEVITE FICAR SEM INTERNET \nE RENOVE SEU ACESSO"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string p2, "Certo"

    invoke-virtual {p1, p2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance p2, Lcom/cybercoari/com/br/SocksHttpMainActivity$17;

    invoke-direct {p2, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$17;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p1, p2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method private alertdiasexpirado()V
    .locals 2

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "ATEN\u00c7\u00c3O!!"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "SUA INTERNET ESTA VENCIDA!\n\nPOR FAVOR, CONTATE SEU \nVENDEDOR PARA RENOVAR SEU ACESSO."

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Certo"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$16;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$16;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method private alertlimiter(II)V
    .locals 3

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "ATEN\u00c7\u00c3O!!"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "ESSE USUARIO J\u00c1 ESTA\n EM USO NO MOMENTO.\n\nNUNCA COMPARTILHE SEUS\nDADOS DE LOGIN.\n\n CASO ESSE PROBLEMA\nPERSISTA ENTRE EM CONTATO\nCOM SEU VENDEDOR.\n\nLIMITE: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " | "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string p2, "Certo"

    invoke-virtual {p1, p2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelable(Z)V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance p2, Lcom/cybercoari/com/br/SocksHttpMainActivity$20;

    invoke-direct {p2, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$20;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p1, p2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method private antcrash()V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getCheckUser()Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$19;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$19;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_0
    return-void
.end method

.method private applyAppearanceBackground(Landroid/view/View;II)V
    .locals 3

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v1, v0, Landroid/graphics/drawable/GradientDrawable;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual {v0, p3, p2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method private applyAppearanceIcon(Landroid/view/View;I)V
    .locals 4

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ImageView;

    if-eqz v2, :cond_0

    check-cast v1, Landroid/widget/ImageView;

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    :cond_0
    return-void
.end method

.method private applyOnlineTheme()V
    .locals 6

    :try_start_0
    new-instance v0, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getLogoonline()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_0

    new-instance v2, Lcom/cybercoari/com/br/util/OnlineLogo;

    iget-object v3, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->btn_att:Landroid/widget/ImageView;

    invoke-direct {v2, p0, v3, v1}, Lcom/cybercoari/com/br/util/OnlineLogo;-><init>(Landroid/app/Activity;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/cybercoari/com/br/util/OnlineLogo;->start()V

    :cond_0
    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getLogonline()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_1

    const v2, 0x7f09016a

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    if-eqz v2, :cond_1

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    new-instance v3, Lcom/cybercoari/com/br/util/OnlineLogo;

    invoke-direct {v3, p0, v2, v1}, Lcom/cybercoari/com/br/util/OnlineLogo;-><init>(Landroid/app/Activity;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/cybercoari/com/br/util/OnlineLogo;->start()V

    :cond_1
    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getFundoonline()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_2

    const v2, 0x7f090168

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    new-instance v3, Lcom/cybercoari/com/br/util/OnlineLogo;

    invoke-direct {v3, p0, v2, v1}, Lcom/cybercoari/com/br/util/OnlineLogo;-><init>(Landroid/app/Activity;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/cybercoari/com/br/util/OnlineLogo;->start()V

    :cond_2
    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getRodapeonline()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_3

    const v2, 0x7f090169

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    new-instance v3, Lcom/cybercoari/com/br/util/OnlineLogo;

    invoke-direct {v3, p0, v2, v1}, Lcom/cybercoari/com/br/util/OnlineLogo;-><init>(Landroid/app/Activity;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/cybercoari/com/br/util/OnlineLogo;->start()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    return-void

    :catch_0
    move-exception v0

    return-void
.end method

.method private applyStartButtonAppearance(Landroid/view/View;III)V
    .locals 6

    if-eqz p1, :cond_0

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v1, 0x2

    invoke-virtual {v0, v1, p3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x41a00000    # 20.0f

    mul-float/2addr v3, v2

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    instance-of v4, p1, Landroid/widget/TextView;

    if-eqz v4, :cond_0

    check-cast p1, Landroid/widget/TextView;

    invoke-virtual {p1, p4}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_0
    return-void
.end method

.method private checkNetwork()V
    .locals 4

    :try_start_0
    const-string v0, "connectivity"

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/net/ConnectivityManager;->getNetworkInfo(I)Landroid/net/NetworkInfo;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/net/ConnectivityManager;->getNetworkInfo(I)Landroid/net/NetworkInfo;

    move-result-object v2

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v1

    const v3, 0x7f10019d

    if-eqz v1, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "WIFI: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto/16 :goto_0

    :cond_0
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getExtraInfo()Ljava/lang/String;

    move-result-object v0

    const-string v1, "vivo"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "VIVO: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto/16 :goto_0

    :cond_1
    const-string v1, "claro"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v2, "CLARO: "

    if-eqz v1, :cond_2

    :try_start_1
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto/16 :goto_0

    :cond_2
    const-string v1, "java"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto/16 :goto_0

    :cond_3
    const-string v1, "tim"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "TIM: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto :goto_0

    :cond_4
    const-string v1, "oi"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "OI: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto :goto_0

    :cond_5
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "MOBILE: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/romzkie/ultrasshservice/tunnel/TunnelUtils;->getLocalIpAddress()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V

    goto :goto_0

    :cond_6
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    const-string v1, "SEM CONEX\u00c3O COM A INTERNET"

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/Toolbar;->setSubtitle(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0, p0, v3}, Landroidx/appcompat/widget/Toolbar;->setSubtitleTextAppearance(Landroid/content/Context;I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    return-void
.end method

.method private checkUser()V
    .locals 4

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    const-string v1, "sshUser"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "url"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/cybercoari/com/br/SocksHttpMainActivity$18;

    invoke-direct {v3, p0, v0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$18;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private createNotification(Landroid/app/NotificationManager;Ljava/lang/String;)V
    .locals 3

    new-instance v0, Landroid/app/NotificationChannel;

    const-string v1, "SocksHttpMainActivity Notification"

    const/4 v2, 0x4

    invoke-direct {v0, p2, v1, v2}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const/4 p2, 0x1

    invoke-virtual {v0, p2}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    invoke-virtual {p1, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    return-void
.end method

.method private doLayout()V
    .locals 7

    const v0, 0x7f0c0023

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setContentView(I)V

    new-instance v6, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v6, p0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6}, Lcom/cybercoari/com/br/util/ConfigUtil;->getAppName()Ljava/lang/String;

    move-result-object v6

    const v5, 0x7f090028

    invoke-virtual {p0, v5}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    if-eqz v5, :cond_0

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const v0, 0x7f09014c

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {v1, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->setDrawer(Landroidx/appcompat/widget/Toolbar;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->toolbar_main:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setSupportActionBar(Landroidx/appcompat/widget/Toolbar;)V

    const v0, 0x7f0900cd

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    const v0, 0x7f090030

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mainLayout:Landroid/widget/LinearLayout;

    const v0, 0x7f09002a

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->loginLayout:Landroid/widget/LinearLayout;

    const v0, 0x7f09003c

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->starterButton:Landroid/widget/Button;

    const v0, 0x7f09002c

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    const v0, 0x7f09002b

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    const v0, 0x7f09002f

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwShowPass:Landroid/widget/ImageButton;

    const v0, 0x7f090006

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->LinearCheck:Landroid/widget/LinearLayout;

    const v0, 0x7f090028

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v1}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "usarDefaultPayload"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tunnelType"

    const/4 v5, 0x2

    invoke-interface {v1, v2, v5}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    new-instance v1, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    const v1, 0x7f09010e

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Spinner;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    const v2, 0x7f0900e2

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/Spinner;

    iput-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverList:Ljava/util/ArrayList;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadList:Ljava/util/ArrayList;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->udpList:Ljava/util/ArrayList;

    new-instance v5, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    iget-object v6, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverList:Ljava/util/ArrayList;

    invoke-direct {v5, p0, v1, v6}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    new-instance v1, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    iget-object v5, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadList:Ljava/util/ArrayList;

    invoke-direct {v1, p0, v2, v5}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;-><init>(Landroid/content/Context;ILjava/util/ArrayList;)V

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    const v1, 0x7f0900ee

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->reloadIU:Landroid/widget/ImageView;

    const v1, 0x7f09004d

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->btn_config:Landroid/widget/ImageView;

    const v1, 0x7f09004c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->btn_att:Landroid/widget/ImageView;

    const v1, 0x7f09000a

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->Vencimento:Landroid/widget/TextView;

    const v1, 0x7f090070

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->dias_check:Landroid/widget/TextView;

    const v1, 0x7f0900b6

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->user_limite:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v5, 0x7f080066

    invoke-virtual {v2, v5}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->loadServer()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->loadNetworks()V

    const/4 v1, 0x1

    invoke-direct {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateConfig(Z)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startAutoConfigCheck()V

    const v2, 0x7f090035

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/RadioGroup;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->metodoConexaoRadio:Landroid/widget/RadioGroup;

    const v2, 0x7f090029

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroidx/appcompat/widget/SwitchCompat;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->customPayloadSwitch:Landroidx/appcompat/widget/SwitchCompat;

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->starterButton:Landroid/widget/Button;

    invoke-virtual {v2, p0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f09002e

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadLayout:Landroid/widget/LinearLayout;

    const v2, 0x7f09002d

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

    const v2, 0x7f09003b

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->ssl_layout:Landroid/widget/LinearLayout;

    const v2, 0x7f09003a

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->sslEdit:Lcom/google/android/material/textfield/TextInputEditText;

    const v2, 0x7f090032

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->configMsgLayout:Landroid/widget/LinearLayout;

    const v2, 0x7f090033

    invoke-virtual {p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->configMsgText:Landroid/widget/TextView;

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->customPayloadSwitch:Landroidx/appcompat/widget/SwitchCompat;

    invoke-virtual {v2, v1}, Landroidx/appcompat/widget/SwitchCompat;->setChecked(Z)V

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->metodoConexaoRadio:Landroid/widget/RadioGroup;

    invoke-virtual {v0, p0}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwShowPass:Landroid/widget/ImageButton;

    invoke-virtual {v0, p0}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->reloadIU:Landroid/widget/ImageView;

    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->btn_config:Landroid/widget/ImageView;

    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->btn_att:Landroid/widget/ImageView;

    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doTabs()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setuserpass()V

    return-void
.end method

.method private declared-synchronized doSaveData()V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "USER"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v2}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v2, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "PASS"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v2}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v1, "sshUser"

    iget-object v3, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v3}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_0

    :cond_0
    const-string v3, "sshUser"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, "sshPass"

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_1

    :cond_1
    const-string v1, "sshPass"

    invoke-interface {v2, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_1
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v0

    goto :goto_3

    :catch_0
    move-exception v0

    :try_start_1
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    monitor-exit p0

    return-void

    :goto_3
    monitor-exit p0

    throw v0
.end method

.method private doUpdateLayout()V
    .locals 8

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->isTunnelActive()Z

    move-result v1

    const-string v2, "tunnelType"

    const/4 v3, 0x1

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iget-object v4, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->starterButton:Landroid/widget/Button;

    invoke-virtual {p0, v4, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setStarterButton(Landroid/widget/Button;Landroid/app/Activity;)V

    const v4, 0x7f0f0094

    invoke-virtual {p0, v4}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    const-string v4, "protegerConfig"

    const/4 v5, 0x0

    invoke-interface {v0, v4, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    const-string v6, "proxyRemoto"

    invoke-virtual {v0, v6}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrivString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_1

    new-array v6, v4, [Ljava/lang/Object;

    aput-object v0, v6, v5

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    const-string v7, "proxyRemotoPorta"

    invoke-virtual {v0, v7}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrivString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v6, v3

    const-string v0, "%s:%s"

    invoke-static {v0, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    :cond_1
    :goto_0
    if-eq v2, v3, :cond_4

    if-eq v2, v4, :cond_3

    const/4 v0, 0x3

    if-eq v2, v0, :cond_2

    goto :goto_1

    :cond_2
    const v0, 0x7f090039

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/widget/AppCompatRadioButton;

    invoke-virtual {v0, v3}, Landroidx/appcompat/widget/AppCompatRadioButton;->setChecked(Z)V

    goto :goto_1

    :cond_3
    const v0, 0x7f090038

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/widget/AppCompatRadioButton;

    invoke-virtual {v0, v3}, Landroidx/appcompat/widget/AppCompatRadioButton;->setChecked(Z)V

    goto :goto_1

    :cond_4
    const v0, 0x7f090037

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/widget/AppCompatRadioButton;

    invoke-virtual {v0, v3}, Landroidx/appcompat/widget/AppCompatRadioButton;->setChecked(Z)V

    :goto_1
    const/16 v0, 0x8

    xor-int/2addr v1, v3

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->loginLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->configMsgText:Landroid/widget/TextView;

    const-string v3, ""

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->configMsgLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :goto_2
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->metodoConexaoRadio:Landroid/widget/RadioGroup;

    invoke-virtual {v0}, Landroid/widget/RadioGroup;->getChildCount()I

    move-result v0

    if-ge v5, v0, :cond_5

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->metodoConexaoRadio:Landroid/widget/RadioGroup;

    invoke-virtual {v0, v5}, Landroid/widget/RadioGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_5
    return-void
.end method

.method private errorUpdateDialog(Ljava/lang/String;)V
    .locals 1

    new-instance p1, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    const-string v0, "Erro na atualiza\u00e7\u00e3o"

    invoke-virtual {p1, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    const-string v0, "Ocorreu um erro ao verificar a atualiza\u00e7\u00e3o.\nObserva\u00e7\u00e3o: se o erro persistir, entre em contato com o desenvolvedor para obter mais assist\u00eancia."

    invoke-virtual {p1, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->dismiss()V

    return-void
.end method

.method private getColoredSpanned(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "<font color="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ">"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private isNewVersion(Ljava/lang/String;)Z
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getVersion()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "Version"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1, p1, v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->versionCompare(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Lorg/json/JSONException;->printStackTrace()V

    const/4 p1, 0x0

    return p1
.end method

.method private loadNetworks()V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadList:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;->notifyDataSetChanged()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_1
    return-void
.end method

.method private loadServer()V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v1

    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverList:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverAdapter:Lcom/cybercoari/com/br/adapter/SpinnerAdapter;

    invoke-virtual {v1}, Lcom/cybercoari/com/br/adapter/SpinnerAdapter;->notifyDataSetChanged()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_1
    return-void
.end method

.method private loadServerData()V
    .locals 21

    move-object/from16 v1, p0

    const-string v0, "[app_host]"

    :try_start_0
    iget-object v2, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v2}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    iget-object v4, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    new-instance v5, Lcom/cybercoari/com/br/SocksHttpMainActivity$2;

    invoke-direct {v5, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$2;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v4, v5}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v4, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    new-instance v5, Lcom/cybercoari/com/br/SocksHttpMainActivity$3;

    invoke-direct {v5, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$3;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v4, v5}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v4, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {v4}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v4

    iget-object v5, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {v5}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v5

    iget-object v6, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v6}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v6

    invoke-virtual {v6, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    const-string v7, "ServerIP"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v7, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v7}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v7

    invoke-virtual {v7, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    const-string v8, "ServerPort"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iget-object v8, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v8}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v8

    invoke-virtual {v8, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v8

    const-string v9, "SSLPort"

    invoke-virtual {v8, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v9, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v9}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v9

    invoke-virtual {v9, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const-string v9, "CheckUser"

    invoke-virtual {v4, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v9, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v9}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v9

    invoke-virtual {v9, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    const-string v10, "Payload"

    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    iget-object v10, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v10}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v10

    invoke-virtual {v10, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    const-string v11, "SNI"

    invoke-virtual {v10, v11}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v11}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v11

    invoke-virtual {v11, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    const-string v12, "TlsIP"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget-object v12, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v12}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v12

    invoke-virtual {v12, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v12

    const-string v13, "ProxyIP"

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    iget-object v13, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v13}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v13

    invoke-virtual {v13, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    const-string v14, "ProxyPort"

    invoke-virtual {v13, v14}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    iget-object v14, v1, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v14}, Lcom/cybercoari/com/br/util/ConfigUtil;->getNetworksArray()Lorg/json/JSONArray;

    move-result-object v14

    invoke-virtual {v14, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    const-string v14, "Info"

    invoke-virtual {v5, v14}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_0

    move-object v11, v6

    :cond_0
    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_1

    move-object v10, v6

    :cond_1
    invoke-virtual {v12, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move-object v12, v6

    :cond_2
    const-string v0, "Ssl"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v14, "sslSNI"

    const-string v15, "usarDefaultPayload"

    move-object/from16 v16, v3

    const-string v3, "sshPort"

    move-object/from16 v17, v4

    const-string v4, "tunnelType"

    move-object/from16 v18, v11

    const-string v11, "sshServer"

    if-eqz v0, :cond_3

    :try_start_1
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    move-object/from16 v19, v12

    const/4 v12, 0x1

    invoke-interface {v0, v15, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v12, 0x3

    invoke-interface {v0, v4, v12}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v11, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {v1, v8}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-interface {v0, v3, v12}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v14, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_0

    :cond_3
    move-object/from16 v19, v12

    :goto_0
    const-string v0, "Direct"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const-string v12, "proxyPayload"

    if-eqz v0, :cond_4

    :try_start_2
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v11, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    move-object/from16 v20, v10

    invoke-virtual {v1, v13}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v0, v3, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v12, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v10, 0x1

    invoke-interface {v0, v4, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_1

    :cond_4
    move-object/from16 v20, v10

    :goto_1
    const-string v0, "Proxy"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x0

    if-eqz v0, :cond_5

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v15, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v10, 0x2

    invoke-interface {v0, v4, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v11, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {v1, v7}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-interface {v0, v3, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v7, "proxyRemoto"

    move-object/from16 v10, v19

    invoke-interface {v0, v7, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v7, "proxyRemotoPorta"

    invoke-virtual {v1, v13}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v0, v7, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v12, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_5
    const-string v0, "Tlsws"

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    move-object/from16 v5, v18

    invoke-interface {v0, v11, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {v1, v8}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v0, v3, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v12, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v3, 0x4

    invoke-interface {v0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    move-object/from16 v10, v20

    invoke-interface {v0, v14, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v3, 0x0

    invoke-interface {v0, v15, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_6
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "app_host"

    invoke-interface {v0, v3, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "url"

    move-object/from16 v3, v17

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface/range {v16 .. v16}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_2
    return-void
.end method

.method private newUpdateDialog(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;,
            Ljava/security/GeneralSecurityException;,
            Ljava/security/GeneralSecurityException;
        }
    .end annotation

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v1, "ReleaseNotes"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v2, 0x3

    invoke-direct {v1, p0, v2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v2, "BOAS NOTICIAS"

    invoke-virtual {v1, v2}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v1, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "ATUALIZAR"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const-string v1, "Sair"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->showCancelButton(Z)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$5;

    invoke-direct {v1, p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$5;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method private noUpdateDialog()V
    .locals 2

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    const-string v1, "CYBERCOARI"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const-string v1, "Sua configura\u00e7\u00e3o est\u00e1 na vers\u00e3o mais recente"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->pDialog:Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->dismiss()V

    return-void
.end method

.method private restart_app()V
    .locals 3

    invoke-static {}, Lcom/cybercoari/com/br/SocksHttpApp;->getApp()Lcom/cybercoari/com/br/SocksHttpApp;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v1

    invoke-static {v1}, Landroid/content/Intent;->makeRestartActivityTask(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Runtime;->exit(I)V

    return-void
.end method

.method private saveSpinner()V
    .locals 4

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v1

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {v2}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v2

    const-string v3, "LastSelectedServer"

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const-string v1, "LastSelectedPayload"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private setSpinner()V
    .locals 4

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    const-string v1, "LastSelectedServer"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    const-string v3, "LastSelectedPayload"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {v2, v1}, Landroid/widget/Spinner;->setSelection(I)V

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {v1, v0}, Landroid/widget/Spinner;->setSelection(I)V

    return-void
.end method

.method private setupSSH()V
    .locals 5

    const-string v0, "proxyRemotoPorta"

    :try_start_0
    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v1}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "tunnelType"

    const/4 v4, 0x2

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    iget-object v3, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {v3}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v3

    iget-object v4, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v4}, Lcom/cybercoari/com/br/util/ConfigUtil;->getServersArray()Lorg/json/JSONArray;

    move-result-object v4

    invoke-virtual {v4, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "ServerPort"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "sshPort"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v3, ""

    invoke-interface {v1, v0, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "8080"

    invoke-interface {v2, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method private setupSSL()V
    .locals 4

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setupSSH()V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "tunnelType"

    const/4 v3, 0x3

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "sshPort"

    const-string v2, "443"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private updateAppearance()V
    .locals 2

    new-instance v0, Lcom/cybercoari/com/br/util/AppearanceUpdate;

    invoke-direct {v0, p0, p0}, Lcom/cybercoari/com/br/util/AppearanceUpdate;-><init>(Landroid/content/Context;Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/cybercoari/com/br/util/AppearanceUpdate;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method private startAutoConfigCheck()V
    .locals 3

    new-instance v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$22;
    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$22;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mRunnable:Ljava/lang/Runnable;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler2:Landroid/os/Handler;
    const-wide/16 v2, 0x7530
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    return-void
.end method

.method private scheduleAutoConfigCheck()V
    .locals 3
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler2:Landroid/os/Handler;
    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mRunnable:Ljava/lang/Runnable;
    if-eqz v0, :cond_auto_schedule_end
    if-eqz v1, :cond_auto_schedule_end
    const-wide/16 v2, 0x7530
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :cond_auto_schedule_end
    return-void
.end method

.method private runAutoConfigCheck()V
    .locals 1
    const/4 v0, 0x0
    invoke-direct {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateConfigAuto(Z)V
    return-void
.end method

.method private updateConfigAuto(Z)V
    .locals 2
    new-instance v0, Lcom/cybercoari/com/br/util/ConfigUpdate;
    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$21;
    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$21;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    invoke-direct {v0, p0, v1}, Lcom/cybercoari/com/br/util/ConfigUpdate;-><init>(Landroid/content/Context;Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;)V
    invoke-virtual {v0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate;->start(Z)V
    return-void
.end method

.method private applyAutoConfig(Ljava/lang/String;)V
    .locals 3
    :try_start_auto
    new-instance v0, Ljava/io/File;
    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getFilesDir()Ljava/io/File;
    move-result-object v1
    const-string v2, "Config.json"
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    new-instance v1, Ljava/io/FileOutputStream;
    invoke-direct {v1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B
    move-result-object p1
    invoke-virtual {v1, p1}, Ljava/io/OutputStream;->write([B)V
    invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->restart_app()V
    :try_end_auto
    .catch Ljava/io/IOException; {:try_start_auto .. :try_end_auto} :catch_auto
    return-void
    :catch_auto
    move-exception p1
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V
    return-void
.end method

.method private updateConfig(Z)V
    .locals 2

    new-instance v0, Lcom/cybercoari/com/br/util/ConfigUpdate;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$4;

    invoke-direct {v1, p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$4;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Z)V

    invoke-direct {v0, p0, v1}, Lcom/cybercoari/com/br/util/ConfigUpdate;-><init>(Landroid/content/Context;Lcom/cybercoari/com/br/util/ConfigUpdate$OnUpdateListener;)V

    invoke-virtual {v0, p1}, Lcom/cybercoari/com/br/util/ConfigUpdate;->start(Z)V

    return-void
.end method

.method public static updateMainViews(Landroid/content/Context;)V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-string v1, "MainUpdate"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    return-void
.end method


# virtual methods
.method public applyAppearanceJson(Ljava/lang/String;)V
    .locals 10

    const v0, -0x10000

    const v1, -0x6800

    const v2, -0x6800

    const v3, 0x7f040097

    const/4 v4, 0x0

    const/4 v5, -0x1

    const/4 v9, 0x4

    if-eqz p1, :cond_5

    :try_start_0
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v7, "CorBordaCampo"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_0

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    :cond_0
    const-string v7, "CorIconeUsuario"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_1

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    :cond_1
    const-string v7, "CorIconeSenha"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_2

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    :cond_2
    const-string v7, "CorBotaoStart"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_3

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    :cond_3
    const-string v7, "CorBordaBotaoStart"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_4

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    :cond_4
    const-string v7, "CorFonteBotaoStart"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_5

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const-string v7, "EspessuraBordaCampo"

    const/4 v8, 0x4

    invoke-virtual {v6, v7, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_5
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v7, v7, Landroid/util/DisplayMetrics;->density:F

    int-to-float v8, v9

    mul-float/2addr v8, v7

    float-to-int v9, v8

    iget-object v6, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-direct {p0, v6, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    invoke-direct {p0, v6, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceIcon(Landroid/view/View;I)V

    invoke-virtual {v6}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-direct {p0, v7, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    iget-object v6, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-direct {p0, v6, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    invoke-direct {p0, v6, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceIcon(Landroid/view/View;I)V

    invoke-virtual {v6}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    check-cast v7, Landroid/view/View;

    invoke-direct {p0, v7, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    iget-object v6, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-direct {p0, v6, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    iget-object v6, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-direct {p0, v6, v0, v9}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyAppearanceBackground(Landroid/view/View;II)V

    const v6, 0x7f09003c

    invoke-virtual {p0, v6}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v6

    invoke-direct {p0, v6, v3, v4, v5}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyStartButtonAppearance(Landroid/view/View;III)V

    return-void
.end method

.method public doTabs()V
    .locals 3

    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v0, p0}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    new-instance v1, Lcom/cybercoari/com/br/adapter/LogsAdapter;

    invoke-direct {v1, v0, p0}, Lcom/cybercoari/com/br/adapter/LogsAdapter;-><init>(Landroidx/recyclerview/widget/LinearLayoutManager;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mLogAdapter:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    const v1, 0x7f0900ec

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    iput-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->logList:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mLogAdapter:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->logList:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mLogAdapter:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/adapter/LogsAdapter;->scrollToLastPosition()V

    const v0, 0x7f09015e

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/viewpager/widget/ViewPager;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->vp:Landroidx/viewpager/widget/ViewPager;

    const v0, 0x7f090135

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/tabs/TabLayout;

    iput-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabs:Lcom/google/android/material/tabs/TabLayout;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->vp:Landroidx/viewpager/widget/ViewPager;

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$MyAdapter;

    sget-object v2, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabTitle:[Ljava/lang/String;

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v1, p0, v2}, Lcom/cybercoari/com/br/SocksHttpMainActivity$MyAdapter;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Ljava/util/List;)V

    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->setAdapter(Landroidx/viewpager/widget/PagerAdapter;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->vp:Landroidx/viewpager/widget/ViewPager;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->setOffscreenPageLimit(I)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabs:Lcom/google/android/material/tabs/TabLayout;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/tabs/TabLayout;->setTabMode(I)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabs:Lcom/google/android/material/tabs/TabLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/tabs/TabLayout;->setTabGravity(I)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->tabs:Lcom/google/android/material/tabs/TabLayout;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->vp:Landroidx/viewpager/widget/ViewPager;

    invoke-virtual {v0, v1}, Lcom/google/android/material/tabs/TabLayout;->setupWithViewPager(Landroidx/viewpager/widget/ViewPager;)V

    return-void
.end method

.method public onBackPressed()V
    .locals 2

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    const v1, 0x7f0f0033

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const v1, 0x7f0f002c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const v1, 0x7f0f007b

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$13;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$13;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const v1, 0x7f0f008c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->showCancelButton(Z)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$12;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$12;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 0

    return-void
.end method

.method public onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .locals 1

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {p2}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object p2

    invoke-virtual {p2}, Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;->edit()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences$Editor;

    move-result-object p2

    invoke-virtual {p1}, Landroid/widget/RadioGroup;->getCheckedRadioButtonId()I

    move-result p1

    const-string v0, "tunnelType"

    packed-switch p1, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const/4 p1, 0x2

    invoke-interface {p2, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :pswitch_1
    const/4 p1, 0x1

    invoke-interface {p2, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_0
    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doUpdateLayout()V

    return-void

    :pswitch_data_0
    .packed-switch 0x7f090037
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onClick(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v0, 0x1

    sparse-switch p1, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->restart_app()V

    goto/16 :goto_0

    :sswitch_1
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/cybercoari/com/br/activities/ConfigGeralActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v0, 0x10000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_0

    :sswitch_2
    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateConfig(Z)V

    goto/16 :goto_0

    :sswitch_3
    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doSaveData()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->loadServerData()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->saveSpinner()V

    invoke-virtual {p0, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startOrStopTunnel(Landroid/app/Activity;)V

    goto :goto_0

    :sswitch_4
    iget-boolean p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->isMostrarSenha:Z

    xor-int/2addr p1, v0

    iput-boolean p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->isMostrarSenha:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v0, 0x91

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/TextInputEditText;->setInputType(I)V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwShowPass:Landroid/widget/ImageButton;

    const v0, 0x7f0800bf

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v0, 0x81

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/TextInputEditText;->setInputType(I)V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwShowPass:Landroid/widget/ImageButton;

    const v0, 0x7f0800c0

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :sswitch_5
    new-instance p1, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {p1, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    const v1, 0x7f0f0033

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    const-string v1, "CYBERCOARI \u00e9 de acesso privado\n(N\u00c3O GRATUITO) \n\nCaso queira conhecer os valores e prazos ou aderir acesso ao aplicativo entre em Contato."

    invoke-virtual {p1, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    const-string v1, "Fechar"

    invoke-virtual {p1, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    new-instance v1, Lcom/cybercoari/com/br/SocksHttpMainActivity$7;

    invoke-direct {v1, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$7;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p1, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    const-string v1, "Contato"

    invoke-virtual {p1, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    invoke-virtual {p1, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->showCancelButton(Z)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    new-instance v0, Lcom/cybercoari/com/br/SocksHttpMainActivity$6;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$6;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p1, v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setCancelClickListener(Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    :goto_0
    return-void

    :sswitch_data_0
    .sparse-switch
        0x7f090028 -> :sswitch_5
        0x7f09002f -> :sswitch_4
        0x7f09003c -> :sswitch_3
        0x7f09004c -> :sswitch_2
        0x7f09004d -> :sswitch_1
        0x7f0900ee -> :sswitch_0
    .end sparse-switch
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    invoke-super {p0, p1}, Lcom/cybercoari/com/br/activities/BaseActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroidx/appcompat/app/ActionBarDrawerToggle;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6

    invoke-super {p0, p1}, Lcom/cybercoari/com/br/activities/BaseActivity;->onCreate(Landroid/os/Bundle;)V

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler:Landroid/os/Handler;

    new-instance p1, Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-direct {p1, p0}, Lcom/romzkie/ultrasshservice/config/Settings;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    new-instance p1, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-direct {p1, p0, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Landroidx/appcompat/app/AppCompatActivity;)V

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    new-instance p1, Lcom/cybercoari/com/br/SocksHttpMainActivity$OneSocks;

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->makefat:[Ljava/lang/String;

    invoke-direct {p1, p0, p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$OneSocks;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Landroid/content/Context;[Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$OneSocks;->init()V

    new-instance p1, Lcom/cybercoari/com/br/activities/SMSuPdater;

    invoke-direct {p1, p0}, Lcom/cybercoari/com/br/activities/SMSuPdater;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    new-instance p1, Lcom/cybercoari/com/br/ExceptionHandler;

    invoke-direct {p1, p0}, Lcom/cybercoari/com/br/ExceptionHandler;-><init>(Landroid/app/Activity;)V

    invoke-static {p1}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setRequestedOrientation(I)V

    const-string v0, "SocksHttpGERAL"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "connect_first_time"

    invoke-interface {v0, v2, p1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const-string v3, "last_version"

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    if-eqz p1, :cond_0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-static {p0}, Lcom/romzkie/ultrasshservice/config/Settings;->setDefaultConfig(Landroid/content/Context;)V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->showBoasVindas()V

    :cond_0
    :try_start_0
    invoke-static {p0}, Lcom/romzkie/ultrasshservice/config/ConfigParser;->getBuildId(Landroid/content/Context;)I

    move-result v1

    iput v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->idAtual:I

    if-ge v4, v1, :cond_1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->idAtual:I

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-nez p1, :cond_1

    if-eqz v4, :cond_1

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->ShowMsgUpdate()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doLayout()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->applyOnlineTheme()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateAppearance()V

    new-instance p1, Landroid/content/IntentFilter;

    invoke-direct {p1}, Landroid/content/IntentFilter;-><init>()V

    const-string v0, "MainUpdate"

    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "com.cybercoari.com.br:openLogs"

    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    invoke-static {p0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mActivityReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1, p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doUpdateLayout()V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const v1, 0x7f0d0001

    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 p1, 0x1

    return p1
.end method

.method protected onDestroy()V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler2:Landroid/os/Handler;
    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mRunnable:Ljava/lang/Runnable;
    if-eqz v0, :cond_auto_destroy
    if-eqz v1, :cond_auto_destroy
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_auto_destroy
    invoke-super {p0}, Lcom/cybercoari/com/br/activities/BaseActivity;->onDestroy()V

    invoke-static {p0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mActivityReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    return-void
.end method

.method public onDismiss(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v0, p1}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "Payload successfully generated!"

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->dialog:Landroidx/appcompat/app/AlertDialog;

    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->dismiss()V

    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 3

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroidx/appcompat/app/ActionBarDrawerToggle;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const/4 v1, 0x0

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/cybercoari/com/br/activities/ConfigGeralActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    :sswitch_1
    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->isTunnelActive()Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;

    invoke-direct {v0}, Lcom/cybercoari/com/br/fragments/ClearConfigDialogFragment;-><init>()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "alertClearConf"

    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/DialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    const v0, 0x7f0f0078

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_0

    :sswitch_2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x10

    if-lt v0, v2, :cond_2

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->finishAffinity()V

    :cond_2
    invoke-static {v1}, Ljava/lang/System;->exit(I)V

    goto :goto_0

    :sswitch_3
    invoke-direct {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateConfig(Z)V

    :goto_0
    invoke-super {p0, p1}, Lcom/cybercoari/com/br/activities/BaseActivity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1

    nop

    :sswitch_data_0
    .sparse-switch
        0x7f09005b -> :sswitch_3
        0x7f0900c4 -> :sswitch_2
        0x7f0900c5 -> :sswitch_1
        0x7f0900c9 -> :sswitch_0
    .end sparse-switch
.end method

.method protected onPause()V
    .locals 1

    invoke-super {p0}, Lcom/cybercoari/com/br/activities/BaseActivity;->onPause()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->doSaveData()V

    invoke-static {p0}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->removeStateListener(Lcom/romzkie/ultrasshservice/logger/SkStatus$StateListener;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->typenetwork:Z

    return-void
.end method

.method public onPostCreate(Landroid/os/Bundle;Landroid/os/PersistableBundle;)V
    .locals 0

    invoke-super {p0, p1, p2}, Lcom/cybercoari/com/br/activities/BaseActivity;->onPostCreate(Landroid/os/Bundle;Landroid/os/PersistableBundle;)V

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mDrawerPanel:Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;

    invoke-virtual {p1}, Lcom/cybercoari/com/br/SocksHttpMainActivity$DrawerPanelMain;->getToogle()Landroidx/appcompat/app/ActionBarDrawerToggle;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/appcompat/app/ActionBarDrawerToggle;->syncState()V

    :cond_0
    return-void
.end method

.method public onResume()V
    .locals 1

    invoke-super {p0}, Lcom/cybercoari/com/br/activities/BaseActivity;->onResume()V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setSpinner()V

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->setuserpass()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->typenetwork:Z

    invoke-static {p0}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->addStateListener(Lcom/romzkie/ultrasshservice/logger/SkStatus$StateListener;)V

    return-void
.end method

.method public parseRandom(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const-string v0, ";"

    :try_start_0
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    array-length v2, v0

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    array-length v2, v0

    if-ge v1, v2, :cond_0

    if-gez v1, :cond_1

    :cond_0
    const/4 v1, 0x0

    :cond_1
    aget-object p1, v0, v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    return-object p1
.end method

.method public setStarterButton(Landroid/widget/Button;Landroid/app/Activity;)V
    .locals 7

    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->getLastState()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->isTunnelActive()Z

    move-result v1

    if-eqz p1, :cond_8

    new-instance v2, Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-direct {v2, p2}, Lcom/romzkie/ultrasshservice/config/Settings;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v2

    const-wide/16 v3, 0x0

    const-string v5, "validadeConfig"

    invoke-interface {v2, v5, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    invoke-static {v3, v4}, Lcom/romzkie/ultrasshservice/config/ConfigParser;->isValidadeExpirou(J)Z

    move-result v3

    const v4, 0x7f0f00be

    const v5, 0x7f0f00db

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const v4, 0x7f0f007d

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setEnabled(Z)V

    if-eqz v1, :cond_7

    invoke-virtual {p0, p2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startOrStopTunnel(Landroid/app/Activity;)V

    goto/16 :goto_1

    :cond_0
    const-string v3, "blockRoot"

    invoke-interface {v2, v3, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {p2}, Lcom/romzkie/ultrasshservice/config/ConfigParser;->isDeviceRooted(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_1

    const v4, 0x7f0f0038

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setEnabled(Z)V

    const v0, 0x7f0f0073

    invoke-static {p2, v0, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    if-eqz v1, :cond_7

    invoke-virtual {p0, p2}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->startOrStopTunnel(Landroid/app/Activity;)V

    goto/16 :goto_1

    :cond_1
    const-string p2, "INICIANDO"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const v2, 0x7f080065

    if-eqz p2, :cond_2

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v6}, Landroid/widget/Spinner;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v6}, Landroid/widget/Spinner;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->sslEdit:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const v4, 0x7f0f00db

    goto/16 :goto_1

    :cond_2
    const-string p2, "CONECTADO"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x1

    if-eqz p2, :cond_3

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v6}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v6}, Landroid/widget/Spinner;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v6}, Landroid/widget/Spinner;->setEnabled(Z)V

    goto :goto_0

    :cond_3
    const-string p2, "PARANDO"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4

    const v4, 0x7f0f00d2

    invoke-virtual {p1, v6}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    :cond_4
    const-string p2, "DESCONECTADO"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_5

    invoke-virtual {p1, v3}, Landroid/widget/Button;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->serverSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v3}, Landroid/widget/Spinner;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadSpinner:Landroid/widget/Spinner;

    invoke-virtual {p2, v3}, Landroid/widget/Spinner;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->sslEdit:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->payloadEdit:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputEditText;->setEnabled(Z)V

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->status:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f080066

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    :cond_5
    if-eqz v1, :cond_6

    const v4, 0x7f0f00db

    :cond_6
    invoke-virtual {p1, v3}, Landroid/widget/Button;->setEnabled(Z)V

    :cond_7
    :goto_1
    invoke-virtual {p1, v4}, Landroid/widget/Button;->setText(I)V

    :cond_8
    return-void
.end method

.method public setuserpass()V
    .locals 4

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mConfig:Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v0

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    const-string v2, "sshUser"

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    const-string v2, "sshPass"

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method protected showBoasVindas()V
    .locals 2

    new-instance v0, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;-><init>(Landroid/content/Context;I)V

    const-string v1, "Aten\u00e7\u00e3o"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setTitleText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const-string v1, "O CYBERCOARI oferece a seguran\u00e7a online e a confidencialidade que cada um de n\u00f3s merece. A melhor e mais r\u00e1pida VPN desenvolvida por seus usu\u00e1rios, para seus usu\u00e1rios.\n\n\u25ba Internet ilimitada\n\u25ba Acesso e conex\u00e3o ilimitados.\n\u25ba VPN f\u00e1cil de usar, conex\u00e3o de um toque.\n\u25ba Nenhum registro salvo."

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setContentText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    const-string v1, "Certo"

    invoke-virtual {v0, v1}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->setConfirmText(Ljava/lang/String;)Lcn/pedant/SweetAlert/widget/SweetAlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Lcn/pedant/SweetAlert/widget/SweetAlertDialog;->show()V

    return-void
.end method

.method public showExitDialog()V
    .locals 4

    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object v0

    const v1, 0x7f0f0033

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog;->setTitle(Ljava/lang/CharSequence;)V

    const v1, 0x7f0f002c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog;->setMessage(Ljava/lang/CharSequence;)V

    const v1, 0x7f0f007b

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/cybercoari/com/br/SocksHttpMainActivity$14;

    invoke-direct {v2, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$14;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    const/4 v3, -0x1

    invoke-virtual {v0, v3, v1, v2}, Landroidx/appcompat/app/AlertDialog;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    const v1, 0x7f0f008c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/cybercoari/com/br/SocksHttpMainActivity$15;

    invoke-direct {v2, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$15;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1, v2}, Landroidx/appcompat/app/AlertDialog;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method public startOrStopTunnel(Landroid/app/Activity;)V
    .locals 4

    invoke-static {}, Lcom/romzkie/ultrasshservice/logger/SkStatus;->isTunnelActive()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/romzkie/ultrasshservice/tunnel/TunnelManagerHelper;->stopSocksHttp(Landroid/content/Context;)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->config:Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getUdpPort()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->parseRandom(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/romzkie/ultrasshservice/config/Settings;->setUdpRandom(Landroid/content/Context;Ljava/lang/String;)V

    new-instance v0, Lcom/romzkie/ultrasshservice/config/Settings;

    invoke-direct {v0, p1}, Lcom/romzkie/ultrasshservice/config/Settings;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getPrefsPrivate()Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;

    move-result-object v1

    const-string v2, "inputPassword"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Lcom/romzkie/ultrasshservice/util/securepreferences/SecurePreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwUser:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->inputPwPass:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    const p1, 0x7f0f0079

    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/romzkie/ultrasshservice/LaunchVpn;

    invoke-direct {v1, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "android.intent.action.MAIN"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v0}, Lcom/romzkie/ultrasshservice/config/Settings;->getHideLog()Z

    move-result v0

    if-eqz v0, :cond_3

    const/4 v0, 0x1

    const-string v2, "com.cybercoari.com.br.showNoLogWindow"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_3
    invoke-virtual {p1, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    invoke-direct {p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->antcrash()V

    :goto_0
    return-void
.end method

.method public updateState(Ljava/lang/String;Ljava/lang/String;ILcom/romzkie/ultrasshservice/logger/ConnectionStatus;Landroid/content/Intent;)V
    .locals 0

    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler:Landroid/os/Handler;

    new-instance p3, Lcom/cybercoari/com/br/SocksHttpMainActivity$8;

    invoke-direct {p3, p0, p4}, Lcom/cybercoari/com/br/SocksHttpMainActivity$8;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;Lcom/romzkie/ultrasshservice/logger/ConnectionStatus;)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const-string p2, "CONECTADO"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    iget-object p2, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler:Landroid/os/Handler;

    new-instance p3, Lcom/cybercoari/com/br/SocksHttpMainActivity$9;

    invoke-direct {p3, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$9;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const-string p2, "AUTENTICADO"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    iget-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity;->mHandler:Landroid/os/Handler;

    new-instance p2, Lcom/cybercoari/com/br/SocksHttpMainActivity$10;

    invoke-direct {p2, p0}, Lcom/cybercoari/com/br/SocksHttpMainActivity$10;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_1
    return-void
.end method
