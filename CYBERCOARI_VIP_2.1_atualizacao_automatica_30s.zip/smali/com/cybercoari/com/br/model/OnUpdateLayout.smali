.class public interface abstract Lcom/cybercoari/com/br/model/OnUpdateLayout;
.super Ljava/lang/Object;


# virtual methods
.method public abstract updateLayout(Landroid/view/View;)V
.end method
