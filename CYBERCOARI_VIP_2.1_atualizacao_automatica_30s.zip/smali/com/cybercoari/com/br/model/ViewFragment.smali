.class public abstract Lcom/cybercoari/com/br/model/ViewFragment;
.super Landroidx/fragment/app/Fragment;

# interfaces
.implements Lcom/cybercoari/com/br/model/OnUpdateLayout;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    return-void
.end method


# virtual methods
.method public updateLayout()V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/cybercoari/com/br/model/ViewFragment;->updateLayout(Landroid/view/View;)V

    return-void
.end method
