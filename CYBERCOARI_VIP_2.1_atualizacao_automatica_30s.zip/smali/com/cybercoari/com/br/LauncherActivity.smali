.class public Lcom/cybercoari/com/br/LauncherActivity;
.super Lcom/cybercoari/com/br/activities/BaseActivity;


# instance fields
.field private app_name:Landroid/widget/TextView;

.field private txtAnim:Landroid/view/animation/Animation;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/cybercoari/com/br/activities/BaseActivity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5

    invoke-super {p0, p1}, Lcom/cybercoari/com/br/activities/BaseActivity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0024

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/LauncherActivity;->setContentView(I)V

    new-instance v0, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getLogoonline()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_0

    const v1, 0x7f09011c

    invoke-virtual {p0, v1}, Lcom/cybercoari/com/br/LauncherActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_0

    new-instance v2, Lcom/cybercoari/com/br/util/OnlineLogo;

    invoke-direct {v2, p0, v1, v0}, Lcom/cybercoari/com/br/util/OnlineLogo;-><init>(Landroid/app/Activity;Landroid/widget/ImageView;Ljava/lang/String;)V

    invoke-virtual {v2}, Lcom/cybercoari/com/br/util/OnlineLogo;->start()V

    :cond_0
    const p1, 0x7f090044

    invoke-virtual {p0, p1}, Lcom/cybercoari/com/br/LauncherActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/cybercoari/com/br/LauncherActivity;->app_name:Landroid/widget/TextView;

    new-instance v0, Lcom/cybercoari/com/br/util/ConfigUtil;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/util/ConfigUtil;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lcom/cybercoari/com/br/util/ConfigUtil;->getAppName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object p1, p0, Lcom/cybercoari/com/br/LauncherActivity;->app_name:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    invoke-virtual {p0}, Lcom/cybercoari/com/br/LauncherActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f010014

    invoke-static {p1, v0}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object p1

    iput-object p1, p0, Lcom/cybercoari/com/br/LauncherActivity;->txtAnim:Landroid/view/animation/Animation;

    iget-object p1, p0, Lcom/cybercoari/com/br/LauncherActivity;->app_name:Landroid/widget/TextView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object p1, p0, Lcom/cybercoari/com/br/LauncherActivity;->app_name:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/cybercoari/com/br/LauncherActivity;->txtAnim:Landroid/view/animation/Animation;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->startAnimation(Landroid/view/animation/Animation;)V

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    new-instance v0, Lcom/cybercoari/com/br/LauncherActivity$1;

    invoke-direct {v0, p0}, Lcom/cybercoari/com/br/LauncherActivity$1;-><init>(Lcom/cybercoari/com/br/LauncherActivity;)V

    const-wide/16 v1, 0xbb8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
