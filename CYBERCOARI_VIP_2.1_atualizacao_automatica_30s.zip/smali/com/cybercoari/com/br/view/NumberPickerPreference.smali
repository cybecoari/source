.class public Lcom/cybercoari/com/br/view/NumberPickerPreference;
.super Landroidx/preference/PreferenceDialogFragmentCompat;


# static fields
.field public static final MAX_VALUE:I = 0x64

.field public static final MIN_VALUE:I = 0x0

.field public static final WRAP_SELECTOR_WHEEL:Z = true


# instance fields
.field private picker:Landroid/widget/NumberPicker;

.field private value:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/preference/PreferenceDialogFragmentCompat;-><init>()V

    return-void
.end method


# virtual methods
.method public onDialogClosed(Z)V
    .locals 0

    return-void
.end method
