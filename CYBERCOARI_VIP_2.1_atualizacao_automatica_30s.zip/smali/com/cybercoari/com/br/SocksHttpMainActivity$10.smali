.class Lcom/cybercoari/com/br/SocksHttpMainActivity$10;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/SocksHttpMainActivity;->updateState(Ljava/lang/String;Ljava/lang/String;ILcom/romzkie/ultrasshservice/logger/ConnectionStatus;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$10;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$10;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/cybercoari/com/br/SocksHttpMainActivity;->access$1300(Lcom/cybercoari/com/br/SocksHttpMainActivity;Z)V

    new-instance v0, Lcom/cybercoari/com/br/activities/SMSuPdater;

    iget-object v1, p0, Lcom/cybercoari/com/br/SocksHttpMainActivity$10;->this$0:Lcom/cybercoari/com/br/SocksHttpMainActivity;

    invoke-direct {v0, v1}, Lcom/cybercoari/com/br/activities/SMSuPdater;-><init>(Lcom/cybercoari/com/br/SocksHttpMainActivity;)V

    return-void
.end method
