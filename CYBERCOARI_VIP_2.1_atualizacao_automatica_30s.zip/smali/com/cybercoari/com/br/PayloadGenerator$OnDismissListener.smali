.class public interface abstract Lcom/cybercoari/com/br/PayloadGenerator$OnDismissListener;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/PayloadGenerator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnDismissListener"
.end annotation


# virtual methods
.method public abstract onDismiss(Ljava/lang/String;)V
.end method
