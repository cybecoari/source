.class public Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ItemHolder"
.end annotation


# instance fields
.field ivImage:Landroid/widget/ImageView;

.field final synthetic this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

.field tvItemLayout:Landroid/widget/LinearLayout;

.field tvItemName:Landroid/widget/TextView;

.field tvItemNameSecond:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;->this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    const p1, 0x7f0900b1

    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;->tvItemLayout:Landroid/widget/LinearLayout;

    const p1, 0x7f090155

    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;->tvItemName:Landroid/widget/TextView;

    const p1, 0x7f0900b0

    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;->ivImage:Landroid/widget/ImageView;

    const p1, 0x7f090156

    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;->tvItemNameSecond:Landroid/widget/TextView;

    return-void
.end method
