.class Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;->onBindViewHolder(Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$ItemHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

.field final synthetic val$position:I


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;I)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

    iput p2, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;->val$position:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

    invoke-static {v0}, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;->access$000(Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;)Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$OnItemClickListener;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;

    invoke-static {v0}, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;->access$000(Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter;)Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$OnItemClickListener;

    move-result-object v0

    iget v1, p0, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$1;->val$position:I

    invoke-interface {v0, p1, v1}, Lcom/cybercoari/com/br/adapter/ManagerFilesAdapter$OnItemClickListener;->onItemClick(Landroid/view/View;I)V

    :cond_0
    return-void
.end method
