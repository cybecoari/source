.class Lcom/cybercoari/com/br/adapter/LogsAdapter$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/cybercoari/com/br/adapter/LogsAdapter;->onBindViewHolder(Lcom/cybercoari/com/br/adapter/LogsAdapter$logViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/cybercoari/com/br/adapter/LogsAdapter;

.field final synthetic val$position:I

.field final synthetic val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/cybercoari/com/br/adapter/LogsAdapter;ILjava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    iput p2, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->val$position:I

    iput-object p3, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->val$text:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    invoke-static {v0}, Lcom/cybercoari/com/br/adapter/LogsAdapter;->access$000(Lcom/cybercoari/com/br/adapter/LogsAdapter;)Lcom/cybercoari/com/br/adapter/LogsAdapter$OnItemClickListener;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->this$0:Lcom/cybercoari/com/br/adapter/LogsAdapter;

    invoke-static {v0}, Lcom/cybercoari/com/br/adapter/LogsAdapter;->access$000(Lcom/cybercoari/com/br/adapter/LogsAdapter;)Lcom/cybercoari/com/br/adapter/LogsAdapter$OnItemClickListener;

    move-result-object v0

    iget v1, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->val$position:I

    iget-object v2, p0, Lcom/cybercoari/com/br/adapter/LogsAdapter$1;->val$text:Ljava/lang/String;

    invoke-interface {v0, p1, v1, v2}, Lcom/cybercoari/com/br/adapter/LogsAdapter$OnItemClickListener;->onItemClick(Landroid/view/View;ILjava/lang/String;)V

    :cond_0
    return-void
.end method
