.class public interface abstract Lcom/cybercoari/com/br/adapter/LogsAdapter$OnItemClickListener;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/cybercoari/com/br/adapter/LogsAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnItemClickListener"
.end annotation


# virtual methods
.method public abstract onItemClick(Landroid/view/View;ILjava/lang/String;)V
.end method

.method public abstract onItemLongClick(Landroid/view/View;ILjava/lang/String;)V
.end method
