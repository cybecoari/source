.class public final Lcom/pnikosis/materialishprogress/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final Base_TextAppearance_AppCompat:I = 0x7f100015

.field public static final Base_TextAppearance_AppCompat_Body1:I = 0x7f100016

.field public static final Base_TextAppearance_AppCompat_Body2:I = 0x7f100017

.field public static final Base_TextAppearance_AppCompat_Button:I = 0x7f100018

.field public static final Base_TextAppearance_AppCompat_Caption:I = 0x7f100019

.field public static final Base_TextAppearance_AppCompat_Display1:I = 0x7f10001a

.field public static final Base_TextAppearance_AppCompat_Display2:I = 0x7f10001b

.field public static final Base_TextAppearance_AppCompat_Display3:I = 0x7f10001c

.field public static final Base_TextAppearance_AppCompat_Display4:I = 0x7f10001d

.field public static final Base_TextAppearance_AppCompat_Headline:I = 0x7f10001e

.field public static final Base_TextAppearance_AppCompat_Inverse:I = 0x7f10001f

.field public static final Base_TextAppearance_AppCompat_Large:I = 0x7f100020

.field public static final Base_TextAppearance_AppCompat_Large_Inverse:I = 0x7f100021

.field public static final Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large:I = 0x7f100022

.field public static final Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small:I = 0x7f100023

.field public static final Base_TextAppearance_AppCompat_Medium:I = 0x7f100024

.field public static final Base_TextAppearance_AppCompat_Medium_Inverse:I = 0x7f100025

.field public static final Base_TextAppearance_AppCompat_Menu:I = 0x7f100026

.field public static final Base_TextAppearance_AppCompat_SearchResult:I = 0x7f100027

.field public static final Base_TextAppearance_AppCompat_SearchResult_Subtitle:I = 0x7f100028

.field public static final Base_TextAppearance_AppCompat_SearchResult_Title:I = 0x7f100029

.field public static final Base_TextAppearance_AppCompat_Small:I = 0x7f10002a

.field public static final Base_TextAppearance_AppCompat_Small_Inverse:I = 0x7f10002b

.field public static final Base_TextAppearance_AppCompat_Subhead:I = 0x7f10002c

.field public static final Base_TextAppearance_AppCompat_Subhead_Inverse:I = 0x7f10002d

.field public static final Base_TextAppearance_AppCompat_Title:I = 0x7f10002e

.field public static final Base_TextAppearance_AppCompat_Title_Inverse:I = 0x7f10002f

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Menu:I = 0x7f100031

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle:I = 0x7f100032

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse:I = 0x7f100033

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Title:I = 0x7f100034

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse:I = 0x7f100035

.field public static final Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle:I = 0x7f100036

.field public static final Base_TextAppearance_AppCompat_Widget_ActionMode_Title:I = 0x7f100037

.field public static final Base_TextAppearance_AppCompat_Widget_DropDownItem:I = 0x7f10003c

.field public static final Base_TextAppearance_AppCompat_Widget_PopupMenu_Large:I = 0x7f10003e

.field public static final Base_TextAppearance_AppCompat_Widget_PopupMenu_Small:I = 0x7f10003f

.field public static final Base_TextAppearance_AppCompat_Widget_Switch:I = 0x7f100040

.field public static final Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item:I = 0x7f100042

.field public static final Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle:I = 0x7f100043

.field public static final Base_TextAppearance_Widget_AppCompat_Toolbar_Title:I = 0x7f100044

.field public static final Base_ThemeOverlay_AppCompat:I = 0x7f100064

.field public static final Base_ThemeOverlay_AppCompat_ActionBar:I = 0x7f100065

.field public static final Base_ThemeOverlay_AppCompat_Dark:I = 0x7f100066

.field public static final Base_ThemeOverlay_AppCompat_Dark_ActionBar:I = 0x7f100067

.field public static final Base_ThemeOverlay_AppCompat_Light:I = 0x7f10006a

.field public static final Base_Theme_AppCompat:I = 0x7f100045

.field public static final Base_Theme_AppCompat_CompactMenu:I = 0x7f100046

.field public static final Base_Theme_AppCompat_Dialog:I = 0x7f100047

.field public static final Base_Theme_AppCompat_DialogWhenLarge:I = 0x7f10004b

.field public static final Base_Theme_AppCompat_Dialog_FixedSize:I = 0x7f100049

.field public static final Base_Theme_AppCompat_Light:I = 0x7f10004c

.field public static final Base_Theme_AppCompat_Light_DarkActionBar:I = 0x7f10004d

.field public static final Base_Theme_AppCompat_Light_Dialog:I = 0x7f10004e

.field public static final Base_Theme_AppCompat_Light_DialogWhenLarge:I = 0x7f100052

.field public static final Base_Theme_AppCompat_Light_Dialog_FixedSize:I = 0x7f100050

.field public static final Base_V21_Theme_AppCompat:I = 0x7f100076

.field public static final Base_V21_Theme_AppCompat_Dialog:I = 0x7f100077

.field public static final Base_V21_Theme_AppCompat_Light:I = 0x7f100078

.field public static final Base_V21_Theme_AppCompat_Light_Dialog:I = 0x7f100079

.field public static final Base_V7_Theme_AppCompat:I = 0x7f100084

.field public static final Base_V7_Theme_AppCompat_Dialog:I = 0x7f100085

.field public static final Base_V7_Theme_AppCompat_Light:I = 0x7f100086

.field public static final Base_Widget_AppCompat_ActionBar:I = 0x7f10008c

.field public static final Base_Widget_AppCompat_ActionBar_Solid:I = 0x7f10008d

.field public static final Base_Widget_AppCompat_ActionBar_TabBar:I = 0x7f10008e

.field public static final Base_Widget_AppCompat_ActionBar_TabText:I = 0x7f10008f

.field public static final Base_Widget_AppCompat_ActionBar_TabView:I = 0x7f100090

.field public static final Base_Widget_AppCompat_ActionButton:I = 0x7f100091

.field public static final Base_Widget_AppCompat_ActionButton_CloseMode:I = 0x7f100092

.field public static final Base_Widget_AppCompat_ActionButton_Overflow:I = 0x7f100093

.field public static final Base_Widget_AppCompat_ActionMode:I = 0x7f100094

.field public static final Base_Widget_AppCompat_ActivityChooserView:I = 0x7f100095

.field public static final Base_Widget_AppCompat_AutoCompleteTextView:I = 0x7f100096

.field public static final Base_Widget_AppCompat_CompoundButton_Switch:I = 0x7f1000a1

.field public static final Base_Widget_AppCompat_DrawerArrowToggle:I = 0x7f1000a2

.field public static final Base_Widget_AppCompat_DropDownItem_Spinner:I = 0x7f1000a4

.field public static final Base_Widget_AppCompat_EditText:I = 0x7f1000a5

.field public static final Base_Widget_AppCompat_Light_ActionBar:I = 0x7f1000a7

.field public static final Base_Widget_AppCompat_Light_ActionBar_Solid:I = 0x7f1000a8

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabBar:I = 0x7f1000a9

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabText:I = 0x7f1000aa

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse:I = 0x7f1000ab

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabView:I = 0x7f1000ac

.field public static final Base_Widget_AppCompat_Light_PopupMenu:I = 0x7f1000ad

.field public static final Base_Widget_AppCompat_Light_PopupMenu_Overflow:I = 0x7f1000ae

.field public static final Base_Widget_AppCompat_ListPopupWindow:I = 0x7f1000b0

.field public static final Base_Widget_AppCompat_ListView_DropDown:I = 0x7f1000b2

.field public static final Base_Widget_AppCompat_ListView_Menu:I = 0x7f1000b3

.field public static final Base_Widget_AppCompat_PopupMenu:I = 0x7f1000b4

.field public static final Base_Widget_AppCompat_PopupMenu_Overflow:I = 0x7f1000b5

.field public static final Base_Widget_AppCompat_PopupWindow:I = 0x7f1000b6

.field public static final Base_Widget_AppCompat_ProgressBar:I = 0x7f1000b7

.field public static final Base_Widget_AppCompat_ProgressBar_Horizontal:I = 0x7f1000b8

.field public static final Base_Widget_AppCompat_SearchView:I = 0x7f1000bc

.field public static final Base_Widget_AppCompat_Spinner:I = 0x7f1000c0

.field public static final Base_Widget_AppCompat_Toolbar:I = 0x7f1000c3

.field public static final Base_Widget_AppCompat_Toolbar_Button_Navigation:I = 0x7f1000c4

.field public static final Platform_AppCompat:I = 0x7f1000cc

.field public static final Platform_AppCompat_Light:I = 0x7f1000cd

.field public static final RtlOverlay_Widget_AppCompat_ActionBar_TitleItem:I = 0x7f1000fa

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem:I = 0x7f1000fc

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup:I = 0x7f1000fd

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_Text:I = 0x7f100100

.field public static final RtlOverlay_Widget_AppCompat_SearchView_MagIcon:I = 0x7f100107

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown:I = 0x7f100102

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1:I = 0x7f100103

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2:I = 0x7f100104

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Query:I = 0x7f100105

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Text:I = 0x7f100106

.field public static final TextAppearance_AppCompat:I = 0x7f10010b

.field public static final TextAppearance_AppCompat_Body1:I = 0x7f10010c

.field public static final TextAppearance_AppCompat_Body2:I = 0x7f10010d

.field public static final TextAppearance_AppCompat_Button:I = 0x7f10010e

.field public static final TextAppearance_AppCompat_Caption:I = 0x7f10010f

.field public static final TextAppearance_AppCompat_Display1:I = 0x7f100110

.field public static final TextAppearance_AppCompat_Display2:I = 0x7f100111

.field public static final TextAppearance_AppCompat_Display3:I = 0x7f100112

.field public static final TextAppearance_AppCompat_Display4:I = 0x7f100113

.field public static final TextAppearance_AppCompat_Headline:I = 0x7f100114

.field public static final TextAppearance_AppCompat_Inverse:I = 0x7f100115

.field public static final TextAppearance_AppCompat_Large:I = 0x7f100116

.field public static final TextAppearance_AppCompat_Large_Inverse:I = 0x7f100117

.field public static final TextAppearance_AppCompat_Light_SearchResult_Subtitle:I = 0x7f100118

.field public static final TextAppearance_AppCompat_Light_SearchResult_Title:I = 0x7f100119

.field public static final TextAppearance_AppCompat_Light_Widget_PopupMenu_Large:I = 0x7f10011a

.field public static final TextAppearance_AppCompat_Light_Widget_PopupMenu_Small:I = 0x7f10011b

.field public static final TextAppearance_AppCompat_Medium:I = 0x7f10011c

.field public static final TextAppearance_AppCompat_Medium_Inverse:I = 0x7f10011d

.field public static final TextAppearance_AppCompat_Menu:I = 0x7f10011e

.field public static final TextAppearance_AppCompat_SearchResult_Subtitle:I = 0x7f10011f

.field public static final TextAppearance_AppCompat_SearchResult_Title:I = 0x7f100120

.field public static final TextAppearance_AppCompat_Small:I = 0x7f100121

.field public static final TextAppearance_AppCompat_Small_Inverse:I = 0x7f100122

.field public static final TextAppearance_AppCompat_Subhead:I = 0x7f100123

.field public static final TextAppearance_AppCompat_Subhead_Inverse:I = 0x7f100124

.field public static final TextAppearance_AppCompat_Title:I = 0x7f100125

.field public static final TextAppearance_AppCompat_Title_Inverse:I = 0x7f100126

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Menu:I = 0x7f100128

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Subtitle:I = 0x7f100129

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse:I = 0x7f10012a

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Title:I = 0x7f10012b

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse:I = 0x7f10012c

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Subtitle:I = 0x7f10012d

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse:I = 0x7f10012e

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Title:I = 0x7f10012f

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse:I = 0x7f100130

.field public static final TextAppearance_AppCompat_Widget_DropDownItem:I = 0x7f100135

.field public static final TextAppearance_AppCompat_Widget_PopupMenu_Large:I = 0x7f100137

.field public static final TextAppearance_AppCompat_Widget_PopupMenu_Small:I = 0x7f100138

.field public static final TextAppearance_AppCompat_Widget_Switch:I = 0x7f100139

.field public static final TextAppearance_Widget_AppCompat_ExpandedMenu_Item:I = 0x7f100157

.field public static final TextAppearance_Widget_AppCompat_Toolbar_Subtitle:I = 0x7f100158

.field public static final TextAppearance_Widget_AppCompat_Toolbar_Title:I = 0x7f100159

.field public static final ThemeOverlay_AppCompat:I = 0x7f10018a

.field public static final ThemeOverlay_AppCompat_ActionBar:I = 0x7f10018b

.field public static final ThemeOverlay_AppCompat_Dark:I = 0x7f10018c

.field public static final ThemeOverlay_AppCompat_Dark_ActionBar:I = 0x7f10018d

.field public static final ThemeOverlay_AppCompat_Light:I = 0x7f100190

.field public static final Theme_AppCompat:I = 0x7f10015a

.field public static final Theme_AppCompat_CompactMenu:I = 0x7f10015b

.field public static final Theme_AppCompat_Dialog:I = 0x7f100163

.field public static final Theme_AppCompat_DialogWhenLarge:I = 0x7f100166

.field public static final Theme_AppCompat_Light:I = 0x7f100167

.field public static final Theme_AppCompat_Light_DarkActionBar:I = 0x7f100168

.field public static final Theme_AppCompat_Light_Dialog:I = 0x7f100169

.field public static final Theme_AppCompat_Light_DialogWhenLarge:I = 0x7f10016c

.field public static final Theme_AppCompat_Light_NoActionBar:I = 0x7f10016d

.field public static final Theme_AppCompat_NoActionBar:I = 0x7f10016e

.field public static final Widget_AppCompat_ActionBar:I = 0x7f1001a0

.field public static final Widget_AppCompat_ActionBar_Solid:I = 0x7f1001a1

.field public static final Widget_AppCompat_ActionBar_TabBar:I = 0x7f1001a2

.field public static final Widget_AppCompat_ActionBar_TabText:I = 0x7f1001a3

.field public static final Widget_AppCompat_ActionBar_TabView:I = 0x7f1001a4

.field public static final Widget_AppCompat_ActionButton:I = 0x7f1001a5

.field public static final Widget_AppCompat_ActionButton_CloseMode:I = 0x7f1001a6

.field public static final Widget_AppCompat_ActionButton_Overflow:I = 0x7f1001a7

.field public static final Widget_AppCompat_ActionMode:I = 0x7f1001a8

.field public static final Widget_AppCompat_ActivityChooserView:I = 0x7f1001a9

.field public static final Widget_AppCompat_AutoCompleteTextView:I = 0x7f1001aa

.field public static final Widget_AppCompat_CompoundButton_Switch:I = 0x7f1001b5

.field public static final Widget_AppCompat_DrawerArrowToggle:I = 0x7f1001b6

.field public static final Widget_AppCompat_DropDownItem_Spinner:I = 0x7f1001b7

.field public static final Widget_AppCompat_EditText:I = 0x7f1001b8

.field public static final Widget_AppCompat_Light_ActionBar:I = 0x7f1001ba

.field public static final Widget_AppCompat_Light_ActionBar_Solid:I = 0x7f1001bb

.field public static final Widget_AppCompat_Light_ActionBar_Solid_Inverse:I = 0x7f1001bc

.field public static final Widget_AppCompat_Light_ActionBar_TabBar:I = 0x7f1001bd

.field public static final Widget_AppCompat_Light_ActionBar_TabBar_Inverse:I = 0x7f1001be

.field public static final Widget_AppCompat_Light_ActionBar_TabText:I = 0x7f1001bf

.field public static final Widget_AppCompat_Light_ActionBar_TabText_Inverse:I = 0x7f1001c0

.field public static final Widget_AppCompat_Light_ActionBar_TabView:I = 0x7f1001c1

.field public static final Widget_AppCompat_Light_ActionBar_TabView_Inverse:I = 0x7f1001c2

.field public static final Widget_AppCompat_Light_ActionButton:I = 0x7f1001c3

.field public static final Widget_AppCompat_Light_ActionButton_CloseMode:I = 0x7f1001c4

.field public static final Widget_AppCompat_Light_ActionButton_Overflow:I = 0x7f1001c5

.field public static final Widget_AppCompat_Light_ActionMode_Inverse:I = 0x7f1001c6

.field public static final Widget_AppCompat_Light_ActivityChooserView:I = 0x7f1001c7

.field public static final Widget_AppCompat_Light_AutoCompleteTextView:I = 0x7f1001c8

.field public static final Widget_AppCompat_Light_DropDownItem_Spinner:I = 0x7f1001c9

.field public static final Widget_AppCompat_Light_ListPopupWindow:I = 0x7f1001ca

.field public static final Widget_AppCompat_Light_ListView_DropDown:I = 0x7f1001cb

.field public static final Widget_AppCompat_Light_PopupMenu:I = 0x7f1001cc

.field public static final Widget_AppCompat_Light_PopupMenu_Overflow:I = 0x7f1001cd

.field public static final Widget_AppCompat_Light_SearchView:I = 0x7f1001ce

.field public static final Widget_AppCompat_Light_Spinner_DropDown_ActionBar:I = 0x7f1001cf

.field public static final Widget_AppCompat_ListPopupWindow:I = 0x7f1001d1

.field public static final Widget_AppCompat_ListView_DropDown:I = 0x7f1001d3

.field public static final Widget_AppCompat_ListView_Menu:I = 0x7f1001d4

.field public static final Widget_AppCompat_PopupMenu:I = 0x7f1001d5

.field public static final Widget_AppCompat_PopupMenu_Overflow:I = 0x7f1001d6

.field public static final Widget_AppCompat_PopupWindow:I = 0x7f1001d7

.field public static final Widget_AppCompat_ProgressBar:I = 0x7f1001d8

.field public static final Widget_AppCompat_ProgressBar_Horizontal:I = 0x7f1001d9

.field public static final Widget_AppCompat_SearchView:I = 0x7f1001dd

.field public static final Widget_AppCompat_Spinner:I = 0x7f1001e1

.field public static final Widget_AppCompat_Spinner_DropDown:I = 0x7f1001e2

.field public static final Widget_AppCompat_Spinner_DropDown_ActionBar:I = 0x7f1001e3

.field public static final Widget_AppCompat_Toolbar:I = 0x7f1001e6

.field public static final Widget_AppCompat_Toolbar_Button_Navigation:I = 0x7f1001e7


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
