.class public final Lcom/pnikosis/materialishprogress/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final abc_background_cache_hint_selector_material_dark:I = 0x7f060000

.field public static final abc_background_cache_hint_selector_material_light:I = 0x7f060001

.field public static final abc_input_method_navigation_guard:I = 0x7f060007

.field public static final abc_primary_text_disable_only_material_dark:I = 0x7f060008

.field public static final abc_primary_text_disable_only_material_light:I = 0x7f060009

.field public static final abc_primary_text_material_dark:I = 0x7f06000a

.field public static final abc_primary_text_material_light:I = 0x7f06000b

.field public static final abc_search_url_text:I = 0x7f06000c

.field public static final abc_search_url_text_normal:I = 0x7f06000d

.field public static final abc_search_url_text_pressed:I = 0x7f06000e

.field public static final abc_search_url_text_selected:I = 0x7f06000f

.field public static final abc_secondary_text_material_dark:I = 0x7f060010

.field public static final abc_secondary_text_material_light:I = 0x7f060011

.field public static final accent_material_dark:I = 0x7f060018

.field public static final accent_material_light:I = 0x7f060019

.field public static final background_floating_material_dark:I = 0x7f06001a

.field public static final background_floating_material_light:I = 0x7f06001b

.field public static final background_material_dark:I = 0x7f06001c

.field public static final background_material_light:I = 0x7f06001d

.field public static final bright_foreground_disabled_material_dark:I = 0x7f060024

.field public static final bright_foreground_disabled_material_light:I = 0x7f060025

.field public static final bright_foreground_inverse_material_dark:I = 0x7f060026

.field public static final bright_foreground_inverse_material_light:I = 0x7f060027

.field public static final bright_foreground_material_dark:I = 0x7f060028

.field public static final bright_foreground_material_light:I = 0x7f060029

.field public static final button_material_dark:I = 0x7f06002a

.field public static final button_material_light:I = 0x7f06002b

.field public static final dim_foreground_disabled_material_dark:I = 0x7f060047

.field public static final dim_foreground_disabled_material_light:I = 0x7f060048

.field public static final dim_foreground_material_dark:I = 0x7f060049

.field public static final dim_foreground_material_light:I = 0x7f06004a

.field public static final highlighted_text_material_dark:I = 0x7f060060

.field public static final highlighted_text_material_light:I = 0x7f060061

.field public static final material_blue_grey_800:I = 0x7f060062

.field public static final material_blue_grey_900:I = 0x7f060063

.field public static final material_blue_grey_950:I = 0x7f060064

.field public static final material_deep_teal_200:I = 0x7f060065

.field public static final material_deep_teal_500:I = 0x7f060066

.field public static final primary_dark_material_dark:I = 0x7f06008b

.field public static final primary_dark_material_light:I = 0x7f06008c

.field public static final primary_material_dark:I = 0x7f06008d

.field public static final primary_material_light:I = 0x7f06008e

.field public static final primary_text_default_material_dark:I = 0x7f06008f

.field public static final primary_text_default_material_light:I = 0x7f060090

.field public static final primary_text_disabled_material_dark:I = 0x7f060091

.field public static final primary_text_disabled_material_light:I = 0x7f060092

.field public static final ripple_material_dark:I = 0x7f060098

.field public static final ripple_material_light:I = 0x7f060099

.field public static final secondary_text_default_material_dark:I = 0x7f06009b

.field public static final secondary_text_default_material_light:I = 0x7f06009c

.field public static final secondary_text_disabled_material_dark:I = 0x7f06009d

.field public static final secondary_text_disabled_material_light:I = 0x7f06009e

.field public static final switch_thumb_normal_material_dark:I = 0x7f0600ac

.field public static final switch_thumb_normal_material_light:I = 0x7f0600ad


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
