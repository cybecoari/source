.class public final Lcom/pnikosis/materialishprogress/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final actionBarDivider:I = 0x7f040000

.field public static final actionBarItemBackground:I = 0x7f040001

.field public static final actionBarPopupTheme:I = 0x7f040002

.field public static final actionBarSize:I = 0x7f040003

.field public static final actionBarSplitStyle:I = 0x7f040004

.field public static final actionBarStyle:I = 0x7f040005

.field public static final actionBarTabBarStyle:I = 0x7f040006

.field public static final actionBarTabStyle:I = 0x7f040007

.field public static final actionBarTabTextStyle:I = 0x7f040008

.field public static final actionBarTheme:I = 0x7f040009

.field public static final actionBarWidgetTheme:I = 0x7f04000a

.field public static final actionButtonStyle:I = 0x7f04000b

.field public static final actionDropDownStyle:I = 0x7f04000c

.field public static final actionLayout:I = 0x7f04000d

.field public static final actionMenuTextAppearance:I = 0x7f04000e

.field public static final actionMenuTextColor:I = 0x7f04000f

.field public static final actionModeBackground:I = 0x7f040010

.field public static final actionModeCloseButtonStyle:I = 0x7f040011

.field public static final actionModeCloseDrawable:I = 0x7f040012

.field public static final actionModeCopyDrawable:I = 0x7f040013

.field public static final actionModeCutDrawable:I = 0x7f040014

.field public static final actionModeFindDrawable:I = 0x7f040015

.field public static final actionModePasteDrawable:I = 0x7f040016

.field public static final actionModePopupWindowStyle:I = 0x7f040017

.field public static final actionModeSelectAllDrawable:I = 0x7f040018

.field public static final actionModeShareDrawable:I = 0x7f040019

.field public static final actionModeSplitBackground:I = 0x7f04001a

.field public static final actionModeStyle:I = 0x7f04001b

.field public static final actionModeWebSearchDrawable:I = 0x7f04001c

.field public static final actionOverflowButtonStyle:I = 0x7f04001d

.field public static final actionOverflowMenuStyle:I = 0x7f04001e

.field public static final actionProviderClass:I = 0x7f04001f

.field public static final actionViewClass:I = 0x7f040020

.field public static final activityChooserViewStyle:I = 0x7f040021

.field public static final background:I = 0x7f040035

.field public static final backgroundSplit:I = 0x7f040036

.field public static final backgroundStacked:I = 0x7f040037

.field public static final barColor:I = 0x7f04003a

.field public static final barSpinCycleTime:I = 0x7f04003c

.field public static final barWidth:I = 0x7f04003d

.field public static final buttonBarButtonStyle:I = 0x7f040055

.field public static final buttonBarStyle:I = 0x7f040059

.field public static final buttonGravity:I = 0x7f04005a

.field public static final circleRadius:I = 0x7f040082

.field public static final closeIcon:I = 0x7f040083

.field public static final closeItemLayout:I = 0x7f04008a

.field public static final collapseIcon:I = 0x7f04008c

.field public static final color:I = 0x7f04008f

.field public static final colorAccent:I = 0x7f040090

.field public static final colorButtonNormal:I = 0x7f040092

.field public static final colorControlActivated:I = 0x7f040093

.field public static final colorControlHighlight:I = 0x7f040094

.field public static final colorControlNormal:I = 0x7f040095

.field public static final colorPrimary:I = 0x7f040097

.field public static final colorPrimaryDark:I = 0x7f040098

.field public static final colorSwitchThumbNormal:I = 0x7f04009a

.field public static final commitIcon:I = 0x7f04009b

.field public static final contentInsetEnd:I = 0x7f0400a0

.field public static final contentInsetLeft:I = 0x7f0400a2

.field public static final contentInsetRight:I = 0x7f0400a3

.field public static final contentInsetStart:I = 0x7f0400a4

.field public static final customNavigationLayout:I = 0x7f0400b3

.field public static final displayOptions:I = 0x7f0400c0

.field public static final divider:I = 0x7f0400c1

.field public static final dividerHorizontal:I = 0x7f0400c2

.field public static final dividerPadding:I = 0x7f0400c3

.field public static final dividerVertical:I = 0x7f0400c4

.field public static final drawableSize:I = 0x7f0400c5

.field public static final drawerArrowStyle:I = 0x7f0400c6

.field public static final dropDownListViewStyle:I = 0x7f0400c7

.field public static final dropdownListPreferredItemHeight:I = 0x7f0400c8

.field public static final editTextBackground:I = 0x7f0400ca

.field public static final editTextColor:I = 0x7f0400cb

.field public static final elevation:I = 0x7f0400ce

.field public static final expandActivityOverflowButtonDrawable:I = 0x7f0400d7

.field public static final fillRadius:I = 0x7f0400eb

.field public static final gapBetweenBars:I = 0x7f0400fc

.field public static final goIcon:I = 0x7f0400fd

.field public static final height:I = 0x7f0400ff

.field public static final hideOnContentScroll:I = 0x7f040104

.field public static final homeAsUpIndicator:I = 0x7f040109

.field public static final homeLayout:I = 0x7f04010a

.field public static final icon:I = 0x7f04010c

.field public static final iconifiedByDefault:I = 0x7f040115

.field public static final indeterminateProgressStyle:I = 0x7f040117

.field public static final initialActivityCount:I = 0x7f040118

.field public static final isLightTheme:I = 0x7f04011b

.field public static final itemPadding:I = 0x7f040123

.field public static final layout:I = 0x7f04012d

.field public static final listChoiceBackgroundIndicator:I = 0x7f04016e

.field public static final listPopupWindowStyle:I = 0x7f040173

.field public static final listPreferredItemHeight:I = 0x7f040174

.field public static final listPreferredItemHeightLarge:I = 0x7f040175

.field public static final listPreferredItemHeightSmall:I = 0x7f040176

.field public static final listPreferredItemPaddingLeft:I = 0x7f040177

.field public static final listPreferredItemPaddingRight:I = 0x7f040178

.field public static final logo:I = 0x7f040179

.field public static final maxButtonHeight:I = 0x7f04017e

.field public static final measureWithLargestChild:I = 0x7f040182

.field public static final navigationContentDescription:I = 0x7f040186

.field public static final navigationIcon:I = 0x7f040187

.field public static final navigationMode:I = 0x7f040188

.field public static final overlapAnchor:I = 0x7f04018e

.field public static final paddingEnd:I = 0x7f040190

.field public static final paddingStart:I = 0x7f040191

.field public static final panelBackground:I = 0x7f040193

.field public static final panelMenuListTheme:I = 0x7f040194

.field public static final panelMenuListWidth:I = 0x7f040195

.field public static final popupMenuStyle:I = 0x7f04019e

.field public static final popupTheme:I = 0x7f04019f

.field public static final popupWindowStyle:I = 0x7f0401a0

.field public static final preserveIconSpacing:I = 0x7f0401b0

.field public static final progressBarPadding:I = 0x7f0401b2

.field public static final progressBarStyle:I = 0x7f0401b3

.field public static final progressIndeterminate:I = 0x7f0401b4

.field public static final queryBackground:I = 0x7f0401b5

.field public static final queryHint:I = 0x7f0401b6

.field public static final rimColor:I = 0x7f0401bc

.field public static final rimWidth:I = 0x7f0401bd

.field public static final searchIcon:I = 0x7f0401c5

.field public static final searchViewStyle:I = 0x7f0401c6

.field public static final selectableItemBackground:I = 0x7f0401cb

.field public static final selectableItemBackgroundBorderless:I = 0x7f0401cc

.field public static final showAsAction:I = 0x7f0401ce

.field public static final showDividers:I = 0x7f0401cf

.field public static final showText:I = 0x7f0401d2

.field public static final spinBars:I = 0x7f0401db

.field public static final spinSpeed:I = 0x7f0401dc

.field public static final spinnerDropDownItemStyle:I = 0x7f0401dd

.field public static final spinnerStyle:I = 0x7f0401de

.field public static final splitTrack:I = 0x7f0401df

.field public static final state_above_anchor:I = 0x7f0401e2

.field public static final submitBackground:I = 0x7f0401ec

.field public static final subtitle:I = 0x7f0401ed

.field public static final subtitleTextAppearance:I = 0x7f0401ee

.field public static final subtitleTextStyle:I = 0x7f0401f0

.field public static final suggestionRowLayout:I = 0x7f0401f1

.field public static final switchMinWidth:I = 0x7f0401f5

.field public static final switchPadding:I = 0x7f0401f6

.field public static final switchStyle:I = 0x7f0401f9

.field public static final switchTextAppearance:I = 0x7f0401fa

.field public static final textAllCaps:I = 0x7f040217

.field public static final textAppearanceLargePopupMenu:I = 0x7f040222

.field public static final textAppearanceListItem:I = 0x7f040223

.field public static final textAppearanceListItemSmall:I = 0x7f040225

.field public static final textAppearanceSearchResultSubtitle:I = 0x7f040228

.field public static final textAppearanceSearchResultTitle:I = 0x7f040229

.field public static final textAppearanceSmallPopupMenu:I = 0x7f04022a

.field public static final textColorSearchUrl:I = 0x7f04022e

.field public static final theme:I = 0x7f040232

.field public static final thickness:I = 0x7f040233

.field public static final thumbTextPadding:I = 0x7f040234

.field public static final title:I = 0x7f04023c

.field public static final titleMarginBottom:I = 0x7f04023f

.field public static final titleMarginEnd:I = 0x7f040240

.field public static final titleMarginStart:I = 0x7f040241

.field public static final titleMarginTop:I = 0x7f040242

.field public static final titleMargins:I = 0x7f040243

.field public static final titleTextAppearance:I = 0x7f040244

.field public static final titleTextStyle:I = 0x7f040246

.field public static final toolbarNavigationButtonStyle:I = 0x7f040249

.field public static final toolbarStyle:I = 0x7f04024a

.field public static final track:I = 0x7f04024e

.field public static final voiceIcon:I = 0x7f040254

.field public static final windowActionBar:I = 0x7f040256

.field public static final windowActionBarOverlay:I = 0x7f040257

.field public static final windowActionModeOverlay:I = 0x7f040258

.field public static final windowFixedHeightMajor:I = 0x7f040259

.field public static final windowFixedHeightMinor:I = 0x7f04025a

.field public static final windowFixedWidthMajor:I = 0x7f04025b

.field public static final windowFixedWidthMinor:I = 0x7f04025c


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
