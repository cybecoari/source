.class public final Lcom/pnikosis/materialishprogress/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final ActionBar:[I

.field public static final ActionBarLayout:[I

.field public static final ActionBarLayout_android_layout_gravity:I = 0x0

.field public static final ActionBar_background:I = 0x0

.field public static final ActionBar_backgroundSplit:I = 0x1

.field public static final ActionBar_backgroundStacked:I = 0x2

.field public static final ActionBar_contentInsetEnd:I = 0x3

.field public static final ActionBar_contentInsetEndWithActions:I = 0x4

.field public static final ActionBar_contentInsetLeft:I = 0x5

.field public static final ActionBar_contentInsetRight:I = 0x6

.field public static final ActionBar_contentInsetStart:I = 0x7

.field public static final ActionBar_contentInsetStartWithNavigation:I = 0x8

.field public static final ActionBar_customNavigationLayout:I = 0x9

.field public static final ActionBar_displayOptions:I = 0xa

.field public static final ActionBar_divider:I = 0xb

.field public static final ActionBar_elevation:I = 0xc

.field public static final ActionBar_height:I = 0xd

.field public static final ActionBar_hideOnContentScroll:I = 0xe

.field public static final ActionBar_homeAsUpIndicator:I = 0xf

.field public static final ActionBar_homeLayout:I = 0x10

.field public static final ActionBar_icon:I = 0x11

.field public static final ActionBar_indeterminateProgressStyle:I = 0x12

.field public static final ActionBar_itemPadding:I = 0x13

.field public static final ActionBar_logo:I = 0x14

.field public static final ActionBar_navigationMode:I = 0x15

.field public static final ActionBar_popupTheme:I = 0x16

.field public static final ActionBar_progressBarPadding:I = 0x17

.field public static final ActionBar_progressBarStyle:I = 0x18

.field public static final ActionBar_subtitle:I = 0x19

.field public static final ActionBar_subtitleTextStyle:I = 0x1a

.field public static final ActionBar_title:I = 0x1b

.field public static final ActionBar_titleTextStyle:I = 0x1c

.field public static final ActionMenuItemView:[I

.field public static final ActionMenuItemView_android_minWidth:I = 0x0

.field public static final ActionMenuView:[I

.field public static final ActionMode:[I

.field public static final ActionMode_background:I = 0x0

.field public static final ActionMode_backgroundSplit:I = 0x1

.field public static final ActionMode_closeItemLayout:I = 0x2

.field public static final ActionMode_height:I = 0x3

.field public static final ActionMode_subtitleTextStyle:I = 0x4

.field public static final ActionMode_titleTextStyle:I = 0x5

.field public static final ActivityChooserView:[I

.field public static final ActivityChooserView_expandActivityOverflowButtonDrawable:I = 0x0

.field public static final ActivityChooserView_initialActivityCount:I = 0x1

.field public static final DrawerArrowToggle:[I

.field public static final DrawerArrowToggle_arrowHeadLength:I = 0x0

.field public static final DrawerArrowToggle_arrowShaftLength:I = 0x1

.field public static final DrawerArrowToggle_barLength:I = 0x2

.field public static final DrawerArrowToggle_color:I = 0x3

.field public static final DrawerArrowToggle_drawableSize:I = 0x4

.field public static final DrawerArrowToggle_gapBetweenBars:I = 0x5

.field public static final DrawerArrowToggle_spinBars:I = 0x6

.field public static final DrawerArrowToggle_thickness:I = 0x7

.field public static final LinearLayoutCompat:[I

.field public static final LinearLayoutCompat_Layout:[I

.field public static final LinearLayoutCompat_Layout_android_layout_gravity:I = 0x0

.field public static final LinearLayoutCompat_Layout_android_layout_height:I = 0x2

.field public static final LinearLayoutCompat_Layout_android_layout_weight:I = 0x3

.field public static final LinearLayoutCompat_Layout_android_layout_width:I = 0x1

.field public static final LinearLayoutCompat_android_baselineAligned:I = 0x2

.field public static final LinearLayoutCompat_android_baselineAlignedChildIndex:I = 0x3

.field public static final LinearLayoutCompat_android_gravity:I = 0x0

.field public static final LinearLayoutCompat_android_orientation:I = 0x1

.field public static final LinearLayoutCompat_android_weightSum:I = 0x4

.field public static final LinearLayoutCompat_divider:I = 0x5

.field public static final LinearLayoutCompat_dividerPadding:I = 0x6

.field public static final LinearLayoutCompat_measureWithLargestChild:I = 0x7

.field public static final LinearLayoutCompat_showDividers:I = 0x8

.field public static final ListPopupWindow:[I

.field public static final ListPopupWindow_android_dropDownHorizontalOffset:I = 0x0

.field public static final ListPopupWindow_android_dropDownVerticalOffset:I = 0x1

.field public static final MenuGroup:[I

.field public static final MenuGroup_android_checkableBehavior:I = 0x5

.field public static final MenuGroup_android_enabled:I = 0x0

.field public static final MenuGroup_android_id:I = 0x1

.field public static final MenuGroup_android_menuCategory:I = 0x3

.field public static final MenuGroup_android_orderInCategory:I = 0x4

.field public static final MenuGroup_android_visible:I = 0x2

.field public static final MenuItem:[I

.field public static final MenuItem_actionLayout:I = 0xd

.field public static final MenuItem_actionProviderClass:I = 0xe

.field public static final MenuItem_actionViewClass:I = 0xf

.field public static final MenuItem_alphabeticModifiers:I = 0x10

.field public static final MenuItem_android_alphabeticShortcut:I = 0x9

.field public static final MenuItem_android_checkable:I = 0xb

.field public static final MenuItem_android_checked:I = 0x3

.field public static final MenuItem_android_enabled:I = 0x1

.field public static final MenuItem_android_icon:I = 0x0

.field public static final MenuItem_android_id:I = 0x2

.field public static final MenuItem_android_menuCategory:I = 0x5

.field public static final MenuItem_android_numericShortcut:I = 0xa

.field public static final MenuItem_android_onClick:I = 0xc

.field public static final MenuItem_android_orderInCategory:I = 0x6

.field public static final MenuItem_android_title:I = 0x7

.field public static final MenuItem_android_titleCondensed:I = 0x8

.field public static final MenuItem_android_visible:I = 0x4

.field public static final MenuItem_contentDescription:I = 0x11

.field public static final MenuItem_iconTint:I = 0x12

.field public static final MenuItem_iconTintMode:I = 0x13

.field public static final MenuItem_numericModifiers:I = 0x14

.field public static final MenuItem_showAsAction:I = 0x15

.field public static final MenuItem_tooltipText:I = 0x16

.field public static final MenuView:[I

.field public static final MenuView_android_headerBackground:I = 0x4

.field public static final MenuView_android_horizontalDivider:I = 0x2

.field public static final MenuView_android_itemBackground:I = 0x5

.field public static final MenuView_android_itemIconDisabledAlpha:I = 0x6

.field public static final MenuView_android_itemTextAppearance:I = 0x1

.field public static final MenuView_android_verticalDivider:I = 0x3

.field public static final MenuView_android_windowAnimationStyle:I = 0x0

.field public static final MenuView_preserveIconSpacing:I = 0x7

.field public static final MenuView_subMenuArrow:I = 0x8

.field public static final PopupWindow:[I

.field public static final PopupWindowBackgroundState:[I

.field public static final PopupWindowBackgroundState_state_above_anchor:I = 0x0

.field public static final PopupWindow_android_popupAnimationStyle:I = 0x1

.field public static final PopupWindow_android_popupBackground:I = 0x0

.field public static final PopupWindow_overlapAnchor:I = 0x2

.field public static final ProgressWheel:[I

.field public static final ProgressWheel_barColor:I = 0x0

.field public static final ProgressWheel_barSpinCycleTime:I = 0x1

.field public static final ProgressWheel_barWidth:I = 0x2

.field public static final ProgressWheel_circleRadius:I = 0x3

.field public static final ProgressWheel_fillRadius:I = 0x4

.field public static final ProgressWheel_progressIndeterminate:I = 0x5

.field public static final ProgressWheel_rimColor:I = 0x6

.field public static final ProgressWheel_rimWidth:I = 0x7

.field public static final ProgressWheel_spinSpeed:I = 0x8

.field public static final SearchView:[I

.field public static final SearchView_android_focusable:I = 0x0

.field public static final SearchView_android_imeOptions:I = 0x3

.field public static final SearchView_android_inputType:I = 0x2

.field public static final SearchView_android_maxWidth:I = 0x1

.field public static final SearchView_closeIcon:I = 0x4

.field public static final SearchView_commitIcon:I = 0x5

.field public static final SearchView_defaultQueryHint:I = 0x6

.field public static final SearchView_goIcon:I = 0x7

.field public static final SearchView_iconifiedByDefault:I = 0x8

.field public static final SearchView_layout:I = 0x9

.field public static final SearchView_queryBackground:I = 0xa

.field public static final SearchView_queryHint:I = 0xb

.field public static final SearchView_searchHintIcon:I = 0xc

.field public static final SearchView_searchIcon:I = 0xd

.field public static final SearchView_submitBackground:I = 0xe

.field public static final SearchView_suggestionRowLayout:I = 0xf

.field public static final SearchView_voiceIcon:I = 0x10

.field public static final Spinner:[I

.field public static final Spinner_android_dropDownWidth:I = 0x3

.field public static final Spinner_android_entries:I = 0x0

.field public static final Spinner_android_popupBackground:I = 0x1

.field public static final Spinner_android_prompt:I = 0x2

.field public static final Spinner_popupTheme:I = 0x4

.field public static final SwitchCompat:[I

.field public static final SwitchCompat_android_textOff:I = 0x1

.field public static final SwitchCompat_android_textOn:I = 0x0

.field public static final SwitchCompat_android_thumb:I = 0x2

.field public static final SwitchCompat_showText:I = 0x3

.field public static final SwitchCompat_splitTrack:I = 0x4

.field public static final SwitchCompat_switchMinWidth:I = 0x5

.field public static final SwitchCompat_switchPadding:I = 0x6

.field public static final SwitchCompat_switchTextAppearance:I = 0x7

.field public static final SwitchCompat_thumbTextPadding:I = 0x8

.field public static final SwitchCompat_thumbTint:I = 0x9

.field public static final SwitchCompat_thumbTintMode:I = 0xa

.field public static final SwitchCompat_track:I = 0xb

.field public static final SwitchCompat_trackTint:I = 0xc

.field public static final SwitchCompat_trackTintMode:I = 0xd

.field public static final Toolbar:[I

.field public static final Toolbar_android_gravity:I = 0x0

.field public static final Toolbar_android_minHeight:I = 0x1

.field public static final Toolbar_buttonGravity:I = 0x2

.field public static final Toolbar_collapseContentDescription:I = 0x3

.field public static final Toolbar_collapseIcon:I = 0x4

.field public static final Toolbar_contentInsetEnd:I = 0x5

.field public static final Toolbar_contentInsetEndWithActions:I = 0x6

.field public static final Toolbar_contentInsetLeft:I = 0x7

.field public static final Toolbar_contentInsetRight:I = 0x8

.field public static final Toolbar_contentInsetStart:I = 0x9

.field public static final Toolbar_contentInsetStartWithNavigation:I = 0xa

.field public static final Toolbar_logo:I = 0xb

.field public static final Toolbar_logoDescription:I = 0xc

.field public static final Toolbar_maxButtonHeight:I = 0xd

.field public static final Toolbar_navigationContentDescription:I = 0xe

.field public static final Toolbar_navigationIcon:I = 0xf

.field public static final Toolbar_popupTheme:I = 0x10

.field public static final Toolbar_subtitle:I = 0x11

.field public static final Toolbar_subtitleTextAppearance:I = 0x12

.field public static final Toolbar_subtitleTextColor:I = 0x13

.field public static final Toolbar_title:I = 0x14

.field public static final Toolbar_titleMargin:I = 0x15

.field public static final Toolbar_titleMarginBottom:I = 0x16

.field public static final Toolbar_titleMarginEnd:I = 0x17

.field public static final Toolbar_titleMarginStart:I = 0x18

.field public static final Toolbar_titleMarginTop:I = 0x19

.field public static final Toolbar_titleMargins:I = 0x1a

.field public static final Toolbar_titleTextAppearance:I = 0x1b

.field public static final Toolbar_titleTextColor:I = 0x1c

.field public static final View:[I

.field public static final ViewStubCompat:[I

.field public static final ViewStubCompat_android_id:I = 0x0

.field public static final ViewStubCompat_android_inflatedId:I = 0x2

.field public static final ViewStubCompat_android_layout:I = 0x1

.field public static final View_android_focusable:I = 0x1

.field public static final View_android_theme:I = 0x0

.field public static final View_paddingEnd:I = 0x2

.field public static final View_paddingStart:I = 0x3

.field public static final View_theme:I = 0x4


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    const/16 v0, 0x1d

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    sput-object v1, Lcom/pnikosis/materialishprogress/R$styleable;->ActionBar:[I

    const/4 v1, 0x1

    new-array v2, v1, [I

    const v3, 0x10100b3

    const/4 v4, 0x0

    aput v3, v2, v4

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->ActionBarLayout:[I

    new-array v2, v1, [I

    const v3, 0x101013f

    aput v3, v2, v4

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->ActionMenuItemView:[I

    new-array v2, v4, [I

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->ActionMenuView:[I

    const/4 v2, 0x6

    new-array v3, v2, [I

    fill-array-data v3, :array_1

    sput-object v3, Lcom/pnikosis/materialishprogress/R$styleable;->ActionMode:[I

    const/4 v3, 0x2

    new-array v5, v3, [I

    fill-array-data v5, :array_2

    sput-object v5, Lcom/pnikosis/materialishprogress/R$styleable;->ActivityChooserView:[I

    const/16 v5, 0x8

    new-array v5, v5, [I

    fill-array-data v5, :array_3

    sput-object v5, Lcom/pnikosis/materialishprogress/R$styleable;->DrawerArrowToggle:[I

    const/16 v5, 0x9

    new-array v6, v5, [I

    fill-array-data v6, :array_4

    sput-object v6, Lcom/pnikosis/materialishprogress/R$styleable;->LinearLayoutCompat:[I

    const/4 v6, 0x4

    new-array v6, v6, [I

    fill-array-data v6, :array_5

    sput-object v6, Lcom/pnikosis/materialishprogress/R$styleable;->LinearLayoutCompat_Layout:[I

    new-array v3, v3, [I

    fill-array-data v3, :array_6

    sput-object v3, Lcom/pnikosis/materialishprogress/R$styleable;->ListPopupWindow:[I

    new-array v2, v2, [I

    fill-array-data v2, :array_7

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->MenuGroup:[I

    const/16 v2, 0x17

    new-array v2, v2, [I

    fill-array-data v2, :array_8

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->MenuItem:[I

    new-array v2, v5, [I

    fill-array-data v2, :array_9

    sput-object v2, Lcom/pnikosis/materialishprogress/R$styleable;->MenuView:[I

    const/4 v2, 0x3

    new-array v3, v2, [I

    fill-array-data v3, :array_a

    sput-object v3, Lcom/pnikosis/materialishprogress/R$styleable;->PopupWindow:[I

    new-array v1, v1, [I

    const v3, 0x7f0401e2

    aput v3, v1, v4

    sput-object v1, Lcom/pnikosis/materialishprogress/R$styleable;->PopupWindowBackgroundState:[I

    new-array v1, v5, [I

    fill-array-data v1, :array_b

    sput-object v1, Lcom/pnikosis/materialishprogress/R$styleable;->ProgressWheel:[I

    const/16 v1, 0x11

    new-array v1, v1, [I

    fill-array-data v1, :array_c

    sput-object v1, Lcom/pnikosis/materialishprogress/R$styleable;->SearchView:[I

    const/4 v1, 0x5

    new-array v3, v1, [I

    fill-array-data v3, :array_d

    sput-object v3, Lcom/pnikosis/materialishprogress/R$styleable;->Spinner:[I

    const/16 v3, 0xe

    new-array v3, v3, [I

    fill-array-data v3, :array_e

    sput-object v3, Lcom/pnikosis/materialishprogress/R$styleable;->SwitchCompat:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_f

    sput-object v0, Lcom/pnikosis/materialishprogress/R$styleable;->Toolbar:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_10

    sput-object v0, Lcom/pnikosis/materialishprogress/R$styleable;->View:[I

    new-array v0, v2, [I

    fill-array-data v0, :array_11

    sput-object v0, Lcom/pnikosis/materialishprogress/R$styleable;->ViewStubCompat:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x7f040035
        0x7f040036
        0x7f040037
        0x7f0400a0
        0x7f0400a1
        0x7f0400a2
        0x7f0400a3
        0x7f0400a4
        0x7f0400a5
        0x7f0400b3
        0x7f0400c0
        0x7f0400c1
        0x7f0400ce
        0x7f0400ff
        0x7f040104
        0x7f040109
        0x7f04010a
        0x7f04010c
        0x7f040117
        0x7f040123
        0x7f040179
        0x7f040188
        0x7f04019f
        0x7f0401b2
        0x7f0401b3
        0x7f0401ed
        0x7f0401f0
        0x7f04023c
        0x7f040246
    .end array-data

    :array_1
    .array-data 4
        0x7f040035
        0x7f040036
        0x7f04008a
        0x7f0400ff
        0x7f0401f0
        0x7f040246
    .end array-data

    :array_2
    .array-data 4
        0x7f0400d7
        0x7f040118
    .end array-data

    :array_3
    .array-data 4
        0x7f04002d
        0x7f04002e
        0x7f04003b
        0x7f04008f
        0x7f0400c5
        0x7f0400fc
        0x7f0401db
        0x7f040233
    .end array-data

    :array_4
    .array-data 4
        0x10100af
        0x10100c4
        0x1010126
        0x1010127
        0x1010128
        0x7f0400c1
        0x7f0400c3
        0x7f040182
        0x7f0401cf
    .end array-data

    :array_5
    .array-data 4
        0x10100b3
        0x10100f4
        0x10100f5
        0x1010181
    .end array-data

    :array_6
    .array-data 4
        0x10102ac
        0x10102ad
    .end array-data

    :array_7
    .array-data 4
        0x101000e
        0x10100d0
        0x1010194
        0x10101de
        0x10101df
        0x10101e0
    .end array-data

    :array_8
    .array-data 4
        0x1010002
        0x101000e
        0x10100d0
        0x1010106
        0x1010194
        0x10101de
        0x10101df
        0x10101e1
        0x10101e2
        0x10101e3
        0x10101e4
        0x10101e5
        0x101026f
        0x7f04000d
        0x7f04001f
        0x7f040020
        0x7f04002c
        0x7f04009f
        0x7f040113
        0x7f040114
        0x7f04018b
        0x7f0401ce
        0x7f04024d
    .end array-data

    :array_9
    .array-data 4
        0x10100ae
        0x101012c
        0x101012d
        0x101012e
        0x101012f
        0x1010130
        0x1010131
        0x7f0401b0
        0x7f0401eb
    .end array-data

    :array_a
    .array-data 4
        0x1010176
        0x10102c9
        0x7f04018e
    .end array-data

    :array_b
    .array-data 4
        0x7f04003a
        0x7f04003c
        0x7f04003d
        0x7f040082
        0x7f0400eb
        0x7f0401b4
        0x7f0401bc
        0x7f0401bd
        0x7f0401dc
    .end array-data

    :array_c
    .array-data 4
        0x10100da
        0x101011f
        0x1010220
        0x1010264
        0x7f040083
        0x7f04009b
        0x7f0400b4
        0x7f0400fd
        0x7f040115
        0x7f04012d
        0x7f0401b5
        0x7f0401b6
        0x7f0401c4
        0x7f0401c5
        0x7f0401ec
        0x7f0401f1
        0x7f040254
    .end array-data

    :array_d
    .array-data 4
        0x10100b2
        0x1010176
        0x101017b
        0x1010262
        0x7f04019f
    .end array-data

    :array_e
    .array-data 4
        0x1010124
        0x1010125
        0x1010142
        0x7f0401d2
        0x7f0401df
        0x7f0401f5
        0x7f0401f6
        0x7f0401fa
        0x7f040234
        0x7f040235
        0x7f040236
        0x7f04024e
        0x7f04024f
        0x7f040250
    .end array-data

    :array_f
    .array-data 4
        0x10100af
        0x1010140
        0x7f04005a
        0x7f04008b
        0x7f04008c
        0x7f0400a0
        0x7f0400a1
        0x7f0400a2
        0x7f0400a3
        0x7f0400a4
        0x7f0400a5
        0x7f040179
        0x7f04017a
        0x7f04017e
        0x7f040186
        0x7f040187
        0x7f04019f
        0x7f0401ed
        0x7f0401ee
        0x7f0401ef
        0x7f04023c
        0x7f04023e
        0x7f04023f
        0x7f040240
        0x7f040241
        0x7f040242
        0x7f040243
        0x7f040244
        0x7f040245
    .end array-data

    :array_10
    .array-data 4
        0x1010000
        0x10100da
        0x7f040190
        0x7f040191
        0x7f040232
    .end array-data

    :array_11
    .array-data 4
        0x10100d0
        0x10100f2
        0x10100f3
    .end array-data
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
