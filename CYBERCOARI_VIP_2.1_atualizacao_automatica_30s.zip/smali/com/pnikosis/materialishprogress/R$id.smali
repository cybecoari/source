.class public final Lcom/pnikosis/materialishprogress/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_bar:I = 0x7f09000b

.field public static final action_bar_activity_content:I = 0x7f09000c

.field public static final action_bar_container:I = 0x7f09000d

.field public static final action_bar_root:I = 0x7f09000e

.field public static final action_bar_spinner:I = 0x7f09000f

.field public static final action_bar_subtitle:I = 0x7f090010

.field public static final action_bar_title:I = 0x7f090011

.field public static final action_context_bar:I = 0x7f090013

.field public static final action_menu_divider:I = 0x7f090016

.field public static final action_menu_presenter:I = 0x7f090017

.field public static final action_mode_bar:I = 0x7f090018

.field public static final action_mode_bar_stub:I = 0x7f090019

.field public static final action_mode_close_button:I = 0x7f09001a

.field public static final activity_chooser_view_content:I = 0x7f09001d

.field public static final always:I = 0x7f090043

.field public static final beginning:I = 0x7f090049

.field public static final bottom:I = 0x7f09004b

.field public static final checkbox:I = 0x7f090056

.field public static final collapseActionView:I = 0x7f09005a

.field public static final decor_content_parent:I = 0x7f090067

.field public static final default_activity_button:I = 0x7f09006a

.field public static final disableHome:I = 0x7f090073

.field public static final edit_query:I = 0x7f090078

.field public static final end:I = 0x7f090079

.field public static final expand_activities_button:I = 0x7f090081

.field public static final expanded_menu:I = 0x7f090082

.field public static final home:I = 0x7f09009f

.field public static final homeAsUp:I = 0x7f0900a0

.field public static final icon:I = 0x7f0900a1

.field public static final ifRoom:I = 0x7f0900a4

.field public static final image:I = 0x7f0900a5

.field public static final listMode:I = 0x7f0900ba

.field public static final list_item:I = 0x7f0900bb

.field public static final middle:I = 0x7f0900ca

.field public static final never:I = 0x7f0900d3

.field public static final none:I = 0x7f0900d4

.field public static final normal:I = 0x7f0900d5

.field public static final progress_circular:I = 0x7f0900e6

.field public static final progress_horizontal:I = 0x7f0900e8

.field public static final radio:I = 0x7f0900ea

.field public static final search_badge:I = 0x7f090100

.field public static final search_bar:I = 0x7f090101

.field public static final search_button:I = 0x7f090102

.field public static final search_close_btn:I = 0x7f090103

.field public static final search_edit_frame:I = 0x7f090104

.field public static final search_go_btn:I = 0x7f090105

.field public static final search_mag_icon:I = 0x7f090106

.field public static final search_plate:I = 0x7f090107

.field public static final search_src_text:I = 0x7f090108

.field public static final search_voice_btn:I = 0x7f090109

.field public static final shortcut:I = 0x7f09010f

.field public static final showCustom:I = 0x7f090110

.field public static final showHome:I = 0x7f090111

.field public static final showTitle:I = 0x7f090112

.field public static final split_action_bar:I = 0x7f09011d

.field public static final submit_area:I = 0x7f09012d

.field public static final tabMode:I = 0x7f090134

.field public static final title:I = 0x7f090147

.field public static final top:I = 0x7f09014d

.field public static final up:I = 0x7f090159

.field public static final useLogo:I = 0x7f09015b

.field public static final withText:I = 0x7f090162

.field public static final wrap_content:I = 0x7f090164


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
