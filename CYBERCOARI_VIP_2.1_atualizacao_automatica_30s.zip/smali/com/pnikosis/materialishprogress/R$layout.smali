.class public final Lcom/pnikosis/materialishprogress/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/pnikosis/materialishprogress/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0c0000

.field public static final abc_action_bar_up_container:I = 0x7f0c0001

.field public static final abc_action_menu_item_layout:I = 0x7f0c0002

.field public static final abc_action_menu_layout:I = 0x7f0c0003

.field public static final abc_action_mode_bar:I = 0x7f0c0004

.field public static final abc_action_mode_close_item_material:I = 0x7f0c0005

.field public static final abc_activity_chooser_view:I = 0x7f0c0006

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0c0007

.field public static final abc_expanded_menu_layout:I = 0x7f0c000d

.field public static final abc_list_menu_item_checkbox:I = 0x7f0c000e

.field public static final abc_list_menu_item_icon:I = 0x7f0c000f

.field public static final abc_list_menu_item_layout:I = 0x7f0c0010

.field public static final abc_list_menu_item_radio:I = 0x7f0c0011

.field public static final abc_popup_menu_item_layout:I = 0x7f0c0013

.field public static final abc_screen_content_include:I = 0x7f0c0014

.field public static final abc_screen_simple:I = 0x7f0c0015

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0c0016

.field public static final abc_screen_toolbar:I = 0x7f0c0017

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0c0018

.field public static final abc_search_view:I = 0x7f0c0019

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0c0065


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
