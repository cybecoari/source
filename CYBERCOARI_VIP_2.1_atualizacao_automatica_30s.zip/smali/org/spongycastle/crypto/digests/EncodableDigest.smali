.class public interface abstract Lorg/spongycastle/crypto/digests/EncodableDigest;
.super Ljava/lang/Object;


# virtual methods
.method public abstract getEncodedState()[B
.end method
