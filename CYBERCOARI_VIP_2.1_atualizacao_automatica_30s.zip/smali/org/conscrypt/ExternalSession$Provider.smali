.class interface abstract Lorg/conscrypt/ExternalSession$Provider;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/conscrypt/ExternalSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Provider"
.end annotation


# virtual methods
.method public abstract provideSession()Lorg/conscrypt/ConscryptSession;
.end method
