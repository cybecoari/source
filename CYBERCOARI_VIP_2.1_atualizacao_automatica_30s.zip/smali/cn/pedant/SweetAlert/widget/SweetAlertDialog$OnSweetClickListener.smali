.class public interface abstract Lcn/pedant/SweetAlert/widget/SweetAlertDialog$OnSweetClickListener;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/pedant/SweetAlert/widget/SweetAlertDialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSweetClickListener"
.end annotation


# virtual methods
.method public abstract onClick(Lcn/pedant/SweetAlert/widget/SweetAlertDialog;)V
.end method
