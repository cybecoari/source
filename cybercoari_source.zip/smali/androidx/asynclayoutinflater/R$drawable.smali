.class public final Landroidx/asynclayoutinflater/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final notification_action_background:I = 0x7f0800ca

.field public static final notification_bg:I = 0x7f0800cb

.field public static final notification_bg_low:I = 0x7f0800cc

.field public static final notification_bg_low_normal:I = 0x7f0800cd

.field public static final notification_bg_low_pressed:I = 0x7f0800ce

.field public static final notification_bg_normal:I = 0x7f0800cf

.field public static final notification_bg_normal_pressed:I = 0x7f0800d0

.field public static final notification_icon_background:I = 0x7f0800d1

.field public static final notification_template_icon_bg:I = 0x7f0800d2

.field public static final notification_template_icon_low_bg:I = 0x7f0800d3

.field public static final notification_tile_bg:I = 0x7f0800d4

.field public static final notify_panel_notification_icon_bg:I = 0x7f0800d5


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
