.class public Landroidx/appcompat/widget/e/e2;
.super Ljava/lang/Object;
.source "e2.java"


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 37
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a()Landroid/app/Application;
    .locals 10

    .prologue
    .line 29
    :try_start_0
    const-string v4, "android.app.ActivityThread"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    move-object v1, v4

    .line 30
    check-cast v4, Ljava/lang/Class;

    const-string v5, "currentApplication"

    const/4 v6, 0x0

    new-array v6, v6, [Ljava/lang/Class;

    invoke-virtual {v4, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    move-object v2, v4

    .line 31
    move-object v5, v1

    const/4 v6, 0x0

    new-array v6, v6, [Ljava/lang/Object;

    invoke-virtual {v4, v5, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 32
    move-object v4, v2

    move-object v5, v1

    const/4 v6, 0x0

    new-array v6, v6, [Ljava/lang/Object;

    invoke-virtual {v4, v5, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 33
    check-cast v4, Landroid/app/Application;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v4

    .line 36
    :goto_0
    return-object v0

    .line 33
    :catch_0
    move-exception v4

    .line 36
    const/4 v4, 0x0

    check-cast v4, Landroid/app/Application;

    move-object v0, v4

    goto :goto_0
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .prologue
    .line 17
    move-object v0, p0

    :try_start_0
    invoke-static {}, Landroidx/appcompat/widget/e/e2;->a()Landroid/app/Application;

    move-result-object v5

    invoke-virtual {v5}, Landroid/app/Application;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "np/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v5

    move-object v2, v5

    .line 18
    invoke-virtual {v5}, Ljava/io/InputStream;->available()I

    move-result v5

    new-array v5, v5, [B

    move-object v3, v5

    .line 19
    move-object v5, v2

    move-object v6, v3

    invoke-virtual {v5, v6}, Ljava/io/InputStream;->read([B)I

    move-result v5

    .line 20
    move-object v5, v2

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 21
    new-instance v5, Ljava/lang/String;

    move-object v8, v5

    move-object v6, v8

    move-object v7, v3

    invoke-direct {v6, v7}, Ljava/lang/String;-><init>([B)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v5

    .line 23
    :goto_0
    return-object v0

    .line 21
    :catch_0
    move-exception v5

    .line 23
    const/4 v5, 0x0

    check-cast v5, Ljava/lang/String;

    move-object v0, v5

    goto :goto_0
.end method

.method public static n()Ljava/lang/String;
    .locals 7

    .prologue
    .line 11
    const-string v2, "np/"

    move-object v0, v2

    return-object v0
.end method
