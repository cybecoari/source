.class public Landroidx/appcompat/widget/AbsActionBarView2;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Ar()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "MyMessage"

    move-object v0, v3

    return-object v0
.end method

.method public static BaiTT6Dq3()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"red\">Usu\u00e1rio n\u00e3o encontrado no banco de dados!</strong>"

    move-object v0, v3

    return-object v0
.end method

.method public static Bhl8XgGah()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"#ffffff\">DIAS RESTANTES: </strong><strong><font color=\"#10FF00\">"

    move-object v0, v3

    return-object v0
.end method

.method public static CW6ty()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, " | "

    move-object v0, v3

    return-object v0
.end method

.method public static Dolemn()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "alarm"

    move-object v0, v3

    return-object v0
.end method

.method public static DzJ7iNlpg()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.extra.SUBJECT"

    move-object v0, v3

    return-object v0
.end method

.method public static ESGa()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "es"

    move-object v0, v3

    return-object v0
.end method

.method public static FQ()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"

    move-object v0, v3

    return-object v0
.end method

.method public static FwqLI5T()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"#ffffff\">DIAS RESTANTES: </strong><strong><font color=\"red\">"

    move-object v0, v3

    return-object v0
.end method

.method public static GLVzSleIg()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"#ffffff\">VENCIMENTO: </strong><strong><font color=\"#10FF00\">"

    move-object v0, v3

    return-object v0
.end method

.method public static HHqjk9SCP()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "user"

    move-object v0, v3

    return-object v0
.end method

.method public static IqC8W()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"#ffffff\">LIMITES: </strong><strong><font color=\"red\">"

    move-object v0, v3

    return-object v0
.end method

.method public static J22lMk()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.MAIN"

    move-object v0, v3

    return-object v0
.end method

.method public static J8P()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "firstStartSMS"

    move-object v0, v4

    return-object v0
.end method

.method public static KYQa6P8z()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "expiration_date"

    move-object v0, v4

    return-object v0
.end method

.method public static LMlNOD6()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    move-object v0, v3

    return-object v0
.end method

.method public static LjmqpFIZ5()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"#ffffff\">LIMITES: </strong><strong><font color=\"#10FF00\">"

    move-object v0, v3

    return-object v0
.end method

.method public static MLSQ()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "alarm"

    move-object v0, v3

    return-object v0
.end method

.method public static OxaN6()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, ".smsupdater"

    move-object v0, v4

    return-object v0
.end method

.method public static P33P()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "LastSelectedServer"

    move-object v0, v3

    return-object v0
.end method

.method public static PE()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "username"

    move-object v0, v3

    return-object v0
.end method

.method public static PjwuLwCfJ()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "com.android.phone"

    move-object v0, v3

    return-object v0
.end method

.method public static PzUB0YWEB()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Desinstalar"

    move-object v0, v3

    return-object v0
.end method

.method public static Q6kQ()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "not exist"

    move-object v0, v4

    return-object v0
.end method

.method public static QNW()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "CONECTADO"

    move-object v0, v3

    return-object v0
.end method

.method public static RA()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "notification"

    move-object v0, v3

    return-object v0
.end method

.method public static Rb4VPSL()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "MainUpdate"

    move-object v0, v3

    return-object v0
.end method

.method public static SEj5()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Content-Type"

    move-object v0, v3

    return-object v0
.end method

.method public static Sxi()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "com.android.settings.RadioInfo"

    move-object v0, v4

    return-object v0
.end method

.method public static TdMDmC3Yo()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, " dias"

    move-object v0, v3

    return-object v0
.end method

.method public static Te()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "SendMessage"

    move-object v0, v3

    return-object v0
.end method

.method public static Th()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "com.android.phone.settings.RadioInfo"

    move-object v0, v3

    return-object v0
.end method

.method public static Tkgm()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "message/rfc822"

    move-object v0, v3

    return-object v0
.end method

.method public static TmWM()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "application/json;charset=UTF-8"

    move-object v0, v4

    return-object v0
.end method

.method public static UCuHFu7()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Socks Injector - Feedback"

    move-object v0, v3

    return-object v0
.end method

.method public static UZZgO3OB()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.MAIN"

    move-object v0, v3

    return-object v0
.end method

.method public static VC0esIvo()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Accept"

    move-object v0, v3

    return-object v0
.end method

.method public static WZPS8R()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Error on getting data"

    move-object v0, v3

    return-object v0
.end method

.method public static XLs()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "application/json"

    move-object v0, v4

    return-object v0
.end method

.method public static XV()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "LastSelectedPayload"

    move-object v0, v3

    return-object v0
.end method

.method public static ZkZu1HRgn()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "firstStartSMS"

    move-object v0, v3

    return-object v0
.end method

.method public static Zn7Ech()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Battery optimization > All apps > cybercoari > Dont\'t optimize"

    move-object v0, v3

    return-object v0
.end method

.method public static a0L()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "</strong>"

    move-object v0, v3

    return-object v0
.end method

.method public static a8uqM()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "android.settings.APN_SETTINGS"

    move-object v0, v4

    return-object v0
.end method

.method public static bte4b()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.DELETE"

    move-object v0, v3

    return-object v0
.end method

.method public static csgg0lZxV()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "android.intent.category.HOME"

    move-object v0, v4

    return-object v0
.end method

.method public static dgwC3UV()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.MAIN"

    move-object v0, v3

    return-object v0
.end method

.method public static dlWlnNq()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "N\u00e3o disponivel para o seu aparelho"

    move-object v0, v3

    return-object v0
.end method

.method public static e6StrBG()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, " DIAS"

    move-object v0, v3

    return-object v0
.end method

.method public static gip4wz8Hj()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "NOVA MENSAGEM DO cybercoari"

    move-object v0, v3

    return-object v0
.end method

.method public static iqqoMEG()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "count_connection"

    move-object v0, v3

    return-object v0
.end method

.method public static j0Usaq()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, " DIA"

    move-object v0, v3

    return-object v0
.end method

.method public static joIw()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "com.cybercoari:openLogs"

    move-object v0, v4

    return-object v0
.end method

.method public static lh0I()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "<strong><font color=\"red\">Ocorreu um erro ao obter as informa\u00e7\u00f5es do login!</strong>"

    move-object v0, v3

    return-object v0
.end method

.method public static ln()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "v. %s (%d)"

    move-object v0, v3

    return-object v0
.end method

.method public static lofoqtK()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "android.intent.category.HOME"

    move-object v0, v4

    return-object v0
.end method

.method public static mO1()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.extra.EMAIL"

    move-object v0, v3

    return-object v0
.end method

.method public static nF4ASqP()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "package:"

    move-object v0, v4

    return-object v0
.end method

.method public static o6Dn8wz()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "SendMessage"

    move-object v0, v4

    return-object v0
.end method

.method public static pUe07rd()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "default"

    move-object v0, v3

    return-object v0
.end method

.method public static r0()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "JSON"

    move-object v0, v3

    return-object v0
.end method

.method public static rOTKdbK()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "pt-BR"

    move-object v0, v3

    return-object v0
.end method

.method public static rn9()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "com.android.settings"

    move-object v0, v3

    return-object v0
.end method

.method public static sneX()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "SMS"

    move-object v0, v3

    return-object v0
.end method

.method public static tP()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, " dia"

    move-object v0, v3

    return-object v0
.end method

.method public static v35sqG()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.VIEW"

    move-object v0, v3

    return-object v0
.end method

.method public static vmeK2QBlk()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "expiration_days"

    move-object v0, v3

    return-object v0
.end method

.method public static wpwaaavC()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "%s (%s)"

    move-object v0, v3

    return-object v0
.end method

.method public static wrje()Ljava/lang/String;
    .locals 7

    .prologue
    const-string v4, "RemoteException"

    move-object v0, v4

    return-object v0
.end method

.method public static xIGQXH7cN()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "NOVA MENSAGEM"

    move-object v0, v3

    return-object v0
.end method

.method public static yB()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "android.intent.action.SEND"

    move-object v0, v3

    return-object v0
.end method

.method public static yhS()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "limiter_user"

    move-object v0, v3

    return-object v0
.end method

.method public static zCHjjq()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "POST"

    move-object v0, v3

    return-object v0
.end method

.method public static zVfptaAj()Ljava/lang/String;
    .locals 5

    .prologue
    const-string v3, "Certo"

    move-object v0, v3

    return-object v0
.end method
