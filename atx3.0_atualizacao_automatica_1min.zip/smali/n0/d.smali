.class public interface abstract Ln0/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/n;


# virtual methods
.method public abstract d()Landroidx/savedstate/a;
.end method
