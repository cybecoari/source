.class public final Le4/m$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le4/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lg3/g;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Le4/m$a;-><init>()V

    return-void
.end method

.method public static final synthetic a(Le4/m$a;)Le4/m;
    .locals 0

    .line 1
    invoke-direct {p0}, Le4/m$a;->f()Le4/m;

    move-result-object p0

    return-object p0
.end method

.method private final d()Le4/m;
    .locals 1

    .line 1
    sget-object v0, Lf4/e;->a:Lf4/e;

    invoke-virtual {v0}, Lf4/e;->b()V

    sget-object v0, Le4/c;->e:Le4/c$a;

    invoke-virtual {v0}, Le4/c$a;->a()Le4/m;

    move-result-object v0

    if-nez v0, :cond_0

    sget-object v0, Le4/e;->f:Le4/e$a;

    invoke-virtual {v0}, Le4/e$a;->a()Le4/m;

    move-result-object v0

    invoke-static {v0}, Lg3/k;->b(Ljava/lang/Object;)V

    :cond_0
    return-object v0
.end method

.method private final e()Le4/m;
    .locals 1

    .line 1
    invoke-direct {p0}, Le4/m$a;->j()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Le4/g;->e:Le4/g$a;

    invoke-virtual {v0}, Le4/g$a;->b()Le4/g;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-direct {p0}, Le4/m$a;->i()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Le4/f;->e:Le4/f$a;

    invoke-virtual {v0}, Le4/f$a;->a()Le4/f;

    move-result-object v0

    if-eqz v0, :cond_1

    return-object v0

    :cond_1
    invoke-direct {p0}, Le4/m$a;->k()Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Le4/l;->e:Le4/l$a;

    invoke-virtual {v0}, Le4/l$a;->a()Le4/l;

    move-result-object v0

    if-eqz v0, :cond_2

    return-object v0

    :cond_2
    sget-object v0, Le4/k;->d:Le4/k$a;

    invoke-virtual {v0}, Le4/k$a;->a()Le4/k;

    move-result-object v0

    if-eqz v0, :cond_3

    return-object v0

    :cond_3
    sget-object v0, Le4/h;->i:Le4/h$b;

    invoke-virtual {v0}, Le4/h$b;->a()Le4/m;

    move-result-object v0

    if-eqz v0, :cond_4

    return-object v0

    :cond_4
    new-instance v0, Le4/m;

    invoke-direct {v0}, Le4/m;-><init>()V

    return-object v0
.end method

.method private final f()Le4/m;
    .locals 1

    .line 1
    invoke-virtual {p0}, Le4/m$a;->h()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Le4/m$a;->d()Le4/m;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Le4/m$a;->e()Le4/m;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method private final i()Z
    .locals 2

    .line 1
    invoke-static {}, Ljava/security/Security;->getProviders()[Ljava/security/Provider;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/security/Provider;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "BC"

    invoke-static {v1, v0}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private final j()Z
    .locals 2

    .line 1
    invoke-static {}, Ljava/security/Security;->getProviders()[Ljava/security/Provider;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/security/Provider;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Conscrypt"

    invoke-static {v1, v0}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private final k()Z
    .locals 2

    .line 1
    invoke-static {}, Ljava/security/Security;->getProviders()[Ljava/security/Provider;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/security/Provider;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OpenJSSE"

    invoke-static {v1, v0}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method


# virtual methods
.method public final b(Ljava/util/List;)Ljava/util/List;
    .locals 4

    .line 1
    const-string v0, "protocols"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lv3/z;

    sget-object v3, Lv3/z;->c:Lv3/z;

    if-eq v2, v3, :cond_1

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    :goto_1
    if-eqz v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    new-instance p1, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {v0, v1}, Lu2/l;->n(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {p1, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lv3/z;

    invoke-virtual {v1}, Lv3/z;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    return-object p1
.end method

.method public final c(Ljava/util/List;)[B
    .locals 3

    .line 1
    const-string v0, "protocols"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Li4/b;

    invoke-direct {v0}, Li4/b;-><init>()V

    invoke-virtual {p0, p1}, Le4/m$a;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v0, v2}, Li4/b;->b0(I)Li4/b;

    invoke-virtual {v0, v1}, Li4/b;->g0(Ljava/lang/String;)Li4/b;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Li4/b;->y()[B

    move-result-object p1

    return-object p1
.end method

.method public final g()Le4/m;
    .locals 1

    .line 1
    invoke-static {}, Le4/m;->a()Le4/m;

    move-result-object v0

    return-object v0
.end method

.method public final h()Z
    .locals 2

    .line 1
    const-string v0, "java.vm.name"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "Dalvik"

    invoke-static {v1, v0}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method
