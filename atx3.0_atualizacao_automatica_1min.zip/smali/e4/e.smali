.class public final Le4/e;
.super Le4/m;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le4/e$b;,
        Le4/e$a;
    }
.end annotation


# static fields
.field public static final f:Le4/e$a;

.field private static final g:Z


# instance fields
.field private final d:Ljava/util/List;

.field private final e:Lf4/j;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Le4/e$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Le4/e$a;-><init>(Lg3/g;)V

    sput-object v0, Le4/e;->f:Le4/e$a;

    sget-object v0, Le4/m;->a:Le4/m$a;

    invoke-virtual {v0}, Le4/m$a;->h()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v0, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    :goto_0
    sput-boolean v1, Le4/e;->g:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Le4/m;-><init>()V

    const/4 v0, 0x4

    new-array v0, v0, [Lf4/m;

    sget-object v1, Lf4/n;->j:Lf4/n$a;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1, v2, v3, v2}, Lf4/n$a;->b(Lf4/n$a;Ljava/lang/String;ILjava/lang/Object;)Lf4/m;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    new-instance v1, Lf4/l;

    sget-object v2, Lf4/h;->f:Lf4/h$a;

    invoke-virtual {v2}, Lf4/h$a;->d()Lf4/l$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lf4/l;-><init>(Lf4/l$a;)V

    aput-object v1, v0, v3

    new-instance v1, Lf4/l;

    sget-object v2, Lf4/k;->a:Lf4/k$b;

    invoke-virtual {v2}, Lf4/k$b;->a()Lf4/l$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lf4/l;-><init>(Lf4/l$a;)V

    const/4 v2, 0x2

    aput-object v1, v0, v2

    new-instance v1, Lf4/l;

    sget-object v2, Lf4/i;->a:Lf4/i$b;

    invoke-virtual {v2}, Lf4/i$b;->a()Lf4/l$a;

    move-result-object v2

    invoke-direct {v1, v2}, Lf4/l;-><init>(Lf4/l$a;)V

    const/4 v2, 0x3

    aput-object v1, v0, v2

    invoke-static {v0}, Lu2/l;->i([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lf4/m;

    invoke-interface {v3}, Lf4/m;->c()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    iput-object v1, p0, Le4/e;->d:Ljava/util/List;

    sget-object v0, Lf4/j;->d:Lf4/j$a;

    invoke-virtual {v0}, Lf4/j$a;->a()Lf4/j;

    move-result-object v0

    iput-object v0, p0, Le4/e;->e:Lf4/j;

    return-void
.end method

.method public static final synthetic p()Z
    .locals 1

    .line 1
    sget-boolean v0, Le4/e;->g:Z

    return v0
.end method


# virtual methods
.method public c(Ljavax/net/ssl/X509TrustManager;)Lh4/c;
    .locals 1

    .line 1
    const-string v0, "trustManager"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lf4/d;->d:Lf4/d$a;

    invoke-virtual {v0, p1}, Lf4/d$a;->a(Ljavax/net/ssl/X509TrustManager;)Lf4/d;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-super {p0, p1}, Le4/m;->c(Ljavax/net/ssl/X509TrustManager;)Lh4/c;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public d(Ljavax/net/ssl/X509TrustManager;)Lh4/e;
    .locals 6

    .line 1
    const-string v0, "trustManager"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v1, "findTrustAnchorByIssuerAndSignature"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    const-class v4, Ljava/security/cert/X509Certificate;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    new-instance v1, Le4/e$b;

    const-string v2, "method"

    invoke-static {v0, v2}, Lg3/k;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v1, p1, v0}, Le4/e$b;-><init>(Ljavax/net/ssl/X509TrustManager;Ljava/lang/reflect/Method;)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-super {p0, p1}, Le4/m;->d(Ljavax/net/ssl/X509TrustManager;)Lh4/e;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method public e(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V
    .locals 3

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "protocols"

    invoke-static {p3, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Le4/e;->d:Ljava/util/List;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lf4/m;

    invoke-interface {v2, p1}, Lf4/m;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    check-cast v1, Lf4/m;

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {v1, p1, p2, p3}, Lf4/m;->d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V

    :goto_1
    return-void
.end method

.method public f(Ljava/net/Socket;Ljava/net/InetSocketAddress;I)V
    .locals 1

    .line 1
    const-string v0, "socket"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "address"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p1, p2, p3}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p3, 0x1a

    if-ne p2, p3, :cond_0

    new-instance p2, Ljava/io/IOException;

    const-string p3, "Exception in connect"

    invoke-direct {p2, p3, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :cond_0
    throw p1
.end method

.method public g(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;
    .locals 4

    .line 1
    const-string v0, "sslSocket"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Le4/e;->d:Ljava/util/List;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lf4/m;

    invoke-interface {v3, p1}, Lf4/m;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_1
    move-object v1, v2

    :goto_0
    check-cast v1, Lf4/m;

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {v1, p1}, Lf4/m;->b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;

    move-result-object v2

    :goto_1
    return-object v2
.end method

.method public h(Ljava/lang/String;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "closer"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Le4/e;->e:Lf4/j;

    invoke-virtual {v0, p1}, Lf4/j;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public i(Ljava/lang/String;)Z
    .locals 2

    .line 1
    const-string v0, "hostname"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-lt v0, v1, :cond_0

    invoke-static {}, Le4/a;->a()Landroid/security/NetworkSecurityPolicy;

    move-result-object v0

    invoke-static {v0, p1}, Le4/b;->a(Landroid/security/NetworkSecurityPolicy;Ljava/lang/String;)Z

    move-result p1

    goto :goto_0

    :cond_0
    const/16 p1, 0x17

    if-lt v0, p1, :cond_1

    invoke-static {}, Le4/a;->a()Landroid/security/NetworkSecurityPolicy;

    move-result-object p1

    invoke-static {p1}, Le4/d;->a(Landroid/security/NetworkSecurityPolicy;)Z

    move-result p1

    goto :goto_0

    :cond_1
    const/4 p1, 0x1

    :goto_0
    return p1
.end method

.method public l(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 6

    .line 1
    const-string v0, "message"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Le4/e;->e:Lf4/j;

    invoke-virtual {v0, p2}, Lf4/j;->b(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    invoke-static/range {v0 .. v5}, Le4/m;->k(Le4/m;Ljava/lang/String;ILjava/lang/Throwable;ILjava/lang/Object;)V

    :cond_0
    return-void
.end method
