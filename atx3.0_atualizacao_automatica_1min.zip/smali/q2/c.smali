.class public final Lq2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Lr2/c;

.field private final b:[B

.field private final c:[B

.field private final d:Lq2/a;


# direct methods
.method private constructor <init>(Lr2/c;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lq2/c;->a:Lr2/c;

    invoke-virtual {p1}, Lr2/c;->a()Lr2/b;

    move-result-object v0

    invoke-static {v0}, Lq2/b;->f(Lr2/b;)Lq2/a;

    move-result-object v0

    iput-object v0, p0, Lq2/c;->d:Lq2/a;

    invoke-virtual {p1}, Lr2/c;->f()I

    move-result p1

    new-array p1, p1, [B

    iput-object p1, p0, Lq2/c;->b:[B

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    invoke-virtual {v0, p1}, Ljava/security/SecureRandom;->nextBytes([B)V

    invoke-direct {p0, p1}, Lq2/c;->e([B)[B

    move-result-object p1

    iput-object p1, p0, Lq2/c;->c:[B

    return-void
.end method

.method private c(Ljava/lang/String;)[B
    .locals 1

    .line 1
    const/4 v0, 0x2

    invoke-static {p1, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    return-object p1
.end method

.method public static d(Lr2/c;)Lq2/c;
    .locals 1

    .line 1
    new-instance v0, Lq2/c;

    invoke-direct {v0, p0}, Lq2/c;-><init>(Lr2/c;)V

    return-object v0
.end method

.method private e([B)[B
    .locals 3

    .line 1
    iget-object v0, p0, Lq2/c;->a:Lr2/c;

    invoke-virtual {v0}, Lr2/c;->e()[C

    move-result-object v0

    invoke-static {v0}, Ll4/e;->a([C)[B

    move-result-object v0

    sget-object v1, Lq2/c$a;->a:[I

    iget-object v2, p0, Lq2/c;->a:Lr2/c;

    invoke-virtual {v2}, Lr2/c;->b()Lr2/a;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const/4 v2, 0x1

    if-eq v1, v2, :cond_2

    const/4 v2, 0x2

    if-eq v1, v2, :cond_1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_0

    new-instance v1, Ln4/a;

    new-instance v2, Lm4/e;

    invoke-direct {v2}, Lm4/e;-><init>()V

    invoke-direct {v1, v2}, Ln4/a;-><init>(Ll4/b;)V

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Unknown Digest!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance v1, Ln4/a;

    new-instance v2, Lm4/d;

    invoke-direct {v2}, Lm4/d;-><init>()V

    invoke-direct {v1, v2}, Ln4/a;-><init>(Ll4/b;)V

    goto :goto_0

    :cond_2
    new-instance v1, Ln4/a;

    new-instance v2, Lm4/c;

    invoke-direct {v2}, Lm4/c;-><init>()V

    invoke-direct {v1, v2}, Ln4/a;-><init>(Ll4/b;)V

    :goto_0
    iget-object v2, p0, Lq2/c;->a:Lr2/c;

    invoke-virtual {v2}, Lr2/c;->d()I

    move-result v2

    invoke-virtual {v1, v0, p1, v2}, Ll4/e;->b([B[BI)V

    iget-object p1, p0, Lq2/c;->a:Lr2/c;

    invoke-virtual {p1}, Lr2/c;->c()I

    move-result p1

    invoke-virtual {v1, p1}, Ln4/a;->e(I)Ll4/a;

    move-result-object p1

    check-cast p1, Lp4/a;

    invoke-virtual {p1}, Lp4/a;->a()[B

    move-result-object p1

    return-object p1
.end method

.method private f([B)Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x2

    invoke-static {p1, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public a(Ljava/lang/String;)[B
    .locals 3

    .line 1
    const-string v0, "\\."

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    aget-object v0, p1, v0

    invoke-direct {p0, v0}, Lq2/c;->c(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v1, 0x1

    aget-object v1, p1, v1

    invoke-direct {p0, v1}, Lq2/c;->c(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v2, 0x2

    aget-object p1, p1, v2

    invoke-direct {p0, p1}, Lq2/c;->c(Ljava/lang/String;)[B

    move-result-object p1

    iget-object v2, p0, Lq2/c;->d:Lq2/a;

    invoke-direct {p0, v0}, Lq2/c;->e([B)[B

    move-result-object v0

    invoke-interface {v2, v0, v1, p1}, Lq2/a;->c([B[B[B)[B

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Malformed data string"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public b([B)Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iget-object v1, p0, Lq2/c;->d:Lq2/a;

    invoke-interface {v1}, Lq2/a;->b()I

    move-result v1

    new-array v1, v1, [B

    invoke-virtual {v0, v1}, Ljava/security/SecureRandom;->nextBytes([B)V

    iget-object v0, p0, Lq2/c;->d:Lq2/a;

    iget-object v2, p0, Lq2/c;->c:[B

    invoke-interface {v0, v2, v1, p1}, Lq2/a;->a([B[B[B)[B

    move-result-object p1

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v2, p0, Lq2/c;->b:[B

    invoke-direct {p0, v2}, Lq2/c;->f([B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v0, v3

    const/4 v2, 0x1

    invoke-direct {p0, v1}, Lq2/c;->f([B)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lq2/c;->f([B)Ljava/lang/String;

    move-result-object p1

    aput-object p1, v0, v1

    const-string p1, "%s.%s.%s"

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
