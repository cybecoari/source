.class public abstract La3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La3/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lc3/a;

    invoke-direct {v0}, Lc3/a;-><init>()V

    sput-object v0, La3/b;->a:La3/a;

    return-void
.end method
