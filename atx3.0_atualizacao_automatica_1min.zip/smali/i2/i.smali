.class public Li2/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static b:Li2/i;


# instance fields
.field private a:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li2/i;->a:Landroid/content/Context;

    invoke-static {p1}, Li2/n;->a(Landroid/content/Context;)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1a

    if-lt p1, v0, :cond_0

    invoke-direct {p0}, Li2/i;->a()V

    :cond_0
    return-void
.end method

.method private a()V
    .locals 5

    .line 1
    iget-object v0, p0, Li2/i;->a:Landroid/content/Context;

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    iget-object v1, p0, Li2/i;->a:Landroid/content/Context;

    sget v2, Li2/d;->f:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "openvpn_bg"

    const/4 v3, 0x1

    invoke-static {v2, v1, v3}, Lt0/g;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v1

    iget-object v2, p0, Li2/i;->a:Landroid/content/Context;

    sget v4, Li2/d;->c:I

    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Li2/e;->a(Landroid/app/NotificationChannel;Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-static {v1, v2}, Li2/g;->a(Landroid/app/NotificationChannel;Z)V

    const v2, -0xbbbbbc

    invoke-static {v1, v2}, Li2/f;->a(Landroid/app/NotificationChannel;I)V

    invoke-static {v0, v1}, Lt0/f;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    iget-object v1, p0, Li2/i;->a:Landroid/content/Context;

    sget v2, Li2/d;->g:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "openvpn_newstat"

    const/4 v4, 0x2

    invoke-static {v2, v1, v4}, Lt0/g;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v1

    iget-object v2, p0, Li2/i;->a:Landroid/content/Context;

    sget v4, Li2/d;->d:I

    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Li2/e;->a(Landroid/app/NotificationChannel;Ljava/lang/String;)V

    invoke-static {v1, v3}, Li2/g;->a(Landroid/app/NotificationChannel;Z)V

    const v2, -0xffff01

    invoke-static {v1, v2}, Li2/f;->a(Landroid/app/NotificationChannel;I)V

    invoke-static {v0, v1}, Lt0/f;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    iget-object v1, p0, Li2/i;->a:Landroid/content/Context;

    sget v2, Li2/d;->h:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "openvpn_userreq"

    const/4 v4, 0x4

    invoke-static {v2, v1, v4}, Lt0/g;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v1

    iget-object v2, p0, Li2/i;->a:Landroid/content/Context;

    sget v4, Li2/d;->e:I

    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Li2/e;->a(Landroid/app/NotificationChannel;Ljava/lang/String;)V

    invoke-static {v1, v3}, Li2/h;->a(Landroid/app/NotificationChannel;Z)V

    const v2, -0xff0001

    invoke-static {v1, v2}, Li2/f;->a(Landroid/app/NotificationChannel;I)V

    invoke-static {v0, v1}, Lt0/f;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    return-void
.end method

.method public static b(Landroid/content/Context;)V
    .locals 1

    .line 1
    sget-object v0, Li2/i;->b:Li2/i;

    if-nez v0, :cond_0

    new-instance v0, Li2/i;

    invoke-direct {v0, p0}, Li2/i;-><init>(Landroid/content/Context;)V

    sput-object v0, Li2/i;->b:Li2/i;

    :cond_0
    return-void
.end method
