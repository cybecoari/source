.class public final synthetic Li2/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lm2/m$c;


# instance fields
.field public final synthetic a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;


# direct methods
.method public synthetic constructor <init>(Lcom/slipkprojects/ultrasshservice/SocksHttpService;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li2/l;->a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    .line 1
    iget-object v0, p0, Li2/l;->a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;

    invoke-virtual {v0}, Lcom/slipkprojects/ultrasshservice/SocksHttpService;->d()V

    return-void
.end method
