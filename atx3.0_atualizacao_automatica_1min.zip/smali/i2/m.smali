.class public final synthetic Li2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;


# direct methods
.method public synthetic constructor <init>(Lcom/slipkprojects/ultrasshservice/SocksHttpService;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li2/m;->a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Li2/m;->a:Lcom/slipkprojects/ultrasshservice/SocksHttpService;

    invoke-static {v0}, Lcom/slipkprojects/ultrasshservice/SocksHttpService;->a(Lcom/slipkprojects/ultrasshservice/SocksHttpService;)V

    return-void
.end method
