.class public Lt1/b;
.super Lt1/a;
.source "SourceFile"


# direct methods
.method public constructor <init>(Ljava/io/File;Ljava/io/File;Lv1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lt1/a;-><init>(Ljava/io/File;Ljava/io/File;Lv1/a;)V

    return-void
.end method
