.class public interface abstract Lv1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;)Ljava/lang/String;
.end method
