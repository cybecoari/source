.class Ly1/h$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ly1/h;->j()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ly1/h;


# direct methods
.method constructor <init>(Ly1/h;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/h$b;->a:Ly1/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1
    iget-object v0, p0, Ly1/h$b;->a:Ly1/h;

    iget-object v1, v0, Ly1/h;->q:Lf2/a;

    iget-object v2, v0, Ly1/h;->l:Ljava/lang/String;

    iget-object v0, v0, Ly1/h;->n:Le2/a;

    invoke-interface {v0}, Le2/a;->f()Landroid/view/View;

    move-result-object v0

    invoke-interface {v1, v2, v0}, Lf2/a;->d(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method
