.class public final Ly1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ly1/e$d;,
        Ly1/e$c;,
        Ly1/e$b;
    }
.end annotation


# instance fields
.field final a:Landroid/content/res/Resources;

.field final b:I

.field final c:I

.field final d:I

.field final e:I

.field final f:Ljava/util/concurrent/Executor;

.field final g:Ljava/util/concurrent/Executor;

.field final h:Z

.field final i:Z

.field final j:I

.field final k:I

.field final l:Lz1/g;

.field final m:Lw1/a;

.field final n:Ls1/a;

.field final o:Ld2/b;

.field final p:Lb2/b;

.field final q:Ly1/c;

.field final r:Ld2/b;

.field final s:Ld2/b;


# direct methods
.method private constructor <init>(Ly1/e$b;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ly1/e$b;->a(Ly1/e$b;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->a:Landroid/content/res/Resources;

    invoke-static {p1}, Ly1/e$b;->b(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->b:I

    invoke-static {p1}, Ly1/e$b;->l(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->c:I

    invoke-static {p1}, Ly1/e$b;->m(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->d:I

    invoke-static {p1}, Ly1/e$b;->n(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->e:I

    invoke-static {p1}, Ly1/e$b;->o(Ly1/e$b;)Lg2/a;

    invoke-static {p1}, Ly1/e$b;->p(Ly1/e$b;)Ljava/util/concurrent/Executor;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->f:Ljava/util/concurrent/Executor;

    invoke-static {p1}, Ly1/e$b;->q(Ly1/e$b;)Ljava/util/concurrent/Executor;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->g:Ljava/util/concurrent/Executor;

    invoke-static {p1}, Ly1/e$b;->r(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->j:I

    invoke-static {p1}, Ly1/e$b;->s(Ly1/e$b;)I

    move-result v0

    iput v0, p0, Ly1/e;->k:I

    invoke-static {p1}, Ly1/e$b;->c(Ly1/e$b;)Lz1/g;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->l:Lz1/g;

    invoke-static {p1}, Ly1/e$b;->d(Ly1/e$b;)Ls1/a;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->n:Ls1/a;

    invoke-static {p1}, Ly1/e$b;->e(Ly1/e$b;)Lw1/a;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->m:Lw1/a;

    invoke-static {p1}, Ly1/e$b;->f(Ly1/e$b;)Ly1/c;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->q:Ly1/c;

    invoke-static {p1}, Ly1/e$b;->g(Ly1/e$b;)Ld2/b;

    move-result-object v0

    iput-object v0, p0, Ly1/e;->o:Ld2/b;

    invoke-static {p1}, Ly1/e$b;->h(Ly1/e$b;)Lb2/b;

    move-result-object v1

    iput-object v1, p0, Ly1/e;->p:Lb2/b;

    invoke-static {p1}, Ly1/e$b;->i(Ly1/e$b;)Z

    move-result v1

    iput-boolean v1, p0, Ly1/e;->h:Z

    invoke-static {p1}, Ly1/e$b;->j(Ly1/e$b;)Z

    move-result v1

    iput-boolean v1, p0, Ly1/e;->i:Z

    new-instance v1, Ly1/e$c;

    invoke-direct {v1, v0}, Ly1/e$c;-><init>(Ld2/b;)V

    iput-object v1, p0, Ly1/e;->r:Ld2/b;

    new-instance v1, Ly1/e$d;

    invoke-direct {v1, v0}, Ly1/e$d;-><init>(Ld2/b;)V

    iput-object v1, p0, Ly1/e;->s:Ld2/b;

    invoke-static {p1}, Ly1/e$b;->k(Ly1/e$b;)Z

    move-result p1

    invoke-static {p1}, Lh2/c;->g(Z)V

    return-void
.end method

.method synthetic constructor <init>(Ly1/e$b;Ly1/e$a;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, Ly1/e;-><init>(Ly1/e$b;)V

    return-void
.end method


# virtual methods
.method a()Lz1/e;
    .locals 3

    .line 1
    iget-object v0, p0, Ly1/e;->a:Landroid/content/res/Resources;

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v1, p0, Ly1/e;->b:I

    if-gtz v1, :cond_0

    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    :cond_0
    iget v2, p0, Ly1/e;->c:I

    if-gtz v2, :cond_1

    iget v2, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    :cond_1
    new-instance v0, Lz1/e;

    invoke-direct {v0, v1, v2}, Lz1/e;-><init>(II)V

    return-object v0
.end method
