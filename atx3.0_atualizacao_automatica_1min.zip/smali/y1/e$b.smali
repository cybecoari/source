.class public Ly1/e$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly1/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field public static final x:Lz1/g;


# instance fields
.field private a:Landroid/content/Context;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:Ljava/util/concurrent/Executor;

.field private g:Ljava/util/concurrent/Executor;

.field private h:Z

.field private i:Z

.field private j:I

.field private k:I

.field private l:Z

.field private m:Lz1/g;

.field private n:I

.field private o:J

.field private p:I

.field private q:Lw1/a;

.field private r:Ls1/a;

.field private s:Lv1/a;

.field private t:Ld2/b;

.field private u:Lb2/b;

.field private v:Ly1/c;

.field private w:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lz1/g;->a:Lz1/g;

    sput-object v0, Ly1/e$b;->x:Lz1/g;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Ly1/e$b;->b:I

    iput v0, p0, Ly1/e$b;->c:I

    iput v0, p0, Ly1/e$b;->d:I

    iput v0, p0, Ly1/e$b;->e:I

    const/4 v1, 0x0

    iput-object v1, p0, Ly1/e$b;->f:Ljava/util/concurrent/Executor;

    iput-object v1, p0, Ly1/e$b;->g:Ljava/util/concurrent/Executor;

    iput-boolean v0, p0, Ly1/e$b;->h:Z

    iput-boolean v0, p0, Ly1/e$b;->i:Z

    const/4 v2, 0x3

    iput v2, p0, Ly1/e$b;->j:I

    iput v2, p0, Ly1/e$b;->k:I

    iput-boolean v0, p0, Ly1/e$b;->l:Z

    sget-object v2, Ly1/e$b;->x:Lz1/g;

    iput-object v2, p0, Ly1/e$b;->m:Lz1/g;

    iput v0, p0, Ly1/e$b;->n:I

    const-wide/16 v2, 0x0

    iput-wide v2, p0, Ly1/e$b;->o:J

    iput v0, p0, Ly1/e$b;->p:I

    iput-object v1, p0, Ly1/e$b;->q:Lw1/a;

    iput-object v1, p0, Ly1/e$b;->r:Ls1/a;

    iput-object v1, p0, Ly1/e$b;->s:Lv1/a;

    iput-object v1, p0, Ly1/e$b;->t:Ld2/b;

    iput-object v1, p0, Ly1/e$b;->v:Ly1/c;

    iput-boolean v0, p0, Ly1/e$b;->w:Z

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Ly1/e$b;->a:Landroid/content/Context;

    return-void
.end method

.method static synthetic a(Ly1/e$b;)Landroid/content/Context;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->a:Landroid/content/Context;

    return-object p0
.end method

.method static synthetic b(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->b:I

    return p0
.end method

.method static synthetic c(Ly1/e$b;)Lz1/g;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->m:Lz1/g;

    return-object p0
.end method

.method static synthetic d(Ly1/e$b;)Ls1/a;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->r:Ls1/a;

    return-object p0
.end method

.method static synthetic e(Ly1/e$b;)Lw1/a;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->q:Lw1/a;

    return-object p0
.end method

.method static synthetic f(Ly1/e$b;)Ly1/c;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->v:Ly1/c;

    return-object p0
.end method

.method static synthetic g(Ly1/e$b;)Ld2/b;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->t:Ld2/b;

    return-object p0
.end method

.method static synthetic h(Ly1/e$b;)Lb2/b;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->u:Lb2/b;

    return-object p0
.end method

.method static synthetic i(Ly1/e$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/e$b;->h:Z

    return p0
.end method

.method static synthetic j(Ly1/e$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/e$b;->i:Z

    return p0
.end method

.method static synthetic k(Ly1/e$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/e$b;->w:Z

    return p0
.end method

.method static synthetic l(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->c:I

    return p0
.end method

.method static synthetic m(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->d:I

    return p0
.end method

.method static synthetic n(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->e:I

    return p0
.end method

.method static synthetic o(Ly1/e$b;)Lg2/a;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic p(Ly1/e$b;)Ljava/util/concurrent/Executor;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->f:Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method static synthetic q(Ly1/e$b;)Ljava/util/concurrent/Executor;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/e$b;->g:Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method static synthetic r(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->j:I

    return p0
.end method

.method static synthetic s(Ly1/e$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/e$b;->k:I

    return p0
.end method

.method private y()V
    .locals 5

    .line 1
    iget-object v0, p0, Ly1/e$b;->f:Ljava/util/concurrent/Executor;

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget v0, p0, Ly1/e$b;->j:I

    iget v2, p0, Ly1/e$b;->k:I

    iget-object v3, p0, Ly1/e$b;->m:Lz1/g;

    invoke-static {v0, v2, v3}, Ly1/a;->c(IILz1/g;)Ljava/util/concurrent/Executor;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->f:Ljava/util/concurrent/Executor;

    goto :goto_0

    :cond_0
    iput-boolean v1, p0, Ly1/e$b;->h:Z

    :goto_0
    iget-object v0, p0, Ly1/e$b;->g:Ljava/util/concurrent/Executor;

    if-nez v0, :cond_1

    iget v0, p0, Ly1/e$b;->j:I

    iget v1, p0, Ly1/e$b;->k:I

    iget-object v2, p0, Ly1/e$b;->m:Lz1/g;

    invoke-static {v0, v1, v2}, Ly1/a;->c(IILz1/g;)Ljava/util/concurrent/Executor;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->g:Ljava/util/concurrent/Executor;

    goto :goto_1

    :cond_1
    iput-boolean v1, p0, Ly1/e$b;->i:Z

    :goto_1
    iget-object v0, p0, Ly1/e$b;->r:Ls1/a;

    if-nez v0, :cond_3

    iget-object v0, p0, Ly1/e$b;->s:Lv1/a;

    if-nez v0, :cond_2

    invoke-static {}, Ly1/a;->d()Lv1/a;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->s:Lv1/a;

    :cond_2
    iget-object v0, p0, Ly1/e$b;->a:Landroid/content/Context;

    iget-object v1, p0, Ly1/e$b;->s:Lv1/a;

    iget-wide v2, p0, Ly1/e$b;->o:J

    iget v4, p0, Ly1/e$b;->p:I

    invoke-static {v0, v1, v2, v3, v4}, Ly1/a;->b(Landroid/content/Context;Lv1/a;JI)Ls1/a;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->r:Ls1/a;

    :cond_3
    iget-object v0, p0, Ly1/e$b;->q:Lw1/a;

    if-nez v0, :cond_4

    iget-object v0, p0, Ly1/e$b;->a:Landroid/content/Context;

    iget v1, p0, Ly1/e$b;->n:I

    invoke-static {v0, v1}, Ly1/a;->g(Landroid/content/Context;I)Lw1/a;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->q:Lw1/a;

    :cond_4
    iget-boolean v0, p0, Ly1/e$b;->l:Z

    if-eqz v0, :cond_5

    new-instance v0, Lx1/a;

    iget-object v1, p0, Ly1/e$b;->q:Lw1/a;

    invoke-static {}, Lh2/d;->a()Ljava/util/Comparator;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lx1/a;-><init>(Lw1/a;Ljava/util/Comparator;)V

    iput-object v0, p0, Ly1/e$b;->q:Lw1/a;

    :cond_5
    iget-object v0, p0, Ly1/e$b;->t:Ld2/b;

    if-nez v0, :cond_6

    iget-object v0, p0, Ly1/e$b;->a:Landroid/content/Context;

    invoke-static {v0}, Ly1/a;->f(Landroid/content/Context;)Ld2/b;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->t:Ld2/b;

    :cond_6
    iget-object v0, p0, Ly1/e$b;->u:Lb2/b;

    if-nez v0, :cond_7

    iget-boolean v0, p0, Ly1/e$b;->w:Z

    invoke-static {v0}, Ly1/a;->e(Z)Lb2/b;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->u:Lb2/b;

    :cond_7
    iget-object v0, p0, Ly1/e$b;->v:Ly1/c;

    if-nez v0, :cond_8

    invoke-static {}, Ly1/c;->t()Ly1/c;

    move-result-object v0

    iput-object v0, p0, Ly1/e$b;->v:Ly1/c;

    :cond_8
    return-void
.end method


# virtual methods
.method public A(I)Ly1/e$b;
    .locals 2

    .line 1
    iget-object v0, p0, Ly1/e$b;->f:Ljava/util/concurrent/Executor;

    if-nez v0, :cond_0

    iget-object v0, p0, Ly1/e$b;->g:Ljava/util/concurrent/Executor;

    if-eqz v0, :cond_1

    :cond_0
    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "threadPoolSize(), threadPriority() and tasksProcessingOrder() calls can overlap taskExecutor() and taskExecutorForCachedImages() calls."

    invoke-static {v1, v0}, Lh2/c;->f(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v0, 0x1

    if-ge p1, v0, :cond_2

    :goto_0
    iput v0, p0, Ly1/e$b;->k:I

    goto :goto_1

    :cond_2
    const/16 v0, 0xa

    if-le p1, v0, :cond_3

    goto :goto_0

    :cond_3
    iput p1, p0, Ly1/e$b;->k:I

    :goto_1
    return-object p0
.end method

.method public t()Ly1/e;
    .locals 2

    .line 1
    invoke-direct {p0}, Ly1/e$b;->y()V

    new-instance v0, Ly1/e;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Ly1/e;-><init>(Ly1/e$b;Ly1/e$a;)V

    return-object v0
.end method

.method public u(Ly1/c;)Ly1/e$b;
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/e$b;->v:Ly1/c;

    return-object p0
.end method

.method public v()Ly1/e$b;
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Ly1/e$b;->l:Z

    return-object p0
.end method

.method public w(I)Ly1/e$b;
    .locals 2

    .line 1
    if-lez p1, :cond_1

    iget-object v0, p0, Ly1/e$b;->r:Ls1/a;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "diskCache(), diskCacheSize() and diskCacheFileCount calls overlap each other"

    invoke-static {v1, v0}, Lh2/c;->f(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    iput p1, p0, Ly1/e$b;->p:I

    return-object p0

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "maxFileCount must be a positive number"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public x(I)Ly1/e$b;
    .locals 2

    .line 1
    if-lez p1, :cond_1

    iget-object v0, p0, Ly1/e$b;->r:Ls1/a;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "diskCache(), diskCacheSize() and diskCacheFileCount calls overlap each other"

    invoke-static {v1, v0}, Lh2/c;->f(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    int-to-long v0, p1

    iput-wide v0, p0, Ly1/e$b;->o:J

    return-object p0

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "maxCacheSize must be a positive number"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public z(I)Ly1/e$b;
    .locals 2

    .line 1
    if-lez p1, :cond_1

    const/16 v0, 0x64

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Ly1/e$b;->q:Lw1/a;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "memoryCache() and memoryCacheSize() calls overlap each other"

    invoke-static {v1, v0}, Lh2/c;->f(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v0

    long-to-float v0, v0

    int-to-float p1, p1

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr p1, v1

    mul-float v0, v0, p1

    float-to-int p1, v0

    iput p1, p0, Ly1/e$b;->n:I

    return-object p0

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "availableMemoryPercent must be in range (0 < % < 100)"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
