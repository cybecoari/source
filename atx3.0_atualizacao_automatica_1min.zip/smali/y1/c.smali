.class public final Ly1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ly1/c$b;
    }
.end annotation


# instance fields
.field private final a:I

.field private final b:I

.field private final c:I

.field private final d:Landroid/graphics/drawable/Drawable;

.field private final e:Landroid/graphics/drawable/Drawable;

.field private final f:Landroid/graphics/drawable/Drawable;

.field private final g:Z

.field private final h:Z

.field private final i:Z

.field private final j:Lz1/d;

.field private final k:Landroid/graphics/BitmapFactory$Options;

.field private final l:I

.field private final m:Z

.field private final n:Ljava/lang/Object;

.field private final o:Lc2/a;

.field private final p:Landroid/os/Handler;

.field private final q:Z


# direct methods
.method private constructor <init>(Ly1/c$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ly1/c$b;->a(Ly1/c$b;)I

    move-result v0

    iput v0, p0, Ly1/c;->a:I

    invoke-static {p1}, Ly1/c$b;->b(Ly1/c$b;)I

    move-result v0

    iput v0, p0, Ly1/c;->b:I

    invoke-static {p1}, Ly1/c$b;->l(Ly1/c$b;)I

    move-result v0

    iput v0, p0, Ly1/c;->c:I

    invoke-static {p1}, Ly1/c$b;->m(Ly1/c$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->d:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c$b;->n(Ly1/c$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->e:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c$b;->o(Ly1/c$b;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->f:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c$b;->p(Ly1/c$b;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c;->g:Z

    invoke-static {p1}, Ly1/c$b;->q(Ly1/c$b;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c;->h:Z

    invoke-static {p1}, Ly1/c$b;->r(Ly1/c$b;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c;->i:Z

    invoke-static {p1}, Ly1/c$b;->s(Ly1/c$b;)Lz1/d;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->j:Lz1/d;

    invoke-static {p1}, Ly1/c$b;->c(Ly1/c$b;)Landroid/graphics/BitmapFactory$Options;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->k:Landroid/graphics/BitmapFactory$Options;

    invoke-static {p1}, Ly1/c$b;->d(Ly1/c$b;)I

    move-result v0

    iput v0, p0, Ly1/c;->l:I

    invoke-static {p1}, Ly1/c$b;->e(Ly1/c$b;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c;->m:Z

    invoke-static {p1}, Ly1/c$b;->f(Ly1/c$b;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->n:Ljava/lang/Object;

    invoke-static {p1}, Ly1/c$b;->g(Ly1/c$b;)Lg2/a;

    invoke-static {p1}, Ly1/c$b;->h(Ly1/c$b;)Lg2/a;

    invoke-static {p1}, Ly1/c$b;->i(Ly1/c$b;)Lc2/a;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->o:Lc2/a;

    invoke-static {p1}, Ly1/c$b;->j(Ly1/c$b;)Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, Ly1/c;->p:Landroid/os/Handler;

    invoke-static {p1}, Ly1/c$b;->k(Ly1/c$b;)Z

    move-result p1

    iput-boolean p1, p0, Ly1/c;->q:Z

    return-void
.end method

.method synthetic constructor <init>(Ly1/c$b;Ly1/c$a;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, Ly1/c;-><init>(Ly1/c$b;)V

    return-void
.end method

.method static synthetic a(Ly1/c;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c;->a:I

    return p0
.end method

.method static synthetic b(Ly1/c;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c;->b:I

    return p0
.end method

.method static synthetic c(Ly1/c;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c;->c:I

    return p0
.end method

.method static synthetic d(Ly1/c;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->d:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic e(Ly1/c;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->e:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic f(Ly1/c;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->f:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic g(Ly1/c;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c;->g:Z

    return p0
.end method

.method static synthetic h(Ly1/c;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c;->h:Z

    return p0
.end method

.method static synthetic i(Ly1/c;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c;->i:Z

    return p0
.end method

.method static synthetic j(Ly1/c;)Lz1/d;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->j:Lz1/d;

    return-object p0
.end method

.method static synthetic k(Ly1/c;)Landroid/graphics/BitmapFactory$Options;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->k:Landroid/graphics/BitmapFactory$Options;

    return-object p0
.end method

.method static synthetic l(Ly1/c;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c;->l:I

    return p0
.end method

.method static synthetic m(Ly1/c;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c;->m:Z

    return p0
.end method

.method static synthetic n(Ly1/c;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->n:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic o(Ly1/c;)Lg2/a;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic p(Ly1/c;)Lg2/a;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic q(Ly1/c;)Lc2/a;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->o:Lc2/a;

    return-object p0
.end method

.method static synthetic r(Ly1/c;)Landroid/os/Handler;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c;->p:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic s(Ly1/c;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c;->q:Z

    return p0
.end method

.method public static t()Ly1/c;
    .locals 1

    .line 1
    new-instance v0, Ly1/c$b;

    invoke-direct {v0}, Ly1/c$b;-><init>()V

    invoke-virtual {v0}, Ly1/c$b;->t()Ly1/c;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public A(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget v0, p0, Ly1/c;->c:I

    if-eqz v0, :cond_0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Ly1/c;->f:Landroid/graphics/drawable/Drawable;

    :goto_0
    return-object p1
.end method

.method public B(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget v0, p0, Ly1/c;->a:I

    if-eqz v0, :cond_0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Ly1/c;->d:Landroid/graphics/drawable/Drawable;

    :goto_0
    return-object p1
.end method

.method public C()Lz1/d;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->j:Lz1/d;

    return-object v0
.end method

.method public D()Lg2/a;
    .locals 1

    .line 1
    const/4 v0, 0x0

    return-object v0
.end method

.method public E()Lg2/a;
    .locals 1

    .line 1
    const/4 v0, 0x0

    return-object v0
.end method

.method public F()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/c;->h:Z

    return v0
.end method

.method public G()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/c;->i:Z

    return v0
.end method

.method public H()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/c;->m:Z

    return v0
.end method

.method public I()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/c;->g:Z

    return v0
.end method

.method J()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/c;->q:Z

    return v0
.end method

.method public K()Z
    .locals 1

    .line 1
    iget v0, p0, Ly1/c;->l:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public L()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public M()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public N()Z
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->e:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_1

    iget v0, p0, Ly1/c;->b:I

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public O()Z
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->f:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_1

    iget v0, p0, Ly1/c;->c:I

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public P()Z
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->d:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_1

    iget v0, p0, Ly1/c;->a:I

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public u()Landroid/graphics/BitmapFactory$Options;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->k:Landroid/graphics/BitmapFactory$Options;

    return-object v0
.end method

.method public v()I
    .locals 1

    .line 1
    iget v0, p0, Ly1/c;->l:I

    return v0
.end method

.method public w()Lc2/a;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->o:Lc2/a;

    return-object v0
.end method

.method public x()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->n:Ljava/lang/Object;

    return-object v0
.end method

.method public y()Landroid/os/Handler;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/c;->p:Landroid/os/Handler;

    return-object v0
.end method

.method public z(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget v0, p0, Ly1/c;->b:I

    if-eqz v0, :cond_0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    iget-object p1, p0, Ly1/c;->e:Landroid/graphics/drawable/Drawable;

    :goto_0
    return-object p1
.end method
