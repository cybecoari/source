.class final Ly1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Landroid/graphics/Bitmap;

.field private final b:Ljava/lang/String;

.field private final c:Le2/a;

.field private final d:Ljava/lang/String;

.field private final f:Lc2/a;

.field private final h:Lf2/a;

.field private final j:Ly1/f;

.field private final k:Lz1/f;


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;Ly1/g;Ly1/f;Lz1/f;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ly1/b;->a:Landroid/graphics/Bitmap;

    iget-object p1, p2, Ly1/g;->a:Ljava/lang/String;

    iput-object p1, p0, Ly1/b;->b:Ljava/lang/String;

    iget-object p1, p2, Ly1/g;->c:Le2/a;

    iput-object p1, p0, Ly1/b;->c:Le2/a;

    iget-object p1, p2, Ly1/g;->b:Ljava/lang/String;

    iput-object p1, p0, Ly1/b;->d:Ljava/lang/String;

    iget-object p1, p2, Ly1/g;->e:Ly1/c;

    invoke-virtual {p1}, Ly1/c;->w()Lc2/a;

    move-result-object p1

    iput-object p1, p0, Ly1/b;->f:Lc2/a;

    iget-object p1, p2, Ly1/g;->f:Lf2/a;

    iput-object p1, p0, Ly1/b;->h:Lf2/a;

    iput-object p3, p0, Ly1/b;->j:Ly1/f;

    iput-object p4, p0, Ly1/b;->k:Lz1/f;

    return-void
.end method

.method private a()Z
    .locals 2

    .line 1
    iget-object v0, p0, Ly1/b;->j:Ly1/f;

    iget-object v1, p0, Ly1/b;->c:Le2/a;

    invoke-virtual {v0, v1}, Ly1/f;->g(Le2/a;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ly1/b;->d:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 1
    iget-object v0, p0, Ly1/b;->c:Le2/a;

    invoke-interface {v0}, Le2/a;->a()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    new-array v0, v2, [Ljava/lang/Object;

    iget-object v2, p0, Ly1/b;->d:Ljava/lang/String;

    aput-object v2, v0, v1

    const-string v1, "ImageAware was collected by GC. Task is cancelled. [%s]"

    invoke-static {v1, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    iget-object v0, p0, Ly1/b;->h:Lf2/a;

    iget-object v1, p0, Ly1/b;->b:Ljava/lang/String;

    iget-object v2, p0, Ly1/b;->c:Le2/a;

    invoke-interface {v2}, Le2/a;->f()Landroid/view/View;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Lf2/a;->d(Ljava/lang/String;Landroid/view/View;)V

    goto :goto_1

    :cond_0
    invoke-direct {p0}, Ly1/b;->a()Z

    move-result v0

    if-eqz v0, :cond_1

    new-array v0, v2, [Ljava/lang/Object;

    iget-object v2, p0, Ly1/b;->d:Ljava/lang/String;

    aput-object v2, v0, v1

    const-string v1, "ImageAware is reused for another image. Task is cancelled. [%s]"

    invoke-static {v1, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/b;->k:Lz1/f;

    aput-object v3, v0, v1

    iget-object v1, p0, Ly1/b;->d:Ljava/lang/String;

    aput-object v1, v0, v2

    const-string v1, "Display image in ImageAware (loaded from %1$s) [%2$s]"

    invoke-static {v1, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, p0, Ly1/b;->f:Lc2/a;

    iget-object v1, p0, Ly1/b;->a:Landroid/graphics/Bitmap;

    iget-object v2, p0, Ly1/b;->c:Le2/a;

    iget-object v3, p0, Ly1/b;->k:Lz1/f;

    invoke-interface {v0, v1, v2, v3}, Lc2/a;->a(Landroid/graphics/Bitmap;Le2/a;Lz1/f;)V

    iget-object v0, p0, Ly1/b;->j:Ly1/f;

    iget-object v1, p0, Ly1/b;->c:Le2/a;

    invoke-virtual {v0, v1}, Ly1/f;->d(Le2/a;)V

    iget-object v0, p0, Ly1/b;->h:Lf2/a;

    iget-object v1, p0, Ly1/b;->b:Ljava/lang/String;

    iget-object v2, p0, Ly1/b;->c:Le2/a;

    invoke-interface {v2}, Le2/a;->f()Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Ly1/b;->a:Landroid/graphics/Bitmap;

    invoke-interface {v0, v1, v2, v3}, Lf2/a;->b(Ljava/lang/String;Landroid/view/View;Landroid/graphics/Bitmap;)V

    :goto_1
    return-void
.end method
