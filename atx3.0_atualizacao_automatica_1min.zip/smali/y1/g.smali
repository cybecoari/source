.class final Ly1/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final a:Ljava/lang/String;

.field final b:Ljava/lang/String;

.field final c:Le2/a;

.field final d:Lz1/e;

.field final e:Ly1/c;

.field final f:Lf2/a;

.field final g:Ljava/util/concurrent/locks/ReentrantLock;


# direct methods
.method public constructor <init>(Ljava/lang/String;Le2/a;Lz1/e;Ljava/lang/String;Ly1/c;Lf2/a;Lf2/b;Ljava/util/concurrent/locks/ReentrantLock;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ly1/g;->a:Ljava/lang/String;

    iput-object p2, p0, Ly1/g;->c:Le2/a;

    iput-object p3, p0, Ly1/g;->d:Lz1/e;

    iput-object p5, p0, Ly1/g;->e:Ly1/c;

    iput-object p6, p0, Ly1/g;->f:Lf2/a;

    iput-object p8, p0, Ly1/g;->g:Ljava/util/concurrent/locks/ReentrantLock;

    iput-object p4, p0, Ly1/g;->b:Ljava/lang/String;

    return-void
.end method
