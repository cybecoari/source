.class public Ly1/c$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly1/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Landroid/graphics/drawable/Drawable;

.field private e:Landroid/graphics/drawable/Drawable;

.field private f:Landroid/graphics/drawable/Drawable;

.field private g:Z

.field private h:Z

.field private i:Z

.field private j:Lz1/d;

.field private k:Landroid/graphics/BitmapFactory$Options;

.field private l:I

.field private m:Z

.field private n:Ljava/lang/Object;

.field private o:Lc2/a;

.field private p:Landroid/os/Handler;

.field private q:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Ly1/c$b;->a:I

    iput v0, p0, Ly1/c$b;->b:I

    iput v0, p0, Ly1/c$b;->c:I

    const/4 v1, 0x0

    iput-object v1, p0, Ly1/c$b;->d:Landroid/graphics/drawable/Drawable;

    iput-object v1, p0, Ly1/c$b;->e:Landroid/graphics/drawable/Drawable;

    iput-object v1, p0, Ly1/c$b;->f:Landroid/graphics/drawable/Drawable;

    iput-boolean v0, p0, Ly1/c$b;->g:Z

    iput-boolean v0, p0, Ly1/c$b;->h:Z

    iput-boolean v0, p0, Ly1/c$b;->i:Z

    sget-object v2, Lz1/d;->c:Lz1/d;

    iput-object v2, p0, Ly1/c$b;->j:Lz1/d;

    new-instance v2, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    iput-object v2, p0, Ly1/c$b;->k:Landroid/graphics/BitmapFactory$Options;

    iput v0, p0, Ly1/c$b;->l:I

    iput-boolean v0, p0, Ly1/c$b;->m:Z

    iput-object v1, p0, Ly1/c$b;->n:Ljava/lang/Object;

    invoke-static {}, Ly1/a;->a()Lc2/a;

    move-result-object v2

    iput-object v2, p0, Ly1/c$b;->o:Lc2/a;

    iput-object v1, p0, Ly1/c$b;->p:Landroid/os/Handler;

    iput-boolean v0, p0, Ly1/c$b;->q:Z

    return-void
.end method

.method static synthetic a(Ly1/c$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c$b;->a:I

    return p0
.end method

.method static synthetic b(Ly1/c$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c$b;->b:I

    return p0
.end method

.method static synthetic c(Ly1/c$b;)Landroid/graphics/BitmapFactory$Options;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->k:Landroid/graphics/BitmapFactory$Options;

    return-object p0
.end method

.method static synthetic d(Ly1/c$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c$b;->l:I

    return p0
.end method

.method static synthetic e(Ly1/c$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c$b;->m:Z

    return p0
.end method

.method static synthetic f(Ly1/c$b;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->n:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic g(Ly1/c$b;)Lg2/a;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic h(Ly1/c$b;)Lg2/a;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method static synthetic i(Ly1/c$b;)Lc2/a;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->o:Lc2/a;

    return-object p0
.end method

.method static synthetic j(Ly1/c$b;)Landroid/os/Handler;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->p:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic k(Ly1/c$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c$b;->q:Z

    return p0
.end method

.method static synthetic l(Ly1/c$b;)I
    .locals 0

    .line 1
    iget p0, p0, Ly1/c$b;->c:I

    return p0
.end method

.method static synthetic m(Ly1/c$b;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->d:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic n(Ly1/c$b;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->e:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic o(Ly1/c$b;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->f:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method static synthetic p(Ly1/c$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c$b;->g:Z

    return p0
.end method

.method static synthetic q(Ly1/c$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c$b;->h:Z

    return p0
.end method

.method static synthetic r(Ly1/c$b;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ly1/c$b;->i:Z

    return p0
.end method

.method static synthetic s(Ly1/c$b;)Lz1/d;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/c$b;->j:Lz1/d;

    return-object p0
.end method


# virtual methods
.method public t()Ly1/c;
    .locals 2

    .line 1
    new-instance v0, Ly1/c;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Ly1/c;-><init>(Ly1/c$b;Ly1/c$a;)V

    return-object v0
.end method

.method public u(Z)Ly1/c$b;
    .locals 0

    .line 1
    iput-boolean p1, p0, Ly1/c$b;->h:Z

    return-object p0
.end method

.method public v(Z)Ly1/c$b;
    .locals 0

    .line 1
    iput-boolean p1, p0, Ly1/c$b;->i:Z

    return-object p0
.end method

.method public w(Ly1/c;)Ly1/c$b;
    .locals 1

    .line 1
    invoke-static {p1}, Ly1/c;->a(Ly1/c;)I

    move-result v0

    iput v0, p0, Ly1/c$b;->a:I

    invoke-static {p1}, Ly1/c;->b(Ly1/c;)I

    move-result v0

    iput v0, p0, Ly1/c$b;->b:I

    invoke-static {p1}, Ly1/c;->c(Ly1/c;)I

    move-result v0

    iput v0, p0, Ly1/c$b;->c:I

    invoke-static {p1}, Ly1/c;->d(Ly1/c;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->d:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c;->e(Ly1/c;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->e:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c;->f(Ly1/c;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->f:Landroid/graphics/drawable/Drawable;

    invoke-static {p1}, Ly1/c;->g(Ly1/c;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c$b;->g:Z

    invoke-static {p1}, Ly1/c;->h(Ly1/c;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c$b;->h:Z

    invoke-static {p1}, Ly1/c;->i(Ly1/c;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c$b;->i:Z

    invoke-static {p1}, Ly1/c;->j(Ly1/c;)Lz1/d;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->j:Lz1/d;

    invoke-static {p1}, Ly1/c;->k(Ly1/c;)Landroid/graphics/BitmapFactory$Options;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->k:Landroid/graphics/BitmapFactory$Options;

    invoke-static {p1}, Ly1/c;->l(Ly1/c;)I

    move-result v0

    iput v0, p0, Ly1/c$b;->l:I

    invoke-static {p1}, Ly1/c;->m(Ly1/c;)Z

    move-result v0

    iput-boolean v0, p0, Ly1/c$b;->m:Z

    invoke-static {p1}, Ly1/c;->n(Ly1/c;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->n:Ljava/lang/Object;

    invoke-static {p1}, Ly1/c;->o(Ly1/c;)Lg2/a;

    invoke-static {p1}, Ly1/c;->p(Ly1/c;)Lg2/a;

    invoke-static {p1}, Ly1/c;->q(Ly1/c;)Lc2/a;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->o:Lc2/a;

    invoke-static {p1}, Ly1/c;->r(Ly1/c;)Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, Ly1/c$b;->p:Landroid/os/Handler;

    invoke-static {p1}, Ly1/c;->s(Ly1/c;)Z

    move-result p1

    iput-boolean p1, p0, Ly1/c$b;->q:Z

    return-object p0
.end method

.method public x(Lz1/d;)Ly1/c$b;
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/c$b;->j:Lz1/d;

    return-object p0
.end method
