.class final Ly1/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Ly1/f;

.field private final b:Landroid/graphics/Bitmap;

.field private final c:Ly1/g;

.field private final d:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Ly1/f;Landroid/graphics/Bitmap;Ly1/g;Landroid/os/Handler;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ly1/i;->a:Ly1/f;

    iput-object p2, p0, Ly1/i;->b:Landroid/graphics/Bitmap;

    iput-object p3, p0, Ly1/i;->c:Ly1/g;

    iput-object p4, p0, Ly1/i;->d:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v1, p0, Ly1/i;->c:Ly1/g;

    iget-object v1, v1, Ly1/g;->b:Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "PostProcess image before displaying [%s]"

    invoke-static {v1, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, p0, Ly1/i;->c:Ly1/g;

    iget-object v0, v0, Ly1/g;->e:Ly1/c;

    invoke-virtual {v0}, Ly1/c;->D()Lg2/a;

    const/4 v0, 0x0

    throw v0
.end method
