.class Ly1/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ly1/f;->o(Ly1/h;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ly1/h;

.field final synthetic b:Ly1/f;


# direct methods
.method constructor <init>(Ly1/f;Ly1/h;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/f$a;->b:Ly1/f;

    iput-object p2, p0, Ly1/f$a;->a:Ly1/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Ly1/f$a;->b:Ly1/f;

    iget-object v0, v0, Ly1/f;->a:Ly1/e;

    iget-object v0, v0, Ly1/e;->n:Ls1/a;

    iget-object v1, p0, Ly1/f$a;->a:Ly1/h;

    invoke-virtual {v1}, Ly1/h;->n()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ls1/a;->a(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Ly1/f$a;->b:Ly1/f;

    invoke-static {v1}, Ly1/f;->a(Ly1/f;)V

    if-eqz v0, :cond_1

    iget-object v0, p0, Ly1/f$a;->b:Ly1/f;

    invoke-static {v0}, Ly1/f;->b(Ly1/f;)Ljava/util/concurrent/Executor;

    move-result-object v0

    goto :goto_1

    :cond_1
    iget-object v0, p0, Ly1/f$a;->b:Ly1/f;

    invoke-static {v0}, Ly1/f;->c(Ly1/f;)Ljava/util/concurrent/Executor;

    move-result-object v0

    :goto_1
    iget-object v1, p0, Ly1/f$a;->a:Ly1/h;

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
