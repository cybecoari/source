.class Ly1/h$c;
.super Ljava/lang/Exception;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly1/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Ly1/h;


# direct methods
.method constructor <init>(Ly1/h;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/h$c;->a:Ly1/h;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    return-void
.end method
