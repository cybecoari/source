.class final Ly1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;
.implements Lh2/b$a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ly1/h$c;
    }
.end annotation


# instance fields
.field private final a:Ly1/f;

.field private final b:Ly1/g;

.field private final c:Landroid/os/Handler;

.field private final d:Ly1/e;

.field private final f:Ld2/b;

.field private final h:Ld2/b;

.field private final j:Ld2/b;

.field private final k:Lb2/b;

.field final l:Ljava/lang/String;

.field private final m:Ljava/lang/String;

.field final n:Le2/a;

.field private final o:Lz1/e;

.field final p:Ly1/c;

.field final q:Lf2/a;

.field private final r:Z

.field private s:Lz1/f;


# direct methods
.method public constructor <init>(Ly1/f;Ly1/g;Landroid/os/Handler;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lz1/f;->a:Lz1/f;

    iput-object v0, p0, Ly1/h;->s:Lz1/f;

    iput-object p1, p0, Ly1/h;->a:Ly1/f;

    iput-object p2, p0, Ly1/h;->b:Ly1/g;

    iput-object p3, p0, Ly1/h;->c:Landroid/os/Handler;

    iget-object p1, p1, Ly1/f;->a:Ly1/e;

    iput-object p1, p0, Ly1/h;->d:Ly1/e;

    iget-object p3, p1, Ly1/e;->o:Ld2/b;

    iput-object p3, p0, Ly1/h;->f:Ld2/b;

    iget-object p3, p1, Ly1/e;->r:Ld2/b;

    iput-object p3, p0, Ly1/h;->h:Ld2/b;

    iget-object p3, p1, Ly1/e;->s:Ld2/b;

    iput-object p3, p0, Ly1/h;->j:Ld2/b;

    iget-object p1, p1, Ly1/e;->p:Lb2/b;

    iput-object p1, p0, Ly1/h;->k:Lb2/b;

    iget-object p1, p2, Ly1/g;->a:Ljava/lang/String;

    iput-object p1, p0, Ly1/h;->l:Ljava/lang/String;

    iget-object p1, p2, Ly1/g;->b:Ljava/lang/String;

    iput-object p1, p0, Ly1/h;->m:Ljava/lang/String;

    iget-object p1, p2, Ly1/g;->c:Le2/a;

    iput-object p1, p0, Ly1/h;->n:Le2/a;

    iget-object p1, p2, Ly1/g;->d:Lz1/e;

    iput-object p1, p0, Ly1/h;->o:Lz1/e;

    iget-object p1, p2, Ly1/g;->e:Ly1/c;

    iput-object p1, p0, Ly1/h;->p:Ly1/c;

    iget-object p2, p2, Ly1/g;->f:Lf2/a;

    iput-object p2, p0, Ly1/h;->q:Lf2/a;

    invoke-virtual {p1}, Ly1/c;->J()Z

    move-result p1

    iput-boolean p1, p0, Ly1/h;->r:Z

    return-void
.end method

.method static synthetic b(Ly1/h;)Ly1/e;
    .locals 0

    .line 1
    iget-object p0, p0, Ly1/h;->d:Ly1/e;

    return-object p0
.end method

.method private c()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ly1/h;->o()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ly1/h$c;

    invoke-direct {v0, p0}, Ly1/h$c;-><init>(Ly1/h;)V

    throw v0
.end method

.method private d()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ly1/h;->e()V

    invoke-direct {p0}, Ly1/h;->f()V

    return-void
.end method

.method private e()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ly1/h;->q()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ly1/h$c;

    invoke-direct {v0, p0}, Ly1/h$c;-><init>(Ly1/h;)V

    throw v0
.end method

.method private f()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ly1/h;->r()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ly1/h$c;

    invoke-direct {v0, p0}, Ly1/h$c;-><init>(Ly1/h;)V

    throw v0
.end method

.method private g(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 9

    .line 1
    iget-object v0, p0, Ly1/h;->n:Le2/a;

    invoke-interface {v0}, Le2/a;->e()Lz1/h;

    move-result-object v6

    new-instance v0, Lb2/c;

    iget-object v2, p0, Ly1/h;->m:Ljava/lang/String;

    iget-object v4, p0, Ly1/h;->l:Ljava/lang/String;

    iget-object v5, p0, Ly1/h;->o:Lz1/e;

    invoke-direct {p0}, Ly1/h;->m()Ld2/b;

    move-result-object v7

    iget-object v8, p0, Ly1/h;->p:Ly1/c;

    move-object v1, v0

    move-object v3, p1

    invoke-direct/range {v1 .. v8}, Lb2/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lz1/e;Lz1/h;Ld2/b;Ly1/c;)V

    iget-object p1, p0, Ly1/h;->k:Lb2/b;

    invoke-interface {p1, v0}, Lb2/b;->a(Lb2/c;)Landroid/graphics/Bitmap;

    move-result-object p1

    return-object p1
.end method

.method private h()Z
    .locals 6

    .line 1
    iget-object v0, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v0}, Ly1/c;->K()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v2, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v2}, Ly1/c;->v()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    iget-object v2, p0, Ly1/h;->m:Ljava/lang/String;

    const/4 v3, 0x1

    aput-object v2, v0, v3

    const-string v2, "Delay %d ms before loading...  [%s]"

    invoke-static {v2, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :try_start_0
    iget-object v0, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v0}, Ly1/c;->v()I

    move-result v0

    int-to-long v4, v0

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-direct {p0}, Ly1/h;->p()Z

    move-result v0

    return v0

    :catch_0
    new-array v0, v3, [Ljava/lang/Object;

    iget-object v2, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v2, v0, v1

    const-string v1, "Task was interrupted [%s]"

    invoke-static {v1, v0}, Lh2/c;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    return v3

    :cond_0
    return v1
.end method

.method private i()Z
    .locals 3

    .line 1
    invoke-direct {p0}, Ly1/h;->m()Ld2/b;

    move-result-object v0

    iget-object v1, p0, Ly1/h;->l:Ljava/lang/String;

    iget-object v2, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v2}, Ly1/c;->x()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Ld2/b;->a(Ljava/lang/String;Ljava/lang/Object;)Ljava/io/InputStream;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v1, p0, Ly1/h;->m:Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "No stream for image [%s]"

    invoke-static {v1, v0}, Lh2/c;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    return v2

    :cond_0
    :try_start_0
    iget-object v1, p0, Ly1/h;->d:Ly1/e;

    iget-object v1, v1, Ly1/e;->n:Ls1/a;

    iget-object v2, p0, Ly1/h;->l:Ljava/lang/String;

    invoke-interface {v1, v2, v0, p0}, Ls1/a;->b(Ljava/lang/String;Ljava/io/InputStream;Lh2/b$a;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {v0}, Lh2/b;->a(Ljava/io/Closeable;)V

    return v1

    :catchall_0
    move-exception v1

    invoke-static {v0}, Lh2/b;->a(Ljava/io/Closeable;)V

    throw v1
.end method

.method private j()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Ly1/h;->r:Z

    if-nez v0, :cond_1

    invoke-direct {p0}, Ly1/h;->o()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ly1/h$b;

    invoke-direct {v0, p0}, Ly1/h$b;-><init>(Ly1/h;)V

    iget-object v1, p0, Ly1/h;->c:Landroid/os/Handler;

    iget-object v2, p0, Ly1/h;->a:Ly1/f;

    const/4 v3, 0x0

    invoke-static {v0, v3, v1, v2}, Ly1/h;->t(Ljava/lang/Runnable;ZLandroid/os/Handler;Ly1/f;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private k(Lz1/b$a;Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Ly1/h;->r:Z

    if-nez v0, :cond_1

    invoke-direct {p0}, Ly1/h;->o()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Ly1/h;->p()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ly1/h$a;

    invoke-direct {v0, p0, p1, p2}, Ly1/h$a;-><init>(Ly1/h;Lz1/b$a;Ljava/lang/Throwable;)V

    iget-object p1, p0, Ly1/h;->c:Landroid/os/Handler;

    iget-object p2, p0, Ly1/h;->a:Ly1/f;

    const/4 v1, 0x0

    invoke-static {v0, v1, p1, p2}, Ly1/h;->t(Ljava/lang/Runnable;ZLandroid/os/Handler;Ly1/f;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private l(II)Z
    .locals 0

    .line 1
    invoke-direct {p0}, Ly1/h;->o()Z

    move-result p1

    if-nez p1, :cond_1

    invoke-direct {p0}, Ly1/h;->p()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method private m()Ld2/b;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/h;->a:Ly1/f;

    invoke-virtual {v0}, Ly1/f;->l()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ly1/h;->h:Ld2/b;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Ly1/h;->a:Ly1/f;

    invoke-virtual {v0}, Ly1/f;->m()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Ly1/h;->j:Ld2/b;

    goto :goto_0

    :cond_1
    iget-object v0, p0, Ly1/h;->f:Ld2/b;

    :goto_0
    return-object v0
.end method

.method private o()Z
    .locals 4

    .line 1
    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    new-array v2, v0, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v3, v2, v1

    const-string v1, "Task was interrupted [%s]"

    invoke-static {v1, v2}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    return v0

    :cond_0
    return v1
.end method

.method private p()Z
    .locals 1

    .line 1
    invoke-direct {p0}, Ly1/h;->q()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Ly1/h;->r()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private q()Z
    .locals 4

    .line 1
    iget-object v0, p0, Ly1/h;->n:Le2/a;

    invoke-interface {v0}, Le2/a;->a()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    new-array v2, v0, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v3, v2, v1

    const-string v1, "ImageAware was collected by GC. Task is cancelled. [%s]"

    invoke-static {v1, v2}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    return v0

    :cond_0
    return v1
.end method

.method private r()Z
    .locals 4

    .line 1
    iget-object v0, p0, Ly1/h;->a:Ly1/f;

    iget-object v1, p0, Ly1/h;->n:Le2/a;

    invoke-virtual {v0, v1}, Ly1/f;->g(Le2/a;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Ly1/h;->m:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    new-array v0, v1, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v3, v0, v2

    const-string v2, "ImageAware is reused for another image. Task is cancelled. [%s]"

    invoke-static {v2, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    return v1

    :cond_0
    return v2
.end method

.method private s(II)Z
    .locals 10

    .line 1
    iget-object v0, p0, Ly1/h;->d:Ly1/e;

    iget-object v0, v0, Ly1/e;->n:Ls1/a;

    iget-object v1, p0, Ly1/h;->l:Ljava/lang/String;

    invoke-interface {v0, v1}, Ls1/a;->a(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v6, Lz1/e;

    invoke-direct {v6, p1, p2}, Lz1/e;-><init>(II)V

    new-instance p1, Ly1/c$b;

    invoke-direct {p1}, Ly1/c$b;-><init>()V

    iget-object p2, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {p1, p2}, Ly1/c$b;->w(Ly1/c;)Ly1/c$b;

    move-result-object p1

    sget-object p2, Lz1/d;->d:Lz1/d;

    invoke-virtual {p1, p2}, Ly1/c$b;->x(Lz1/d;)Ly1/c$b;

    move-result-object p1

    invoke-virtual {p1}, Ly1/c$b;->t()Ly1/c;

    move-result-object v9

    new-instance p1, Lb2/c;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    sget-object p2, Ld2/b$a;->f:Ld2/b$a;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ld2/b$a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Ly1/h;->l:Ljava/lang/String;

    sget-object v7, Lz1/h;->a:Lz1/h;

    invoke-direct {p0}, Ly1/h;->m()Ld2/b;

    move-result-object v8

    move-object v2, p1

    invoke-direct/range {v2 .. v9}, Lb2/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lz1/e;Lz1/h;Ld2/b;Ly1/c;)V

    iget-object p2, p0, Ly1/h;->k:Lb2/b;

    invoke-interface {p2, p1}, Lb2/b;->a(Lb2/c;)Landroid/graphics/Bitmap;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p2, p0, Ly1/h;->d:Ly1/e;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_0
    if-eqz p1, :cond_1

    iget-object p2, p0, Ly1/h;->d:Ly1/e;

    iget-object p2, p2, Ly1/e;->n:Ls1/a;

    iget-object v0, p0, Ly1/h;->l:Ljava/lang/String;

    invoke-interface {p2, v0, p1}, Ls1/a;->c(Ljava/lang/String;Landroid/graphics/Bitmap;)Z

    move-result p2

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    goto :goto_0

    :cond_1
    const/4 p2, 0x0

    :goto_0
    return p2
.end method

.method static t(Ljava/lang/Runnable;ZLandroid/os/Handler;Ly1/f;)V
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_0
    if-nez p2, :cond_1

    invoke-virtual {p3, p0}, Ly1/f;->f(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p2, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_0
    return-void
.end method

.method private u()Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    iget-object v2, p0, Ly1/h;->m:Ljava/lang/String;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "Cache image on disk [%s]"

    invoke-static {v2, v1}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :try_start_0
    invoke-direct {p0}, Ly1/h;->i()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v2, p0, Ly1/h;->d:Ly1/e;

    iget v4, v2, Ly1/e;->d:I

    iget v2, v2, Ly1/e;->e:I

    if-gtz v4, :cond_0

    if-lez v2, :cond_1

    :cond_0
    const-string v5, "Resize image in disk cache [%s]"

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v6, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v6, v0, v3

    invoke-static {v5, v0}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-direct {p0, v4, v2}, Ly1/h;->s(II)Z
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    move v3, v1

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-static {v0}, Lh2/c;->c(Ljava/lang/Throwable;)V

    :goto_0
    return v3
.end method

.method private v()Landroid/graphics/Bitmap;
    .locals 10

    .line 1
    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Ly1/h;->d:Ly1/e;

    iget-object v1, v1, Ly1/e;->n:Ls1/a;

    iget-object v2, p0, Ly1/h;->l:Ljava/lang/String;

    invoke-interface {v1, v2}, Ls1/a;->a(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v4

    const-wide/16 v6, 0x0

    cmp-long v8, v4, v6

    if-lez v8, :cond_0

    const-string v4, "Load image from disk cache [%s]"

    new-array v5, v3, [Ljava/lang/Object;

    iget-object v6, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v6, v5, v2

    invoke-static {v4, v5}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    sget-object v4, Lz1/f;->b:Lz1/f;

    iput-object v4, p0, Ly1/h;->s:Lz1/f;

    invoke-direct {p0}, Ly1/h;->d()V

    sget-object v4, Ld2/b$a;->f:Ld2/b$a;

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ld2/b$a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Ly1/h;->g(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ly1/h$c; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    goto :goto_0

    :cond_0
    move-object v1, v0

    :goto_0
    if-eqz v1, :cond_1

    :try_start_1
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    if-lez v4, :cond_1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    if-gtz v4, :cond_4

    :cond_1
    const-string v4, "Load image from network [%s]"

    new-array v3, v3, [Ljava/lang/Object;

    iget-object v5, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v5, v3, v2

    invoke-static {v4, v3}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    sget-object v2, Lz1/f;->a:Lz1/f;

    iput-object v2, p0, Ly1/h;->s:Lz1/f;

    iget-object v2, p0, Ly1/h;->l:Ljava/lang/String;

    iget-object v3, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v3}, Ly1/c;->G()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-direct {p0}, Ly1/h;->u()Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v3, p0, Ly1/h;->d:Ly1/e;

    iget-object v3, v3, Ly1/e;->n:Ls1/a;

    iget-object v4, p0, Ly1/h;->l:Ljava/lang/String;

    invoke-interface {v3, v4}, Ls1/a;->a(Ljava/lang/String;)Ljava/io/File;

    move-result-object v3

    if-eqz v3, :cond_2

    sget-object v2, Ld2/b$a;->f:Ld2/b$a;

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ld2/b$a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_2
    invoke-direct {p0}, Ly1/h;->d()V

    invoke-direct {p0, v2}, Ly1/h;->g(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    if-lez v2, :cond_3

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    if-gtz v2, :cond_4

    :cond_3
    sget-object v2, Lz1/b$a;->b:Lz1/b$a;

    invoke-direct {p0, v2, v0}, Ly1/h;->k(Lz1/b$a;Ljava/lang/Throwable;)V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_6
    .catch Ly1/h$c; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_5

    :catchall_0
    move-exception v0

    move-object v9, v1

    move-object v1, v0

    move-object v0, v9

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v9, v1

    move-object v1, v0

    move-object v0, v9

    goto :goto_2

    :catch_1
    move-exception v0

    move-object v9, v1

    move-object v1, v0

    move-object v0, v9

    goto :goto_3

    :catchall_1
    move-exception v1

    :goto_1
    invoke-static {v1}, Lh2/c;->c(Ljava/lang/Throwable;)V

    sget-object v2, Lz1/b$a;->f:Lz1/b$a;

    goto :goto_4

    :catch_2
    move-exception v1

    :goto_2
    invoke-static {v1}, Lh2/c;->c(Ljava/lang/Throwable;)V

    sget-object v2, Lz1/b$a;->d:Lz1/b$a;

    goto :goto_4

    :catch_3
    move-exception v1

    :goto_3
    invoke-static {v1}, Lh2/c;->c(Ljava/lang/Throwable;)V

    sget-object v2, Lz1/b$a;->a:Lz1/b$a;

    :goto_4
    invoke-direct {p0, v2, v1}, Ly1/h;->k(Lz1/b$a;Ljava/lang/Throwable;)V

    move-object v1, v0

    goto :goto_5

    :catch_4
    move-exception v0

    throw v0

    :catch_5
    move-object v1, v0

    :catch_6
    sget-object v2, Lz1/b$a;->c:Lz1/b$a;

    invoke-direct {p0, v2, v0}, Ly1/h;->k(Lz1/b$a;Ljava/lang/Throwable;)V

    :cond_4
    :goto_5
    return-object v1
.end method

.method private w()Z
    .locals 6

    .line 1
    iget-object v0, p0, Ly1/h;->a:Ly1/f;

    invoke-virtual {v0}, Ly1/f;->i()Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Ly1/h;->a:Ly1/f;

    invoke-virtual {v1}, Ly1/f;->j()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    :try_start_0
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "ImageLoader is paused. Waiting...  [%s]"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Object;

    iget-object v4, p0, Ly1/h;->m:Ljava/lang/String;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-static {v0, v3}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object v0, p0, Ly1/h;->a:Ly1/f;

    invoke-virtual {v0}, Ly1/f;->j()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const-string v0, ".. Resume loading [%s]"

    new-array v2, v2, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v3, v2, v5

    invoke-static {v0, v2}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_0

    :catch_0
    const-string v0, "Task was interrupted [%s]"

    new-array v3, v2, [Ljava/lang/Object;

    iget-object v4, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v4, v3, v5

    invoke-static {v0, v3}, Lh2/c;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    monitor-exit v1

    return v2

    :cond_0
    :goto_0
    monitor-exit v1

    goto :goto_1

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :cond_1
    :goto_1
    invoke-direct {p0}, Ly1/h;->p()Z

    move-result v0

    return v0
.end method


# virtual methods
.method public a(II)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ly1/h;->r:Z

    if-nez v0, :cond_1

    invoke-direct {p0, p1, p2}, Ly1/h;->l(II)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method n()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Ly1/h;->l:Ljava/lang/String;

    return-object v0
.end method

.method public run()V
    .locals 8

    .line 1
    invoke-direct {p0}, Ly1/h;->w()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Ly1/h;->h()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Ly1/h;->b:Ly1/g;

    iget-object v0, v0, Ly1/g;->g:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "Start display image task [%s]"

    invoke-static {v3, v2}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->isLocked()Z

    move-result v2

    if-eqz v2, :cond_2

    new-array v2, v1, [Ljava/lang/Object;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v3, v2, v4

    const-string v3, "Image already is loading. Waiting... [%s]"

    invoke-static {v3, v2}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    :try_start_0
    invoke-direct {p0}, Ly1/h;->d()V

    iget-object v2, p0, Ly1/h;->d:Ly1/e;

    iget-object v2, v2, Ly1/e;->m:Lw1/a;

    iget-object v3, p0, Ly1/h;->m:Ljava/lang/String;

    invoke-interface {v2, v3}, Lw1/a;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v3, 0x0

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_0

    :cond_3
    sget-object v5, Lz1/f;->c:Lz1/f;

    iput-object v5, p0, Ly1/h;->s:Lz1/f;

    const-string v5, "...Get cached bitmap from memory after waiting. [%s]"

    new-array v6, v1, [Ljava/lang/Object;

    iget-object v7, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v7, v6, v4

    invoke-static {v5, v6}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_1

    :cond_4
    :goto_0
    invoke-direct {p0}, Ly1/h;->v()Landroid/graphics/Bitmap;

    move-result-object v2
    :try_end_0
    .catch Ly1/h$c; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void

    :cond_5
    :try_start_1
    invoke-direct {p0}, Ly1/h;->d()V

    invoke-direct {p0}, Ly1/h;->c()V

    iget-object v5, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v5}, Ly1/c;->M()Z

    move-result v5

    if-nez v5, :cond_8

    iget-object v5, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v5}, Ly1/c;->F()Z

    move-result v5

    if-eqz v5, :cond_6

    const-string v5, "Cache image in memory [%s]"

    new-array v6, v1, [Ljava/lang/Object;

    iget-object v7, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v7, v6, v4

    invoke-static {v5, v6}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v5, p0, Ly1/h;->d:Ly1/e;

    iget-object v5, v5, Ly1/e;->m:Lw1/a;

    iget-object v6, p0, Ly1/h;->m:Ljava/lang/String;

    invoke-interface {v5, v6, v2}, Lw1/a;->b(Ljava/lang/String;Landroid/graphics/Bitmap;)Z

    :cond_6
    :goto_1
    iget-object v5, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v5}, Ly1/c;->L()Z

    move-result v5

    if-nez v5, :cond_7

    invoke-direct {p0}, Ly1/h;->d()V

    invoke-direct {p0}, Ly1/h;->c()V
    :try_end_1
    .catch Ly1/h$c; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    new-instance v0, Ly1/b;

    iget-object v1, p0, Ly1/h;->b:Ly1/g;

    iget-object v3, p0, Ly1/h;->a:Ly1/f;

    iget-object v4, p0, Ly1/h;->s:Lz1/f;

    invoke-direct {v0, v2, v1, v3, v4}, Ly1/b;-><init>(Landroid/graphics/Bitmap;Ly1/g;Ly1/f;Lz1/f;)V

    iget-boolean v1, p0, Ly1/h;->r:Z

    iget-object v2, p0, Ly1/h;->c:Landroid/os/Handler;

    iget-object v3, p0, Ly1/h;->a:Ly1/f;

    invoke-static {v0, v1, v2, v3}, Ly1/h;->t(Ljava/lang/Runnable;ZLandroid/os/Handler;Ly1/f;)V

    return-void

    :cond_7
    :try_start_2
    const-string v2, "PostProcess image before displaying [%s]"

    new-array v1, v1, [Ljava/lang/Object;

    iget-object v5, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v5, v1, v4

    invoke-static {v2, v1}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v1, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v1}, Ly1/c;->D()Lg2/a;
    :try_end_2
    .catch Ly1/h$c; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :cond_8
    :try_start_4
    const-string v2, "PreProcess image before caching in memory [%s]"

    new-array v1, v1, [Ljava/lang/Object;

    iget-object v5, p0, Ly1/h;->m:Ljava/lang/String;

    aput-object v5, v1, v4

    invoke-static {v2, v1}, Lh2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v1, p0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v1}, Ly1/c;->E()Lg2/a;
    :try_end_4
    .catch Ly1/h$c; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    throw v3

    :catchall_0
    move-exception v1

    goto :goto_2

    :catch_0
    invoke-direct {p0}, Ly1/h;->j()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void

    :goto_2
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    throw v1
.end method
