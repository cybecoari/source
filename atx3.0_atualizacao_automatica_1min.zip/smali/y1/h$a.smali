.class Ly1/h$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ly1/h;->k(Lz1/b$a;Ljava/lang/Throwable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lz1/b$a;

.field final synthetic b:Ljava/lang/Throwable;

.field final synthetic c:Ly1/h;


# direct methods
.method constructor <init>(Ly1/h;Lz1/b$a;Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ly1/h$a;->c:Ly1/h;

    iput-object p2, p0, Ly1/h$a;->a:Lz1/b$a;

    iput-object p3, p0, Ly1/h$a;->b:Ljava/lang/Throwable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 1
    iget-object v0, p0, Ly1/h$a;->c:Ly1/h;

    iget-object v0, v0, Ly1/h;->p:Ly1/c;

    invoke-virtual {v0}, Ly1/c;->O()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ly1/h$a;->c:Ly1/h;

    iget-object v1, v0, Ly1/h;->n:Le2/a;

    iget-object v2, v0, Ly1/h;->p:Ly1/c;

    invoke-static {v0}, Ly1/h;->b(Ly1/h;)Ly1/e;

    move-result-object v0

    iget-object v0, v0, Ly1/e;->a:Landroid/content/res/Resources;

    invoke-virtual {v2, v0}, Ly1/c;->A(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-interface {v1, v0}, Le2/a;->b(Landroid/graphics/drawable/Drawable;)Z

    :cond_0
    iget-object v0, p0, Ly1/h$a;->c:Ly1/h;

    iget-object v1, v0, Ly1/h;->q:Lf2/a;

    iget-object v2, v0, Ly1/h;->l:Ljava/lang/String;

    iget-object v0, v0, Ly1/h;->n:Le2/a;

    invoke-interface {v0}, Le2/a;->f()Landroid/view/View;

    move-result-object v0

    new-instance v3, Lz1/b;

    iget-object v4, p0, Ly1/h$a;->a:Lz1/b$a;

    iget-object v5, p0, Ly1/h$a;->b:Ljava/lang/Throwable;

    invoke-direct {v3, v4, v5}, Lz1/b;-><init>(Lz1/b$a;Ljava/lang/Throwable;)V

    invoke-interface {v1, v2, v0, v3}, Lf2/a;->a(Ljava/lang/String;Landroid/view/View;Lz1/b;)V

    return-void
.end method
