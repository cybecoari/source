.class public Lk2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static c:Lk2/b;

.field private static d:Ljava/util/UUID;


# instance fields
.field private final a:Ljava/util/UUID;

.field private b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    sput-object v0, Lk2/b;->d:Ljava/util/UUID;

    return-void
.end method

.method private constructor <init>(Ljava/util/UUID;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lk2/b;->a:Ljava/util/UUID;

    return-void
.end method

.method public static a(Ljava/util/UUID;Z)Ljava/lang/String;
    .locals 1

    .line 1
    if-nez p0, :cond_0

    sget-object p0, Lk2/b;->d:Ljava/util/UUID;

    :cond_0
    invoke-static {p0}, Lk2/b;->b(Ljava/util/UUID;)Lk2/b;

    move-result-object v0

    iget-object v0, v0, Lk2/b;->b:Ljava/lang/String;

    if-eqz p1, :cond_1

    invoke-static {p0}, Lk2/b;->b(Ljava/util/UUID;)Lk2/b;

    move-result-object p0

    const/4 p1, 0x0

    iput-object p1, p0, Lk2/b;->b:Ljava/lang/String;

    :cond_1
    return-object v0
.end method

.method public static b(Ljava/util/UUID;)Lk2/b;
    .locals 1

    .line 1
    sget-object v0, Lk2/b;->c:Lk2/b;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lk2/b;->a:Ljava/util/UUID;

    invoke-virtual {v0, p0}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    new-instance v0, Lk2/b;

    invoke-direct {v0, p0}, Lk2/b;-><init>(Ljava/util/UUID;)V

    sput-object v0, Lk2/b;->c:Lk2/b;

    :cond_1
    sget-object p0, Lk2/b;->c:Lk2/b;

    return-object p0
.end method
