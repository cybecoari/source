.class public Lu3/a;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lu3/a$a;
    }
.end annotation


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lu3/a$a;

.field private c:Z

.field private d:Lk2/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lu3/a$a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p1, p0, Lu3/a;->a:Landroid/content/Context;

    iput-object p2, p0, Lu3/a;->b:Lu3/a$a;

    if-eqz p1, :cond_0

    new-instance p2, Lk2/c;

    invoke-direct {p2, p1}, Lk2/c;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lu3/a;->d:Lk2/c;

    :cond_0
    return-void
.end method


# virtual methods
.method protected varargs a([Ljava/lang/Void;)Ljava/lang/String;
    .locals 6

    .line 1
    :try_start_0
    const-string p1, ""
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    new-instance v0, Ljava/lang/String;

    const/16 v1, 0x15

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    iget-object v1, p0, Lu3/a;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    move-exception v0

    :try_start_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    new-instance v0, Ljava/lang/String;

    const/16 v1, 0x31

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    new-instance v1, Ljava/lang/String;

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_2

    invoke-direct {v1, v2}, Ljava/lang/String;-><init>([B)V

    new-instance v2, Ljava/lang/String;

    const/16 v3, 0x16

    new-array v3, v3, [B

    fill-array-data v3, :array_3

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    new-instance v3, Ljava/lang/String;

    const/16 v4, 0xa

    new-array v4, v4, [B

    fill-array-data v4, :array_4

    invoke-direct {v3, v4}, Ljava/lang/String;-><init>([B)V

    new-instance v4, Ljava/lang/String;

    const/4 v5, 0x5

    new-array v5, v5, [B

    fill-array-data v5, :array_5

    invoke-direct {v4, v5}, Ljava/lang/String;-><init>([B)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Lv3/y;

    invoke-direct {v0}, Lv3/y;-><init>()V

    new-instance v5, Lv3/a0$a;

    invoke-direct {v5}, Lv3/a0$a;-><init>()V

    invoke-virtual {v5, p1}, Lv3/a0$a;->n(Ljava/lang/String;)Lv3/a0$a;

    move-result-object p1

    invoke-virtual {p1, v1, v2}, Lv3/a0$a;->a(Ljava/lang/String;Ljava/lang/String;)Lv3/a0$a;

    move-result-object p1

    invoke-virtual {p1, v3, v4}, Lv3/a0$a;->a(Ljava/lang/String;Ljava/lang/String;)Lv3/a0$a;

    move-result-object p1

    invoke-virtual {p1}, Lv3/a0$a;->c()Lv3/a0$a;

    move-result-object p1

    invoke-virtual {p1}, Lv3/a0$a;->b()Lv3/a0;

    move-result-object p1

    invoke-virtual {v0, p1}, Lv3/y;->u(Lv3/a0;)Lv3/e;

    move-result-object p1

    invoke-interface {p1}, Lv3/e;->b()Lv3/c0;

    move-result-object p1

    invoke-virtual {p1}, Lv3/c0;->x()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Lv3/c0;->b()Lv3/d0;

    move-result-object p1

    invoke-virtual {p1}, Lv3/d0;->i()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Request failed with code: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lv3/c0;->i()I

    move-result p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return-object p1

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_0
    .array-data 1
        0x63t
        0x6ft
        0x6et
        0x66t
        0x69t
        0x67t
        0x2ft
        0x63t
        0x72t
        0x65t
        0x64t
        0x65t
        0x6et
        0x74t
        0x69t
        0x61t
        0x6ct
        0x2et
        0x74t
        0x78t
        0x74t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x68t
        0x74t
        0x74t
        0x70t
        0x73t
        0x3at
        0x2ft
        0x2ft
        0x70t
        0x61t
        0x69t
        0x6et
        0x65t
        0x6ct
        0x2et
        0x63t
        0x79t
        0x62t
        0x65t
        0x72t
        0x63t
        0x6ft
        0x61t
        0x72t
        0x69t
        0x2et
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x72t
        0x2ft
        0x61t
        0x70t
        0x69t
        0x2ft
        0x61t
        0x74t
        0x78t
        0x2et
        0x70t
        0x68t
        0x70t
        0x3ft
        0x55t
        0x52t
        0x4ct
        0x3dt
    .end array-data

    nop

    :array_2
    .array-data 1
        0x52t
        0x65t
        0x66t
        0x65t
        0x72t
        0x65t
        0x72t
    .end array-data

    :array_3
    .array-data 1
        0x68t
        0x74t
        0x74t
        0x70t
        0x73t
        0x3at
        0x2ft
        0x2ft
        0x78t
        0x76t
        0x69t
        0x64t
        0x65t
        0x6ft
        0x73t
        0x2et
        0x63t
        0x6ft
        0x6dt
        0x2et
        0x62t
        0x72t
    .end array-data

    nop

    :array_4
    .array-data 1
        0x55t
        0x73t
        0x65t
        0x72t
        0x2dt
        0x41t
        0x67t
        0x65t
        0x6et
        0x74t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x75t
        0x72t
        0x75t
        0x62t
        0x75t
    .end array-data
.end method

.method protected b(Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    iget-object v0, p0, Lu3/a;->b:Lu3/a$a;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lu3/a$a;->a(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public c(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lu3/a;->c:Z

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lu3/a;->a([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lu3/a;->b(Ljava/lang/String;)V

    return-void
.end method
