.class public final Ld4/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/g$a;
    }
.end annotation


# static fields
.field public static final g:Ld4/g$a;

.field private static final h:Ljava/util/List;

.field private static final i:Ljava/util/List;


# instance fields
.field private final a:La4/f;

.field private final b:Lb4/g;

.field private final c:Ld4/f;

.field private volatile d:Ld4/i;

.field private final e:Lv3/z;

.field private volatile f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 14

    .line 1
    new-instance v0, Ld4/g$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/g$a;-><init>(Lg3/g;)V

    sput-object v0, Ld4/g;->g:Ld4/g$a;

    const-string v2, "connection"

    const-string v3, "host"

    const-string v4, "keep-alive"

    const-string v5, "proxy-connection"

    const-string v6, "te"

    const-string v7, "transfer-encoding"

    const-string v8, "encoding"

    const-string v9, "upgrade"

    const-string v10, ":method"

    const-string v11, ":path"

    const-string v12, ":scheme"

    const-string v13, ":authority"

    filled-new-array/range {v2 .. v13}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lw3/d;->v([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Ld4/g;->h:Ljava/util/List;

    const-string v1, "connection"

    const-string v2, "host"

    const-string v3, "keep-alive"

    const-string v4, "proxy-connection"

    const-string v5, "te"

    const-string v6, "transfer-encoding"

    const-string v7, "encoding"

    const-string v8, "upgrade"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lw3/d;->v([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Ld4/g;->i:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Lv3/y;La4/f;Lb4/g;Ld4/f;)V
    .locals 1

    .line 1
    const-string v0, "client"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "connection"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "chain"

    invoke-static {p3, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "http2Connection"

    invoke-static {p4, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ld4/g;->a:La4/f;

    iput-object p3, p0, Ld4/g;->b:Lb4/g;

    iput-object p4, p0, Ld4/g;->c:Ld4/f;

    invoke-virtual {p1}, Lv3/y;->w()Ljava/util/List;

    move-result-object p1

    sget-object p2, Lv3/z;->j:Lv3/z;

    invoke-interface {p1, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    sget-object p2, Lv3/z;->h:Lv3/z;

    :goto_0
    iput-object p2, p0, Ld4/g;->e:Lv3/z;

    return-void
.end method

.method public static final synthetic i()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, Ld4/g;->h:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic j()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, Ld4/g;->i:Ljava/util/List;

    return-object v0
.end method


# virtual methods
.method public a(Lv3/c0;)J
    .locals 2

    .line 1
    const-string v0, "response"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lb4/e;->b(Lv3/c0;)Z

    move-result v0

    if-nez v0, :cond_0

    const-wide/16 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-static {p1}, Lw3/d;->u(Lv3/c0;)J

    move-result-wide v0

    :goto_0
    return-wide v0
.end method

.method public b(Lv3/a0;)V
    .locals 3

    .line 1
    const-string v0, "request"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/g;->d:Ld4/i;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Lv3/a0;->a()Lv3/b0;

    move-result-object v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    sget-object v1, Ld4/g;->g:Ld4/g$a;

    invoke-virtual {v1, p1}, Ld4/g$a;->a(Lv3/a0;)Ljava/util/List;

    move-result-object p1

    iget-object v1, p0, Ld4/g;->c:Ld4/f;

    invoke-virtual {v1, p1, v0}, Ld4/f;->i0(Ljava/util/List;Z)Ld4/i;

    move-result-object p1

    iput-object p1, p0, Ld4/g;->d:Ld4/i;

    iget-boolean p1, p0, Ld4/g;->f:Z

    if-nez p1, :cond_2

    iget-object p1, p0, Ld4/g;->d:Ld4/i;

    invoke-static {p1}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ld4/i;->v()Li4/z;

    move-result-object p1

    iget-object v0, p0, Ld4/g;->b:Lb4/g;

    invoke-virtual {v0}, Lb4/g;->h()I

    move-result v0

    int-to-long v0, v0

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p1, v0, v1, v2}, Li4/z;->g(JLjava/util/concurrent/TimeUnit;)Li4/z;

    iget-object p1, p0, Ld4/g;->d:Ld4/i;

    invoke-static {p1}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ld4/i;->G()Li4/z;

    move-result-object p1

    iget-object v0, p0, Ld4/g;->b:Lb4/g;

    invoke-virtual {v0}, Lb4/g;->j()I

    move-result v0

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1, v2}, Li4/z;->g(JLjava/util/concurrent/TimeUnit;)Li4/z;

    return-void

    :cond_2
    iget-object p1, p0, Ld4/g;->d:Ld4/i;

    invoke-static {p1}, Lg3/k;->b(Ljava/lang/Object;)V

    sget-object v0, Ld4/b;->n:Ld4/b;

    invoke-virtual {p1, v0}, Ld4/i;->f(Ld4/b;)V

    new-instance p1, Ljava/io/IOException;

    const-string v0, "Canceled"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public c()V
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/g;->d:Ld4/i;

    invoke-static {v0}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-virtual {v0}, Ld4/i;->n()Li4/w;

    move-result-object v0

    invoke-interface {v0}, Li4/w;->close()V

    return-void
.end method

.method public cancel()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Ld4/g;->f:Z

    iget-object v0, p0, Ld4/g;->d:Ld4/i;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v1, Ld4/b;->n:Ld4/b;

    invoke-virtual {v0, v1}, Ld4/i;->f(Ld4/b;)V

    :goto_0
    return-void
.end method

.method public d()V
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/g;->c:Ld4/f;

    invoke-virtual {v0}, Ld4/f;->flush()V

    return-void
.end method

.method public e(Lv3/c0;)Li4/y;
    .locals 1

    .line 1
    const-string v0, "response"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Ld4/g;->d:Ld4/i;

    invoke-static {p1}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ld4/i;->p()Ld4/i$c;

    move-result-object p1

    return-object p1
.end method

.method public f(Z)Lv3/c0$a;
    .locals 3

    .line 1
    iget-object v0, p0, Ld4/g;->d:Ld4/i;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ld4/i;->E()Lv3/u;

    move-result-object v0

    sget-object v1, Ld4/g;->g:Ld4/g$a;

    iget-object v2, p0, Ld4/g;->e:Lv3/z;

    invoke-virtual {v1, v0, v2}, Ld4/g$a;->b(Lv3/u;Lv3/z;)Lv3/c0$a;

    move-result-object v0

    if-eqz p1, :cond_0

    invoke-virtual {v0}, Lv3/c0$a;->h()I

    move-result p1

    const/16 v1, 0x64

    if-ne p1, v1, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "stream wasn\'t created"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public g(Lv3/a0;J)Li4/w;
    .locals 0

    .line 1
    const-string p2, "request"

    invoke-static {p1, p2}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Ld4/g;->d:Ld4/i;

    invoke-static {p1}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ld4/i;->n()Li4/w;

    move-result-object p1

    return-object p1
.end method

.method public h()La4/f;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/g;->a:La4/f;

    return-object v0
.end method
