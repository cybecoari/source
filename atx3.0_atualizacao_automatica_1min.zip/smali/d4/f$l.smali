.class public final Ld4/f$l;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f;->C0(IJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Z

.field final synthetic g:Ld4/f;

.field final synthetic h:I

.field final synthetic i:J


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLd4/f;IJ)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$l;->e:Ljava/lang/String;

    iput-boolean p2, p0, Ld4/f$l;->f:Z

    iput-object p3, p0, Ld4/f$l;->g:Ld4/f;

    iput p4, p0, Ld4/f$l;->h:I

    iput-wide p5, p0, Ld4/f$l;->i:J

    invoke-direct {p0, p1, p2}, Lz3/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 4

    .line 1
    :try_start_0
    iget-object v0, p0, Ld4/f$l;->g:Ld4/f;

    invoke-virtual {v0}, Ld4/f;->f0()Ld4/j;

    move-result-object v0

    iget v1, p0, Ld4/f$l;->h:I

    iget-wide v2, p0, Ld4/f$l;->i:J

    invoke-virtual {v0, v1, v2, v3}, Ld4/j;->A(IJ)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    iget-object v1, p0, Ld4/f$l;->g:Ld4/f;

    invoke-static {v1, v0}, Ld4/f;->b(Ld4/f;Ljava/io/IOException;)V

    :goto_0
    const-wide/16 v0, -0x1

    return-wide v0
.end method
