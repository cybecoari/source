.class public abstract Ld4/f$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/f$c$b;
    }
.end annotation


# static fields
.field public static final a:Ld4/f$c$b;

.field public static final b:Ld4/f$c;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ld4/f$c$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/f$c$b;-><init>(Lg3/g;)V

    sput-object v0, Ld4/f$c;->a:Ld4/f$c$b;

    new-instance v0, Ld4/f$c$a;

    invoke-direct {v0}, Ld4/f$c$a;-><init>()V

    sput-object v0, Ld4/f$c;->b:Ld4/f$c;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ld4/f;Ld4/m;)V
    .locals 1

    .line 1
    const-string v0, "connection"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "settings"

    invoke-static {p2, p1}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public abstract b(Ld4/i;)V
.end method
