.class public final Ld4/f$c$a;
.super Ld4/f$c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ld4/f$c;-><init>()V

    return-void
.end method


# virtual methods
.method public b(Ld4/i;)V
    .locals 2

    .line 1
    const-string v0, "stream"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Ld4/b;->m:Ld4/b;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Ld4/i;->d(Ld4/b;Ljava/io/IOException;)V

    return-void
.end method
