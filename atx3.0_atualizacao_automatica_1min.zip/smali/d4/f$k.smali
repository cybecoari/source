.class public final Ld4/f$k;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f;->B0(ILd4/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Z

.field final synthetic g:Ld4/f;

.field final synthetic h:I

.field final synthetic i:Ld4/b;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLd4/f;ILd4/b;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$k;->e:Ljava/lang/String;

    iput-boolean p2, p0, Ld4/f$k;->f:Z

    iput-object p3, p0, Ld4/f$k;->g:Ld4/f;

    iput p4, p0, Ld4/f$k;->h:I

    iput-object p5, p0, Ld4/f$k;->i:Ld4/b;

    invoke-direct {p0, p1, p2}, Lz3/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, Ld4/f$k;->g:Ld4/f;

    iget v1, p0, Ld4/f$k;->h:I

    iget-object v2, p0, Ld4/f$k;->i:Ld4/b;

    invoke-virtual {v0, v1, v2}, Ld4/f;->A0(ILd4/b;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    iget-object v1, p0, Ld4/f$k;->g:Ld4/f;

    invoke-static {v1, v0}, Ld4/f;->b(Ld4/f;Ljava/io/IOException;)V

    :goto_0
    const-wide/16 v0, -0x1

    return-wide v0
.end method
