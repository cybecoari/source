.class public final Ld4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/f$a;,
        Ld4/f$d;,
        Ld4/f$c;,
        Ld4/f$b;
    }
.end annotation


# static fields
.field public static final F:Ld4/f$b;

.field private static final G:Ld4/m;


# instance fields
.field private A:J

.field private final B:Ljava/net/Socket;

.field private final C:Ld4/j;

.field private final D:Ld4/f$d;

.field private final E:Ljava/util/Set;

.field private final a:Z

.field private final b:Ld4/f$c;

.field private final c:Ljava/util/Map;

.field private final d:Ljava/lang/String;

.field private f:I

.field private h:I

.field private j:Z

.field private final k:Lz3/e;

.field private final l:Lz3/d;

.field private final m:Lz3/d;

.field private final n:Lz3/d;

.field private final o:Ld4/l;

.field private p:J

.field private q:J

.field private r:J

.field private s:J

.field private t:J

.field private u:J

.field private final v:Ld4/m;

.field private w:Ld4/m;

.field private x:J

.field private y:J

.field private z:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ld4/f$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/f$b;-><init>(Lg3/g;)V

    sput-object v0, Ld4/f;->F:Ld4/f$b;

    new-instance v0, Ld4/m;

    invoke-direct {v0}, Ld4/m;-><init>()V

    const/4 v1, 0x7

    const v2, 0xffff

    invoke-virtual {v0, v1, v2}, Ld4/m;->h(II)Ld4/m;

    const/4 v1, 0x5

    const/16 v2, 0x4000

    invoke-virtual {v0, v1, v2}, Ld4/m;->h(II)Ld4/m;

    sput-object v0, Ld4/f;->G:Ld4/m;

    return-void
.end method

.method public constructor <init>(Ld4/f$a;)V
    .locals 6

    .line 1
    const-string v0, "builder"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ld4/f$a;->b()Z

    move-result v0

    iput-boolean v0, p0, Ld4/f;->a:Z

    invoke-virtual {p1}, Ld4/f$a;->d()Ld4/f$c;

    move-result-object v1

    iput-object v1, p0, Ld4/f;->b:Ld4/f$c;

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v1, p0, Ld4/f;->c:Ljava/util/Map;

    invoke-virtual {p1}, Ld4/f$a;->c()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {p1}, Ld4/f$a;->b()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    iput v2, p0, Ld4/f;->h:I

    invoke-virtual {p1}, Ld4/f$a;->j()Lz3/e;

    move-result-object v2

    iput-object v2, p0, Ld4/f;->k:Lz3/e;

    invoke-virtual {v2}, Lz3/e;->i()Lz3/d;

    move-result-object v3

    iput-object v3, p0, Ld4/f;->l:Lz3/d;

    invoke-virtual {v2}, Lz3/e;->i()Lz3/d;

    move-result-object v4

    iput-object v4, p0, Ld4/f;->m:Lz3/d;

    invoke-virtual {v2}, Lz3/e;->i()Lz3/d;

    move-result-object v2

    iput-object v2, p0, Ld4/f;->n:Lz3/d;

    invoke-virtual {p1}, Ld4/f$a;->f()Ld4/l;

    move-result-object v2

    iput-object v2, p0, Ld4/f;->o:Ld4/l;

    new-instance v2, Ld4/m;

    invoke-direct {v2}, Ld4/m;-><init>()V

    invoke-virtual {p1}, Ld4/f$a;->b()Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 v4, 0x7

    const/high16 v5, 0x1000000

    invoke-virtual {v2, v4, v5}, Ld4/m;->h(II)Ld4/m;

    :cond_1
    iput-object v2, p0, Ld4/f;->v:Ld4/m;

    sget-object v2, Ld4/f;->G:Ld4/m;

    iput-object v2, p0, Ld4/f;->w:Ld4/m;

    invoke-virtual {v2}, Ld4/m;->c()I

    move-result v2

    int-to-long v4, v2

    iput-wide v4, p0, Ld4/f;->A:J

    invoke-virtual {p1}, Ld4/f$a;->h()Ljava/net/Socket;

    move-result-object v2

    iput-object v2, p0, Ld4/f;->B:Ljava/net/Socket;

    new-instance v2, Ld4/j;

    invoke-virtual {p1}, Ld4/f$a;->g()Li4/c;

    move-result-object v4

    invoke-direct {v2, v4, v0}, Ld4/j;-><init>(Li4/c;Z)V

    iput-object v2, p0, Ld4/f;->C:Ld4/j;

    new-instance v2, Ld4/f$d;

    new-instance v4, Ld4/h;

    invoke-virtual {p1}, Ld4/f$a;->i()Li4/d;

    move-result-object v5

    invoke-direct {v4, v5, v0}, Ld4/h;-><init>(Li4/d;Z)V

    invoke-direct {v2, p0, v4}, Ld4/f$d;-><init>(Ld4/f;Ld4/h;)V

    iput-object v2, p0, Ld4/f;->D:Ld4/f$d;

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Ld4/f;->E:Ljava/util/Set;

    invoke-virtual {p1}, Ld4/f$a;->e()I

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p1}, Ld4/f$a;->e()I

    move-result p1

    int-to-long v4, p1

    invoke-virtual {v0, v4, v5}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v4

    const-string p1, " ping"

    invoke-static {v1, p1}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ld4/f$j;

    invoke-direct {v0, p1, p0, v4, v5}, Ld4/f$j;-><init>(Ljava/lang/String;Ld4/f;J)V

    invoke-virtual {v3, v0, v4, v5}, Lz3/d;->i(Lz3/a;J)V

    :cond_2
    return-void
.end method

.method public static final synthetic A(Ld4/f;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Ld4/f;->t:J

    return-void
.end method

.method public static final synthetic B(Ld4/f;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Ld4/f;->s:J

    return-void
.end method

.method public static final synthetic C(Ld4/f;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Ld4/f;->p:J

    return-void
.end method

.method public static final synthetic E(Ld4/f;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Ld4/f;->q:J

    return-void
.end method

.method public static final synthetic J(Ld4/f;Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Ld4/f;->j:Z

    return-void
.end method

.method public static final synthetic L(Ld4/f;J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Ld4/f;->A:J

    return-void
.end method

.method private final S(Ljava/io/IOException;)V
    .locals 1

    .line 1
    sget-object v0, Ld4/b;->d:Ld4/b;

    invoke-virtual {p0, v0, v0, p1}, Ld4/f;->R(Ld4/b;Ld4/b;Ljava/io/IOException;)V

    return-void
.end method

.method public static final synthetic b(Ld4/f;Ljava/io/IOException;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Ld4/f;->S(Ljava/io/IOException;)V

    return-void
.end method

.method public static final synthetic c(Ld4/f;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->t:J

    return-wide v0
.end method

.method public static final synthetic f(Ld4/f;)Ljava/util/Set;
    .locals 0

    .line 1
    iget-object p0, p0, Ld4/f;->E:Ljava/util/Set;

    return-object p0
.end method

.method public static final synthetic g()Ld4/m;
    .locals 1

    .line 1
    sget-object v0, Ld4/f;->G:Ld4/m;

    return-object v0
.end method

.method private final h0(ILjava/util/List;Z)Ld4/i;
    .locals 10

    .line 1
    xor-int/lit8 v6, p3, 0x1

    const/4 v4, 0x0

    iget-object v7, p0, Ld4/f;->C:Ld4/j;

    monitor-enter v7

    :try_start_0
    monitor-enter p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {p0}, Ld4/f;->X()I

    move-result v0

    const v1, 0x3fffffff    # 1.9999999f

    if-le v0, v1, :cond_0

    sget-object v0, Ld4/b;->m:Ld4/b;

    invoke-virtual {p0, v0}, Ld4/f;->t0(Ld4/b;)V

    :cond_0
    iget-boolean v0, p0, Ld4/f;->j:Z

    if-nez v0, :cond_7

    invoke-virtual {p0}, Ld4/f;->X()I

    move-result v8

    invoke-virtual {p0}, Ld4/f;->X()I

    move-result v0

    add-int/lit8 v0, v0, 0x2

    invoke-virtual {p0, v0}, Ld4/f;->r0(I)V

    new-instance v9, Ld4/i;

    const/4 v5, 0x0

    move-object v0, v9

    move v1, v8

    move-object v2, p0

    move v3, v6

    invoke-direct/range {v0 .. v5}, Ld4/i;-><init>(ILd4/f;ZZLv3/u;)V

    const/4 v0, 0x1

    if-eqz p3, :cond_2

    invoke-virtual {p0}, Ld4/f;->e0()J

    move-result-wide v1

    invoke-virtual {p0}, Ld4/f;->d0()J

    move-result-wide v3

    cmp-long p3, v1, v3

    if-gez p3, :cond_2

    invoke-virtual {v9}, Ld4/i;->r()J

    move-result-wide v1

    invoke-virtual {v9}, Ld4/i;->q()J

    move-result-wide v3

    cmp-long p3, v1, v3

    if-ltz p3, :cond_1

    goto :goto_0

    :cond_1
    const/4 p3, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 p3, 0x1

    :goto_1
    invoke-virtual {v9}, Ld4/i;->u()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object v1

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    sget-object v1, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit p0

    if-nez p1, :cond_4

    invoke-virtual {p0}, Ld4/f;->f0()Ld4/j;

    move-result-object p1

    invoke-virtual {p1, v6, v8, p2}, Ld4/j;->k(ZILjava/util/List;)V

    goto :goto_2

    :cond_4
    invoke-virtual {p0}, Ld4/f;->T()Z

    move-result v1

    xor-int/2addr v0, v1

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Ld4/f;->f0()Ld4/j;

    move-result-object v0

    invoke-virtual {v0, p1, v8, p2}, Ld4/j;->t(IILjava/util/List;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_2
    monitor-exit v7

    if-eqz p3, :cond_5

    iget-object p1, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {p1}, Ld4/j;->flush()V

    :cond_5
    return-object v9

    :cond_6
    :try_start_3
    const-string p1, "client streams shouldn\'t have associated stream IDs"

    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_7
    :try_start_4
    new-instance p1, Ld4/a;

    invoke-direct {p1}, Ld4/a;-><init>()V

    throw p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catchall_0
    move-exception p1

    :try_start_5
    monitor-exit p0

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :catchall_1
    move-exception p1

    monitor-exit v7

    throw p1
.end method

.method public static final synthetic i(Ld4/f;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->s:J

    return-wide v0
.end method

.method public static final synthetic j(Ld4/f;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->p:J

    return-wide v0
.end method

.method public static final synthetic k(Ld4/f;)J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->q:J

    return-wide v0
.end method

.method public static final synthetic l(Ld4/f;)Ld4/l;
    .locals 0

    .line 1
    iget-object p0, p0, Ld4/f;->o:Ld4/l;

    return-object p0
.end method

.method public static final synthetic o(Ld4/f;)Lz3/d;
    .locals 0

    .line 1
    iget-object p0, p0, Ld4/f;->n:Lz3/d;

    return-object p0
.end method

.method public static final synthetic t(Ld4/f;)Lz3/e;
    .locals 0

    .line 1
    iget-object p0, p0, Ld4/f;->k:Lz3/e;

    return-object p0
.end method

.method public static synthetic v0(Ld4/f;ZLz3/e;ILjava/lang/Object;)V
    .locals 0

    .line 1
    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    const/4 p1, 0x1

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    sget-object p2, Lz3/e;->i:Lz3/e;

    :cond_1
    invoke-virtual {p0, p1, p2}, Ld4/f;->u0(ZLz3/e;)V

    return-void
.end method

.method public static final synthetic x(Ld4/f;)Lz3/d;
    .locals 0

    .line 1
    iget-object p0, p0, Ld4/f;->l:Lz3/d;

    return-object p0
.end method

.method public static final synthetic y(Ld4/f;)Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Ld4/f;->j:Z

    return p0
.end method


# virtual methods
.method public final A0(ILd4/b;)V
    .locals 1

    .line 1
    const-string v0, "statusCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {v0, p1, p2}, Ld4/j;->x(ILd4/b;)V

    return-void
.end method

.method public final B0(ILd4/b;)V
    .locals 9

    .line 1
    const-string v0, "errorCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->l:Lz3/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x5b

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] writeSynReset"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$k;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-object v8, p2

    invoke-direct/range {v3 .. v8}, Ld4/f$k;-><init>(Ljava/lang/String;ZLd4/f;ILd4/b;)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final C0(IJ)V
    .locals 10

    .line 1
    iget-object v0, p0, Ld4/f;->l:Lz3/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x5b

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] windowUpdate"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$l;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-wide v8, p2

    invoke-direct/range {v3 .. v9}, Ld4/f$l;-><init>(Ljava/lang/String;ZLd4/f;IJ)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final R(Ld4/b;Ld4/b;Ljava/io/IOException;)V
    .locals 3

    .line 1
    const-string v0, "connectionCode"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "streamCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-boolean v0, Lw3/d;->h:Z

    if-eqz v0, :cond_1

    invoke-static {p0}, Ljava/lang/Thread;->holdsLock(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/AssertionError;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Thread "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, " MUST NOT hold lock on "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :cond_1
    :goto_0
    :try_start_0
    invoke-virtual {p0, p1}, Ld4/f;->t0(Ld4/b;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    monitor-enter p0

    :try_start_1
    invoke-virtual {p0}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    const/4 v0, 0x0

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    new-array v1, v0, [Ld4/i;

    invoke-interface {p1, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    goto :goto_1

    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    const/4 p1, 0x0

    :goto_1
    sget-object v1, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    check-cast p1, [Ld4/i;

    if-nez p1, :cond_4

    goto :goto_3

    :cond_4
    array-length v1, p1

    :goto_2
    if-ge v0, v1, :cond_5

    aget-object v2, p1, v0

    :try_start_2
    invoke-virtual {v2, p2, p3}, Ld4/i;->d(Ld4/b;Ljava/io/IOException;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_5
    :goto_3
    :try_start_3
    invoke-virtual {p0}, Ld4/f;->f0()Ld4/j;

    move-result-object p1

    invoke-virtual {p1}, Ld4/j;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :try_start_4
    invoke-virtual {p0}, Ld4/f;->a0()Ljava/net/Socket;

    move-result-object p1

    invoke-virtual {p1}, Ljava/net/Socket;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    :catch_3
    iget-object p1, p0, Ld4/f;->l:Lz3/d;

    invoke-virtual {p1}, Lz3/d;->o()V

    iget-object p1, p0, Ld4/f;->m:Lz3/d;

    invoke-virtual {p1}, Lz3/d;->o()V

    iget-object p1, p0, Ld4/f;->n:Lz3/d;

    invoke-virtual {p1}, Lz3/d;->o()V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final T()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld4/f;->a:Z

    return v0
.end method

.method public final U()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->d:Ljava/lang/String;

    return-object v0
.end method

.method public final V()I
    .locals 1

    .line 1
    iget v0, p0, Ld4/f;->f:I

    return v0
.end method

.method public final W()Ld4/f$c;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->b:Ld4/f$c;

    return-object v0
.end method

.method public final X()I
    .locals 1

    .line 1
    iget v0, p0, Ld4/f;->h:I

    return v0
.end method

.method public final Y()Ld4/m;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->v:Ld4/m;

    return-object v0
.end method

.method public final Z()Ld4/m;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->w:Ld4/m;

    return-object v0
.end method

.method public final a0()Ljava/net/Socket;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->B:Ljava/net/Socket;

    return-object v0
.end method

.method public final declared-synchronized b0(I)Ld4/i;
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ld4/f;->c:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld4/i;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final c0()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->c:Ljava/util/Map;

    return-object v0
.end method

.method public close()V
    .locals 3

    .line 1
    sget-object v0, Ld4/b;->c:Ld4/b;

    sget-object v1, Ld4/b;->n:Ld4/b;

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v1, v2}, Ld4/f;->R(Ld4/b;Ld4/b;Ljava/io/IOException;)V

    return-void
.end method

.method public final d0()J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->A:J

    return-wide v0
.end method

.method public final e0()J
    .locals 2

    .line 1
    iget-wide v0, p0, Ld4/f;->z:J

    return-wide v0
.end method

.method public final f0()Ld4/j;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    return-object v0
.end method

.method public final flush()V
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {v0}, Ld4/j;->flush()V

    return-void
.end method

.method public final declared-synchronized g0(J)Z
    .locals 6

    .line 1
    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, Ld4/f;->j:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    monitor-exit p0

    return v1

    :cond_0
    :try_start_1
    iget-wide v2, p0, Ld4/f;->s:J

    iget-wide v4, p0, Ld4/f;->r:J

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    iget-wide v2, p0, Ld4/f;->u:J
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    cmp-long v0, p1, v2

    if-ltz v0, :cond_1

    monitor-exit p0

    return v1

    :cond_1
    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final i0(Ljava/util/List;Z)Ld4/i;
    .locals 1

    .line 1
    const-string v0, "requestHeaders"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0, p1, p2}, Ld4/f;->h0(ILjava/util/List;Z)Ld4/i;

    move-result-object p1

    return-object p1
.end method

.method public final j0(ILi4/d;IZ)V
    .locals 9

    .line 1
    const-string v0, "source"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v6, Li4/b;

    invoke-direct {v6}, Li4/b;-><init>()V

    int-to-long v0, p3

    invoke-interface {p2, v0, v1}, Li4/d;->H(J)V

    invoke-interface {p2, v6, v0, v1}, Li4/y;->G(Li4/b;J)J

    iget-object p2, p0, Ld4/f;->m:Lz3/d;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "] onData"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-instance v0, Ld4/f$e;

    move-object v1, v0

    move-object v4, p0

    move v5, p1

    move v7, p3

    move v8, p4

    invoke-direct/range {v1 .. v8}, Ld4/f$e;-><init>(Ljava/lang/String;ZLd4/f;ILi4/b;IZ)V

    const-wide/16 p3, 0x0

    invoke-virtual {p2, v0, p3, p4}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final k0(ILjava/util/List;Z)V
    .locals 10

    .line 1
    const-string v0, "requestHeaders"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->m:Lz3/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x5b

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] onHeaders"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$f;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-object v8, p2

    move v9, p3

    invoke-direct/range {v3 .. v9}, Ld4/f$f;-><init>(Ljava/lang/String;ZLd4/f;ILjava/util/List;Z)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final l0(ILjava/util/List;)V
    .locals 9

    .line 1
    const-string v0, "requestHeaders"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ld4/f;->E:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p2, Ld4/b;->d:Ld4/b;

    invoke-virtual {p0, p1, p2}, Ld4/f;->B0(ILd4/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    iget-object v0, p0, Ld4/f;->E:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    iget-object v0, p0, Ld4/f;->m:Lz3/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x5b

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] onRequest"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$g;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-object v8, p2

    invoke-direct/range {v3 .. v8}, Ld4/f$g;-><init>(Ljava/lang/String;ZLd4/f;ILjava/util/List;)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final m0(ILd4/b;)V
    .locals 9

    .line 1
    const-string v0, "errorCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->m:Lz3/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Ld4/f;->d:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x5b

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] onReset"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$h;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-object v8, p2

    invoke-direct/range {v3 .. v8}, Ld4/f$h;-><init>(Ljava/lang/String;ZLd4/f;ILd4/b;)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final n0(I)Z
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    const/4 v0, 0x1

    and-int/2addr p1, v0

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final declared-synchronized o0(I)Ld4/i;
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ld4/f;->c:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld4/i;

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final p0()V
    .locals 5

    .line 1
    monitor-enter p0

    :try_start_0
    iget-wide v0, p0, Ld4/f;->s:J

    iget-wide v2, p0, Ld4/f;->r:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    cmp-long v4, v0, v2

    if-gez v4, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    const-wide/16 v0, 0x1

    add-long/2addr v2, v0

    :try_start_1
    iput-wide v2, p0, Ld4/f;->r:J

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    const v2, 0x3b9aca00

    int-to-long v2, v2

    add-long/2addr v0, v2

    iput-wide v0, p0, Ld4/f;->u:J

    sget-object v0, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    iget-object v0, p0, Ld4/f;->l:Lz3/d;

    iget-object v1, p0, Ld4/f;->d:Ljava/lang/String;

    const-string v2, " ping"

    invoke-static {v1, v2}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ld4/f$i;

    const/4 v3, 0x1

    invoke-direct {v2, v1, v3, p0}, Ld4/f$i;-><init>(Ljava/lang/String;ZLd4/f;)V

    const-wide/16 v3, 0x0

    invoke-virtual {v0, v2, v3, v4}, Lz3/d;->i(Lz3/a;J)V

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final q0(I)V
    .locals 0

    .line 1
    iput p1, p0, Ld4/f;->f:I

    return-void
.end method

.method public final r0(I)V
    .locals 0

    .line 1
    iput p1, p0, Ld4/f;->h:I

    return-void
.end method

.method public final s0(Ld4/m;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f;->w:Ld4/m;

    return-void
.end method

.method public final t0(Ld4/b;)V
    .locals 4

    .line 1
    const-string v0, "statusCode"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    monitor-enter v0

    :try_start_0
    new-instance v1, Lg3/q;

    invoke-direct {v1}, Lg3/q;-><init>()V

    monitor-enter p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-boolean v2, p0, Ld4/f;->j:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v2, :cond_0

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v0

    return-void

    :cond_0
    const/4 v2, 0x1

    :try_start_3
    iput-boolean v2, p0, Ld4/f;->j:Z

    invoke-virtual {p0}, Ld4/f;->V()I

    move-result v2

    iput v2, v1, Lg3/q;->a:I

    sget-object v2, Lt2/r;->a:Lt2/r;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    monitor-exit p0

    invoke-virtual {p0}, Ld4/f;->f0()Ld4/j;

    move-result-object v2

    iget v1, v1, Lg3/q;->a:I

    sget-object v3, Lw3/d;->a:[B

    invoke-virtual {v2, v1, p1, v3}, Ld4/j;->j(ILd4/b;[B)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    :try_start_5
    monitor-exit p0

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :catchall_1
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public final u0(ZLz3/e;)V
    .locals 4

    .line 1
    const-string v0, "taskRunner"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p1, :cond_0

    iget-object p1, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {p1}, Ld4/j;->c()V

    iget-object p1, p0, Ld4/f;->C:Ld4/j;

    iget-object v0, p0, Ld4/f;->v:Ld4/m;

    invoke-virtual {p1, v0}, Ld4/j;->y(Ld4/m;)V

    iget-object p1, p0, Ld4/f;->v:Ld4/m;

    invoke-virtual {p1}, Ld4/m;->c()I

    move-result p1

    const v0, 0xffff

    if-eq p1, v0, :cond_0

    iget-object v1, p0, Ld4/f;->C:Ld4/j;

    sub-int/2addr p1, v0

    int-to-long v2, p1

    const/4 p1, 0x0

    invoke-virtual {v1, p1, v2, v3}, Ld4/j;->A(IJ)V

    :cond_0
    invoke-virtual {p2}, Lz3/e;->i()Lz3/d;

    move-result-object p1

    iget-object p2, p0, Ld4/f;->d:Ljava/lang/String;

    iget-object v0, p0, Ld4/f;->D:Ld4/f$d;

    new-instance v1, Lz3/c;

    const/4 v2, 0x1

    invoke-direct {v1, p2, v2, v0}, Lz3/c;-><init>(Ljava/lang/String;ZLf3/a;)V

    const-wide/16 v2, 0x0

    invoke-virtual {p1, v1, v2, v3}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public final declared-synchronized w0(J)V
    .locals 3

    .line 1
    monitor-enter p0

    :try_start_0
    iget-wide v0, p0, Ld4/f;->x:J

    add-long/2addr v0, p1

    iput-wide v0, p0, Ld4/f;->x:J

    iget-wide p1, p0, Ld4/f;->y:J

    sub-long/2addr v0, p1

    iget-object p1, p0, Ld4/f;->v:Ld4/m;

    invoke-virtual {p1}, Ld4/m;->c()I

    move-result p1

    div-int/lit8 p1, p1, 0x2

    int-to-long p1, p1

    cmp-long v2, v0, p1

    if-ltz v2, :cond_0

    const/4 p1, 0x0

    invoke-virtual {p0, p1, v0, v1}, Ld4/f;->C0(IJ)V

    iget-wide p1, p0, Ld4/f;->y:J

    add-long/2addr p1, v0

    iput-wide p1, p0, Ld4/f;->y:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final x0(IZLi4/b;J)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    const-wide/16 v1, 0x0

    cmp-long v3, p4, v1

    if-nez v3, :cond_0

    iget-object p4, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {p4, p2, p1, p3, v0}, Ld4/j;->f(ZILi4/b;I)V

    return-void

    :cond_0
    :goto_0
    cmp-long v3, p4, v1

    if-lez v3, :cond_4

    monitor-enter p0

    :goto_1
    :try_start_0
    invoke-virtual {p0}, Ld4/f;->e0()J

    move-result-wide v3

    invoke-virtual {p0}, Ld4/f;->d0()J

    move-result-wide v5

    cmp-long v7, v3, v5

    if-ltz v7, :cond_2

    invoke-virtual {p0}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {p0}, Ljava/lang/Object;->wait()V

    goto :goto_1

    :cond_1
    new-instance p1, Ljava/io/IOException;

    const-string p2, "stream closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    :try_start_1
    invoke-virtual {p0}, Ld4/f;->d0()J

    move-result-wide v3

    invoke-virtual {p0}, Ld4/f;->e0()J

    move-result-wide v5

    sub-long/2addr v3, v5

    invoke-static {p4, p5, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    long-to-int v4, v3

    invoke-virtual {p0}, Ld4/f;->f0()Ld4/j;

    move-result-object v3

    invoke-virtual {v3}, Ld4/j;->l()I

    move-result v3

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-virtual {p0}, Ld4/f;->e0()J

    move-result-wide v4

    int-to-long v6, v3

    add-long/2addr v4, v6

    iput-wide v4, p0, Ld4/f;->z:J

    sget-object v4, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    sub-long/2addr p4, v6

    iget-object v4, p0, Ld4/f;->C:Ld4/j;

    if-eqz p2, :cond_3

    cmp-long v5, p4, v1

    if-nez v5, :cond_3

    const/4 v5, 0x1

    goto :goto_2

    :cond_3
    const/4 v5, 0x0

    :goto_2
    invoke-virtual {v4, v5, p1, p3, v3}, Ld4/j;->f(ZILi4/b;I)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :catch_0
    :try_start_2
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_3
    monitor-exit p0

    throw p1

    :cond_4
    return-void
.end method

.method public final y0(IZLjava/util/List;)V
    .locals 1

    .line 1
    const-string v0, "alternating"

    invoke-static {p3, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {v0, p2, p1, p3}, Ld4/j;->k(ZILjava/util/List;)V

    return-void
.end method

.method public final z0(ZII)V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Ld4/f;->C:Ld4/j;

    invoke-virtual {v0, p1, p2, p3}, Ld4/j;->o(ZII)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-direct {p0, p1}, Ld4/f;->S(Ljava/io/IOException;)V

    :goto_0
    return-void
.end method
