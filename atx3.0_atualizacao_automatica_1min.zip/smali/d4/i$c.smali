.class public final Ld4/i$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li4/y;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "c"
.end annotation


# instance fields
.field private final a:J

.field private b:Z

.field private final c:Li4/b;

.field private final d:Li4/b;

.field private f:Lv3/u;

.field private h:Z

.field final synthetic j:Ld4/i;


# direct methods
.method public constructor <init>(Ld4/i;JZ)V
    .locals 1

    .line 1
    const-string v0, "this$0"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/i$c;->j:Ld4/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p2, p0, Ld4/i$c;->a:J

    iput-boolean p4, p0, Ld4/i$c;->b:Z

    new-instance p1, Li4/b;

    invoke-direct {p1}, Li4/b;-><init>()V

    iput-object p1, p0, Ld4/i$c;->c:Li4/b;

    new-instance p1, Li4/b;

    invoke-direct {p1}, Li4/b;-><init>()V

    iput-object p1, p0, Ld4/i$c;->d:Li4/b;

    return-void
.end method

.method private final o(J)V
    .locals 2

    .line 1
    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    sget-boolean v1, Lw3/d;->h:Z

    if-eqz v1, :cond_1

    invoke-static {v0}, Ljava/lang/Thread;->holdsLock(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/AssertionError;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Thread "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " MUST NOT hold lock on "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :cond_1
    :goto_0
    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    invoke-virtual {v0}, Ld4/i;->g()Ld4/f;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Ld4/f;->w0(J)V

    return-void
.end method


# virtual methods
.method public G(Li4/b;J)J
    .locals 18

    .line 1
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-wide/from16 v2, p2

    const-string v4, "sink"

    invoke-static {v0, v4}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide/16 v6, 0x0

    cmp-long v8, v2, v6

    if-ltz v8, :cond_0

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    :goto_0
    if-eqz v8, :cond_a

    :goto_1
    iget-object v8, v1, Ld4/i$c;->j:Ld4/i;

    monitor-enter v8

    :try_start_0
    invoke-virtual {v8}, Ld4/i;->m()Ld4/i$d;

    move-result-object v9

    invoke-virtual {v9}, Li4/a;->t()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {v8}, Ld4/i;->h()Ld4/b;

    move-result-object v9

    if-eqz v9, :cond_1

    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->c()Z

    move-result v9

    if-nez v9, :cond_1

    invoke-virtual {v8}, Ld4/i;->i()Ljava/io/IOException;

    move-result-object v9

    if-nez v9, :cond_2

    new-instance v9, Ld4/n;

    invoke-virtual {v8}, Ld4/i;->h()Ld4/b;

    move-result-object v10

    invoke-static {v10}, Lg3/k;->b(Ljava/lang/Object;)V

    invoke-direct {v9, v10}, Ld4/n;-><init>(Ld4/b;)V

    goto :goto_2

    :cond_1
    const/4 v9, 0x0

    :cond_2
    :goto_2
    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->b()Z

    move-result v10

    if-nez v10, :cond_9

    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v10

    invoke-virtual {v10}, Li4/b;->T()J

    move-result-wide v10

    const-wide/16 v12, -0x1

    cmp-long v14, v10, v6

    if-lez v14, :cond_3

    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v10

    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v11

    invoke-virtual {v11}, Li4/b;->T()J

    move-result-wide v14

    invoke-static {v2, v3, v14, v15}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v14

    invoke-virtual {v10, v0, v14, v15}, Li4/b;->G(Li4/b;J)J

    move-result-wide v10

    invoke-virtual {v8}, Ld4/i;->l()J

    move-result-wide v14

    add-long/2addr v14, v10

    invoke-virtual {v8, v14, v15}, Ld4/i;->C(J)V

    invoke-virtual {v8}, Ld4/i;->l()J

    move-result-wide v14

    invoke-virtual {v8}, Ld4/i;->k()J

    move-result-wide v16

    sub-long v14, v14, v16

    if-nez v9, :cond_5

    invoke-virtual {v8}, Ld4/i;->g()Ld4/f;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ld4/f;->Y()Ld4/m;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ld4/m;->c()I

    move-result v16

    div-int/lit8 v4, v16, 0x2

    int-to-long v5, v4

    cmp-long v4, v14, v5

    if-ltz v4, :cond_5

    invoke-virtual {v8}, Ld4/i;->g()Ld4/f;

    move-result-object v4

    invoke-virtual {v8}, Ld4/i;->j()I

    move-result v5

    invoke-virtual {v4, v5, v14, v15}, Ld4/f;->C0(IJ)V

    invoke-virtual {v8}, Ld4/i;->l()J

    move-result-wide v4

    invoke-virtual {v8, v4, v5}, Ld4/i;->B(J)V

    goto :goto_3

    :cond_3
    invoke-virtual/range {p0 .. p0}, Ld4/i$c;->c()Z

    move-result v4

    if-nez v4, :cond_4

    if-nez v9, :cond_4

    invoke-virtual {v8}, Ld4/i;->F()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-wide v10, v12

    const/4 v4, 0x1

    goto :goto_4

    :cond_4
    move-wide v10, v12

    :cond_5
    :goto_3
    const/4 v4, 0x0

    :goto_4
    :try_start_2
    invoke-virtual {v8}, Ld4/i;->m()Ld4/i$d;

    move-result-object v5

    invoke-virtual {v5}, Ld4/i$d;->A()V

    sget-object v5, Lt2/r;->a:Lt2/r;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v8

    if-eqz v4, :cond_6

    const-wide/16 v6, 0x0

    goto/16 :goto_1

    :cond_6
    cmp-long v0, v10, v12

    if-eqz v0, :cond_7

    invoke-direct {v1, v10, v11}, Ld4/i$c;->o(J)V

    return-wide v10

    :cond_7
    if-nez v9, :cond_8

    return-wide v12

    :cond_8
    throw v9

    :cond_9
    :try_start_3
    new-instance v0, Ljava/io/IOException;

    const-string v2, "stream closed"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    move-exception v0

    :try_start_4
    invoke-virtual {v8}, Ld4/i;->m()Ld4/i$d;

    move-result-object v2

    invoke-virtual {v2}, Ld4/i$d;->A()V

    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception v0

    monitor-exit v8

    throw v0

    :cond_a
    const-string v0, "byteCount < 0: "

    invoke-static/range {p2 .. p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v0, v2}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method public final b()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld4/i$c;->h:Z

    return v0
.end method

.method public final c()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld4/i$c;->b:Z

    return v0
.end method

.method public close()V
    .locals 5

    .line 1
    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    monitor-enter v0

    const/4 v1, 0x1

    :try_start_0
    invoke-virtual {p0, v1}, Ld4/i$c;->j(Z)V

    invoke-virtual {p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v1

    invoke-virtual {v1}, Li4/b;->T()J

    move-result-wide v1

    invoke-virtual {p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v3

    invoke-virtual {v3}, Li4/b;->c()V

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    sget-object v3, Lt2/r;->a:Lt2/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    const-wide/16 v3, 0x0

    cmp-long v0, v1, v3

    if-lez v0, :cond_0

    invoke-direct {p0, v1, v2}, Ld4/i$c;->o(J)V

    :cond_0
    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    invoke-virtual {v0}, Ld4/i;->b()V

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public d()Li4/z;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    invoke-virtual {v0}, Ld4/i;->m()Ld4/i$d;

    move-result-object v0

    return-object v0
.end method

.method public final f()Li4/b;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/i$c;->d:Li4/b;

    return-object v0
.end method

.method public final g()Li4/b;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/i$c;->c:Li4/b;

    return-object v0
.end method

.method public final i(Li4/d;J)V
    .locals 11

    .line 1
    const-string v0, "source"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/i$c;->j:Ld4/i;

    sget-boolean v1, Lw3/d;->h:Z

    if-eqz v1, :cond_1

    invoke-static {v0}, Ljava/lang/Thread;->holdsLock(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/AssertionError;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Thread "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, " MUST NOT hold lock on "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :cond_1
    :goto_0
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-lez v2, :cond_9

    iget-object v2, p0, Ld4/i$c;->j:Ld4/i;

    monitor-enter v2

    :try_start_0
    invoke-virtual {p0}, Ld4/i$c;->c()Z

    move-result v3

    invoke-virtual {p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v4

    invoke-virtual {v4}, Li4/b;->T()J

    move-result-wide v4

    add-long/2addr v4, p2

    iget-wide v6, p0, Ld4/i$c;->a:J

    const/4 v8, 0x1

    const/4 v9, 0x0

    cmp-long v10, v4, v6

    if-lez v10, :cond_2

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    :goto_1
    sget-object v5, Lt2/r;->a:Lt2/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    monitor-exit v2

    if-eqz v4, :cond_3

    invoke-interface {p1, p2, p3}, Li4/d;->r(J)V

    iget-object p1, p0, Ld4/i$c;->j:Ld4/i;

    sget-object p2, Ld4/b;->h:Ld4/b;

    invoke-virtual {p1, p2}, Ld4/i;->f(Ld4/b;)V

    return-void

    :cond_3
    if-eqz v3, :cond_4

    invoke-interface {p1, p2, p3}, Li4/d;->r(J)V

    return-void

    :cond_4
    iget-object v2, p0, Ld4/i$c;->c:Li4/b;

    invoke-interface {p1, v2, p2, p3}, Li4/y;->G(Li4/b;J)J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long v6, v2, v4

    if-eqz v6, :cond_8

    sub-long/2addr p2, v2

    iget-object v2, p0, Ld4/i$c;->j:Ld4/i;

    monitor-enter v2

    :try_start_1
    invoke-virtual {p0}, Ld4/i$c;->b()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-virtual {p0}, Ld4/i$c;->g()Li4/b;

    move-result-object v3

    invoke-virtual {v3}, Li4/b;->T()J

    move-result-wide v3

    invoke-virtual {p0}, Ld4/i$c;->g()Li4/b;

    move-result-object v5

    invoke-virtual {v5}, Li4/b;->c()V

    goto :goto_3

    :cond_5
    invoke-virtual {p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v3

    invoke-virtual {v3}, Li4/b;->T()J

    move-result-wide v3

    cmp-long v5, v3, v0

    if-nez v5, :cond_6

    goto :goto_2

    :cond_6
    const/4 v8, 0x0

    :goto_2
    invoke-virtual {p0}, Ld4/i$c;->f()Li4/b;

    move-result-object v3

    invoke-virtual {p0}, Ld4/i$c;->g()Li4/b;

    move-result-object v4

    invoke-virtual {v3, v4}, Li4/b;->a0(Li4/y;)J

    if-eqz v8, :cond_7

    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_7
    move-wide v3, v0

    :goto_3
    monitor-exit v2

    cmp-long v2, v3, v0

    if-lez v2, :cond_1

    invoke-direct {p0, v3, v4}, Ld4/i$c;->o(J)V

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    monitor-exit v2

    throw p1

    :cond_8
    new-instance p1, Ljava/io/EOFException;

    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    throw p1

    :catchall_1
    move-exception p1

    monitor-exit v2

    throw p1

    :cond_9
    return-void
.end method

.method public final j(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Ld4/i$c;->h:Z

    return-void
.end method

.method public final k(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Ld4/i$c;->b:Z

    return-void
.end method

.method public final l(Lv3/u;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/i$c;->f:Lv3/u;

    return-void
.end method
