.class public final Ld4/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/c$a;
    }
.end annotation


# static fields
.field public static final d:Ld4/c$a;

.field public static final e:Li4/e;

.field public static final f:Li4/e;

.field public static final g:Li4/e;

.field public static final h:Li4/e;

.field public static final i:Li4/e;

.field public static final j:Li4/e;


# instance fields
.field public final a:Li4/e;

.field public final b:Li4/e;

.field public final c:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ld4/c$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/c$a;-><init>(Lg3/g;)V

    sput-object v0, Ld4/c;->d:Ld4/c$a;

    sget-object v0, Li4/e;->d:Li4/e$a;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v1

    sput-object v1, Ld4/c;->e:Li4/e;

    const-string v1, ":status"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v1

    sput-object v1, Ld4/c;->f:Li4/e;

    const-string v1, ":method"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v1

    sput-object v1, Ld4/c;->g:Li4/e;

    const-string v1, ":path"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v1

    sput-object v1, Ld4/c;->h:Li4/e;

    const-string v1, ":scheme"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v1

    sput-object v1, Ld4/c;->i:Li4/e;

    const-string v1, ":authority"

    invoke-virtual {v0, v1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object v0

    sput-object v0, Ld4/c;->j:Li4/e;

    return-void
.end method

.method public constructor <init>(Li4/e;Li4/e;)V
    .locals 1

    .line 1
    const-string v0, "name"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "value"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld4/c;->a:Li4/e;

    iput-object p2, p0, Ld4/c;->b:Li4/e;

    invoke-virtual {p1}, Li4/e;->q()I

    move-result p1

    add-int/lit8 p1, p1, 0x20

    invoke-virtual {p2}, Li4/e;->q()I

    move-result p2

    add-int/2addr p1, p2

    iput p1, p0, Ld4/c;->c:I

    return-void
.end method

.method public constructor <init>(Li4/e;Ljava/lang/String;)V
    .locals 1

    .line 2
    const-string v0, "name"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "value"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Li4/e;->d:Li4/e$a;

    invoke-virtual {v0, p2}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object p2

    invoke-direct {p0, p1, p2}, Ld4/c;-><init>(Li4/e;Li4/e;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 3
    const-string v0, "name"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "value"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Li4/e;->d:Li4/e$a;

    invoke-virtual {v0, p1}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object p1

    invoke-virtual {v0, p2}, Li4/e$a;->c(Ljava/lang/String;)Li4/e;

    move-result-object p2

    invoke-direct {p0, p1, p2}, Ld4/c;-><init>(Li4/e;Li4/e;)V

    return-void
.end method


# virtual methods
.method public final a()Li4/e;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/c;->a:Li4/e;

    return-object v0
.end method

.method public final b()Li4/e;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/c;->b:Li4/e;

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Ld4/c;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Ld4/c;

    iget-object v1, p0, Ld4/c;->a:Li4/e;

    iget-object v3, p1, Ld4/c;->a:Li4/e;

    invoke-static {v1, v3}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object v1, p0, Ld4/c;->b:Li4/e;

    iget-object p1, p1, Ld4/c;->b:Li4/e;

    invoke-static {v1, p1}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, Ld4/c;->a:Li4/e;

    invoke-virtual {v0}, Li4/e;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Ld4/c;->b:Li4/e;

    invoke-virtual {v1}, Li4/e;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ld4/c;->a:Li4/e;

    invoke-virtual {v1}, Li4/e;->t()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Ld4/c;->b:Li4/e;

    invoke-virtual {v1}, Li4/e;->t()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
