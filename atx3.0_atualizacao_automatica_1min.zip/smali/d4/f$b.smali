.class public final Ld4/f$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lg3/g;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ld4/f$b;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ld4/m;
    .locals 1

    .line 1
    invoke-static {}, Ld4/f;->g()Ld4/m;

    move-result-object v0

    return-object v0
.end method
