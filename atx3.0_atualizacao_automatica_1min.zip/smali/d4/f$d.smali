.class public final Ld4/f$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld4/h$c;
.implements Lf3/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "d"
.end annotation


# instance fields
.field private final a:Ld4/h;

.field final synthetic b:Ld4/f;


# direct methods
.method public constructor <init>(Ld4/f;Ld4/h;)V
    .locals 1

    .line 1
    const-string v0, "this$0"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "reader"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$d;->b:Ld4/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ld4/f$d;->a:Ld4/h;

    return-void
.end method


# virtual methods
.method public a(ZILi4/d;I)V
    .locals 2

    .line 1
    const-string v0, "source"

    invoke-static {p3, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p2}, Ld4/f;->n0(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p2, p3, p4, p1}, Ld4/f;->j0(ILi4/d;IZ)V

    return-void

    :cond_0
    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p2}, Ld4/f;->b0(I)Ld4/i;

    move-result-object v0

    if-nez v0, :cond_1

    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    sget-object v0, Ld4/b;->d:Ld4/b;

    invoke-virtual {p1, p2, v0}, Ld4/f;->B0(ILd4/b;)V

    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    int-to-long v0, p4

    invoke-virtual {p1, v0, v1}, Ld4/f;->w0(J)V

    invoke-interface {p3, v0, v1}, Li4/d;->r(J)V

    return-void

    :cond_1
    invoke-virtual {v0, p3, p4}, Ld4/i;->w(Li4/d;I)V

    if-eqz p1, :cond_2

    sget-object p1, Lw3/d;->b:Lv3/u;

    const/4 p2, 0x1

    invoke-virtual {v0, p1, p2}, Ld4/i;->x(Lv3/u;Z)V

    :cond_2
    return-void
.end method

.method public b(ZIILjava/util/List;)V
    .locals 6

    .line 1
    const-string p3, "headerBlock"

    invoke-static {p4, p3}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p3, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {p3, p2}, Ld4/f;->n0(I)Z

    move-result p3

    if-eqz p3, :cond_0

    iget-object p3, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {p3, p2, p4, p1}, Ld4/f;->k0(ILjava/util/List;Z)V

    return-void

    :cond_0
    iget-object p3, p0, Ld4/f$d;->b:Ld4/f;

    monitor-enter p3

    :try_start_0
    invoke-virtual {p3, p2}, Ld4/f;->b0(I)Ld4/i;

    move-result-object v0

    if-nez v0, :cond_4

    invoke-static {p3}, Ld4/f;->y(Ld4/f;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_1

    monitor-exit p3

    return-void

    :cond_1
    :try_start_1
    invoke-virtual {p3}, Ld4/f;->V()I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-gt p2, v0, :cond_2

    monitor-exit p3

    return-void

    :cond_2
    :try_start_2
    rem-int/lit8 v0, p2, 0x2

    invoke-virtual {p3}, Ld4/f;->X()I

    move-result v1

    rem-int/lit8 v1, v1, 0x2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-ne v0, v1, :cond_3

    monitor-exit p3

    return-void

    :cond_3
    :try_start_3
    invoke-static {p4}, Lw3/d;->O(Ljava/util/List;)Lv3/u;

    move-result-object v5

    new-instance p4, Ld4/i;

    const/4 v3, 0x0

    move-object v0, p4

    move v1, p2

    move-object v2, p3

    move v4, p1

    invoke-direct/range {v0 .. v5}, Ld4/i;-><init>(ILd4/f;ZZLv3/u;)V

    invoke-virtual {p3, p2}, Ld4/f;->q0(I)V

    invoke-virtual {p3}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object p1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p1, v0, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p3}, Ld4/f;->t(Ld4/f;)Lz3/e;

    move-result-object p1

    invoke-virtual {p1}, Lz3/e;->i()Lz3/d;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p3}, Ld4/f;->U()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "] onStream"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ld4/f$d$b;

    const/4 v1, 0x1

    invoke-direct {v0, p2, v1, p3, p4}, Ld4/f$d$b;-><init>(Ljava/lang/String;ZLd4/f;Ld4/i;)V

    const-wide/16 v1, 0x0

    invoke-virtual {p1, v0, v1, v2}, Lz3/d;->i(Lz3/a;J)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    monitor-exit p3

    return-void

    :cond_4
    :try_start_4
    sget-object p2, Lt2/r;->a:Lt2/r;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    monitor-exit p3

    invoke-static {p4}, Lw3/d;->O(Ljava/util/List;)Lv3/u;

    move-result-object p2

    invoke-virtual {v0, p2, p1}, Ld4/i;->x(Lv3/u;Z)V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p3

    throw p1
.end method

.method public bridge synthetic c()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Ld4/f$d;->p()V

    sget-object v0, Lt2/r;->a:Lt2/r;

    return-object v0
.end method

.method public d()V
    .locals 0

    .line 1
    return-void
.end method

.method public f(ILd4/b;)V
    .locals 1

    .line 1
    const-string v0, "errorCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p1}, Ld4/f;->n0(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p1, p2}, Ld4/f;->m0(ILd4/b;)V

    return-void

    :cond_0
    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p1}, Ld4/f;->o0(I)Ld4/i;

    move-result-object p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1, p2}, Ld4/i;->y(Ld4/b;)V

    :goto_0
    return-void
.end method

.method public g(ZLd4/m;)V
    .locals 9

    .line 1
    const-string v0, "settings"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-static {v0}, Ld4/f;->x(Ld4/f;)Lz3/d;

    move-result-object v0

    iget-object v1, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v1}, Ld4/f;->U()Ljava/lang/String;

    move-result-object v1

    const-string v2, " applyAndAckSettings"

    invoke-static {v1, v2}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-instance v1, Ld4/f$d$d;

    move-object v3, v1

    move-object v6, p0

    move v7, p1

    move-object v8, p2

    invoke-direct/range {v3 .. v8}, Ld4/f$d$d;-><init>(Ljava/lang/String;ZLd4/f$d;ZLd4/m;)V

    const-wide/16 p1, 0x0

    invoke-virtual {v0, v1, p1, p2}, Lz3/d;->i(Lz3/a;J)V

    return-void
.end method

.method public h(IJ)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    monitor-enter p1

    :try_start_0
    invoke-virtual {p1}, Ld4/f;->d0()J

    move-result-wide v0

    add-long/2addr v0, p2

    invoke-static {p1, v0, v1}, Ld4/f;->L(Ld4/f;J)V

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    sget-object p2, Lt2/r;->a:Lt2/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p2

    monitor-exit p1

    throw p2

    :cond_0
    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0, p1}, Ld4/f;->b0(I)Ld4/i;

    move-result-object p1

    if-eqz p1, :cond_1

    monitor-enter p1

    :try_start_1
    invoke-virtual {p1, p2, p3}, Ld4/i;->a(J)V

    sget-object p2, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    monitor-exit p1

    goto :goto_1

    :catchall_1
    move-exception p2

    monitor-exit p1

    throw p2

    :cond_1
    :goto_1
    return-void
.end method

.method public i(ILd4/b;Li4/e;)V
    .locals 3

    .line 1
    const-string v0, "errorCode"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "debugData"

    invoke-static {p3, p2}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p3}, Li4/e;->q()I

    iget-object p2, p0, Ld4/f$d;->b:Ld4/f;

    monitor-enter p2

    :try_start_0
    invoke-virtual {p2}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object p3

    invoke-interface {p3}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p3

    const/4 v0, 0x0

    new-array v1, v0, [Ld4/i;

    invoke-interface {p3, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p3

    if-eqz p3, :cond_2

    const/4 v1, 0x1

    invoke-static {p2, v1}, Ld4/f;->J(Ld4/f;Z)V

    sget-object v1, Lt2/r;->a:Lt2/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p2

    check-cast p3, [Ld4/i;

    array-length p2, p3

    :cond_0
    :goto_0
    if-ge v0, p2, :cond_1

    aget-object v1, p3, v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v1}, Ld4/i;->j()I

    move-result v2

    if-le v2, p1, :cond_0

    invoke-virtual {v1}, Ld4/i;->t()Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, Ld4/b;->m:Ld4/b;

    invoke-virtual {v1, v2}, Ld4/i;->y(Ld4/b;)V

    iget-object v2, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v1}, Ld4/i;->j()I

    move-result v1

    invoke-virtual {v2, v1}, Ld4/f;->o0(I)Ld4/i;

    goto :goto_0

    :cond_1
    return-void

    :cond_2
    :try_start_1
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p3, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    invoke-direct {p1, p3}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p2

    throw p1
.end method

.method public j(IILjava/util/List;)V
    .locals 0

    .line 1
    const-string p1, "requestHeaders"

    invoke-static {p3, p1}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {p1, p2, p3}, Ld4/f;->l0(ILjava/util/List;)V

    return-void
.end method

.method public k(ZII)V
    .locals 8

    .line 1
    if-eqz p1, :cond_3

    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    monitor-enter p1

    const/4 p3, 0x1

    const-wide/16 v0, 0x1

    if-eq p2, p3, :cond_2

    const/4 p3, 0x2

    if-eq p2, p3, :cond_1

    const/4 p3, 0x3

    if-eq p2, p3, :cond_0

    :goto_0
    :try_start_0
    sget-object p2, Lt2/r;->a:Lt2/r;

    goto :goto_1

    :cond_0
    invoke-static {p1}, Ld4/f;->c(Ld4/f;)J

    move-result-wide p2

    add-long/2addr p2, v0

    invoke-static {p1, p2, p3}, Ld4/f;->A(Ld4/f;J)V

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    goto :goto_0

    :cond_1
    invoke-static {p1}, Ld4/f;->i(Ld4/f;)J

    move-result-wide p2

    add-long/2addr p2, v0

    invoke-static {p1, p2, p3}, Ld4/f;->B(Ld4/f;J)V

    goto :goto_1

    :cond_2
    invoke-static {p1}, Ld4/f;->k(Ld4/f;)J

    move-result-wide p2

    add-long/2addr p2, v0

    invoke-static {p1, p2, p3}, Ld4/f;->E(Ld4/f;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_1
    monitor-exit p1

    goto :goto_2

    :catchall_0
    move-exception p2

    monitor-exit p1

    throw p2

    :cond_3
    iget-object p1, p0, Ld4/f$d;->b:Ld4/f;

    invoke-static {p1}, Ld4/f;->x(Ld4/f;)Lz3/d;

    move-result-object p1

    iget-object v0, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v0}, Ld4/f;->U()Ljava/lang/String;

    move-result-object v0

    const-string v1, " ping"

    invoke-static {v0, v1}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iget-object v5, p0, Ld4/f$d;->b:Ld4/f;

    const/4 v4, 0x1

    new-instance v0, Ld4/f$d$c;

    move-object v2, v0

    move v6, p2

    move v7, p3

    invoke-direct/range {v2 .. v7}, Ld4/f$d$c;-><init>(Ljava/lang/String;ZLd4/f;II)V

    const-wide/16 p2, 0x0

    invoke-virtual {p1, v0, p2, p3}, Lz3/d;->i(Lz3/a;J)V

    :goto_2
    return-void
.end method

.method public m(IIIZ)V
    .locals 0

    .line 1
    return-void
.end method

.method public final o(ZLd4/m;)V
    .locals 11

    .line 1
    const-string v0, "settings"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lg3/r;

    invoke-direct {v0}, Lg3/r;-><init>()V

    iget-object v1, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v1}, Ld4/f;->f0()Ld4/j;

    move-result-object v1

    iget-object v2, p0, Ld4/f$d;->b:Ld4/f;

    monitor-enter v1

    :try_start_0
    monitor-enter v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    invoke-virtual {v2}, Ld4/f;->Z()Ld4/m;

    move-result-object v3

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ld4/m;

    invoke-direct {p1}, Ld4/m;-><init>()V

    invoke-virtual {p1, v3}, Ld4/m;->g(Ld4/m;)V

    invoke-virtual {p1, p2}, Ld4/m;->g(Ld4/m;)V

    move-object p2, p1

    :goto_0
    iput-object p2, v0, Lg3/r;->a:Ljava/lang/Object;

    invoke-virtual {p2}, Ld4/m;->c()I

    move-result p1

    int-to-long p1, p1

    invoke-virtual {v3}, Ld4/m;->c()I

    move-result v3

    int-to-long v3, v3

    sub-long/2addr p1, v3

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    cmp-long v6, p1, v4

    if-eqz v6, :cond_3

    invoke-virtual {v2}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Map;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v2}, Ld4/f;->c0()Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v6

    new-array v7, v3, [Ld4/i;

    invoke-interface {v6, v7}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_2

    check-cast v6, [Ld4/i;

    goto :goto_2

    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    const-string p2, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    :goto_1
    const/4 v6, 0x0

    :goto_2
    iget-object v7, v0, Lg3/r;->a:Ljava/lang/Object;

    check-cast v7, Ld4/m;

    invoke-virtual {v2, v7}, Ld4/f;->s0(Ld4/m;)V

    invoke-static {v2}, Ld4/f;->o(Ld4/f;)Lz3/d;

    move-result-object v7

    invoke-virtual {v2}, Ld4/f;->U()Ljava/lang/String;

    move-result-object v8

    const-string v9, " onSettings"

    invoke-static {v8, v9}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ld4/f$d$a;

    const/4 v10, 0x1

    invoke-direct {v9, v8, v10, v2, v0}, Ld4/f$d$a;-><init>(Ljava/lang/String;ZLd4/f;Lg3/r;)V

    invoke-virtual {v7, v9, v4, v5}, Lz3/d;->i(Lz3/a;J)V

    sget-object v4, Lt2/r;->a:Lt2/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    invoke-virtual {v2}, Ld4/f;->f0()Ld4/j;

    move-result-object v4

    iget-object v0, v0, Lg3/r;->a:Ljava/lang/Object;

    check-cast v0, Ld4/m;

    invoke-virtual {v4, v0}, Ld4/j;->b(Ld4/m;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_3

    :catch_0
    move-exception v0

    :try_start_4
    invoke-static {v2, v0}, Ld4/f;->b(Ld4/f;Ljava/io/IOException;)V

    :goto_3
    sget-object v0, Lt2/r;->a:Lt2/r;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    monitor-exit v1

    if-eqz v6, :cond_4

    array-length v0, v6

    :goto_4
    if-ge v3, v0, :cond_4

    aget-object v1, v6, v3

    add-int/lit8 v3, v3, 0x1

    monitor-enter v1

    :try_start_5
    invoke-virtual {v1, p1, p2}, Ld4/i;->a(J)V

    sget-object v2, Lt2/r;->a:Lt2/r;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    monitor-exit v1

    goto :goto_4

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1

    :cond_4
    return-void

    :catchall_1
    move-exception p1

    :try_start_6
    monitor-exit v2

    throw p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    move-exception p1

    monitor-exit v1

    throw p1
.end method

.method public p()V
    .locals 5

    .line 1
    sget-object v0, Ld4/b;->f:Ld4/b;

    const/4 v1, 0x0

    :try_start_0
    iget-object v2, p0, Ld4/f$d;->a:Ld4/h;

    invoke-virtual {v2, p0}, Ld4/h;->f(Ld4/h$c;)V

    :goto_0
    iget-object v2, p0, Ld4/f$d;->a:Ld4/h;

    const/4 v3, 0x0

    invoke-virtual {v2, v3, p0}, Ld4/h;->c(ZLd4/h$c;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    sget-object v2, Ld4/b;->c:Ld4/b;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    sget-object v0, Ld4/b;->n:Ld4/b;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    iget-object v3, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v3, v2, v0, v1}, Ld4/f;->R(Ld4/b;Ld4/b;Ljava/io/IOException;)V

    goto :goto_2

    :catch_0
    move-exception v1

    goto :goto_1

    :catchall_0
    move-exception v3

    move-object v2, v0

    goto :goto_3

    :catch_1
    move-exception v1

    move-object v2, v0

    :goto_1
    :try_start_2
    sget-object v0, Ld4/b;->d:Ld4/b;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    iget-object v2, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v2, v0, v0, v1}, Ld4/f;->R(Ld4/b;Ld4/b;Ljava/io/IOException;)V

    :goto_2
    iget-object v0, p0, Ld4/f$d;->a:Ld4/h;

    invoke-static {v0}, Lw3/d;->l(Ljava/io/Closeable;)V

    return-void

    :catchall_1
    move-exception v3

    :goto_3
    iget-object v4, p0, Ld4/f$d;->b:Ld4/f;

    invoke-virtual {v4, v2, v0, v1}, Ld4/f;->R(Ld4/b;Ld4/b;Ljava/io/IOException;)V

    iget-object v0, p0, Ld4/f$d;->a:Ld4/h;

    invoke-static {v0}, Lw3/d;->l(Ljava/io/Closeable;)V

    throw v3
.end method
