.class public final Ld4/g$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lg3/g;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ld4/g$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lv3/a0;)Ljava/util/List;
    .locals 7

    .line 1
    const-string v0, "request"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lv3/a0;->e()Lv3/u;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-virtual {v0}, Lv3/u;->size()I

    move-result v2

    add-int/lit8 v2, v2, 0x4

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v2, Ld4/c;

    sget-object v3, Ld4/c;->g:Li4/e;

    invoke-virtual {p1}, Lv3/a0;->g()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Ld4/c;-><init>(Li4/e;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v2, Ld4/c;

    sget-object v3, Ld4/c;->h:Li4/e;

    sget-object v4, Lb4/i;->a:Lb4/i;

    invoke-virtual {p1}, Lv3/a0;->i()Lv3/v;

    move-result-object v5

    invoke-virtual {v4, v5}, Lb4/i;->c(Lv3/v;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Ld4/c;-><init>(Li4/e;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v2, "Host"

    invoke-virtual {p1, v2}, Lv3/a0;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    new-instance v3, Ld4/c;

    sget-object v4, Ld4/c;->j:Li4/e;

    invoke-direct {v3, v4, v2}, Ld4/c;-><init>(Li4/e;Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    new-instance v2, Ld4/c;

    sget-object v3, Ld4/c;->i:Li4/e;

    invoke-virtual {p1}, Lv3/a0;->i()Lv3/v;

    move-result-object p1

    invoke-virtual {p1}, Lv3/v;->p()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, v3, p1}, Ld4/c;-><init>(Li4/e;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lv3/u;->size()I

    move-result p1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, p1, :cond_3

    add-int/lit8 v3, v2, 0x1

    invoke-virtual {v0, v2}, Lv3/u;->b(I)Ljava/lang/String;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v6, "US"

    invoke-static {v5, v6}, Lg3/k;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "this as java.lang.String).toLowerCase(locale)"

    invoke-static {v4, v5}, Lg3/k;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ld4/g;->i()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    const-string v5, "te"

    invoke-static {v4, v5}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-virtual {v0, v2}, Lv3/u;->d(I)Ljava/lang/String;

    move-result-object v5

    const-string v6, "trailers"

    invoke-static {v5, v6}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_1
    new-instance v5, Ld4/c;

    invoke-virtual {v0, v2}, Lv3/u;->d(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v5, v4, v2}, Ld4/c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    move v2, v3

    goto :goto_0

    :cond_3
    return-object v1
.end method

.method public final b(Lv3/u;Lv3/z;)Lv3/c0$a;
    .locals 7

    .line 1
    const-string v0, "headerBlock"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "protocol"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lv3/u$a;

    invoke-direct {v0}, Lv3/u$a;-><init>()V

    invoke-virtual {p1}, Lv3/u;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_2

    add-int/lit8 v4, v3, 0x1

    invoke-virtual {p1, v3}, Lv3/u;->b(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v3}, Lv3/u;->d(I)Ljava/lang/String;

    move-result-object v3

    const-string v6, ":status"

    invoke-static {v5, v6}, Lg3/k;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    sget-object v2, Lb4/k;->d:Lb4/k$a;

    const-string v5, "HTTP/1.1 "

    invoke-static {v5, v3}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lb4/k$a;->a(Ljava/lang/String;)Lb4/k;

    move-result-object v2

    goto :goto_1

    :cond_0
    invoke-static {}, Ld4/g;->j()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    invoke-virtual {v0, v5, v3}, Lv3/u$a;->c(Ljava/lang/String;Ljava/lang/String;)Lv3/u$a;

    :cond_1
    :goto_1
    move v3, v4

    goto :goto_0

    :cond_2
    if-eqz v2, :cond_3

    new-instance p1, Lv3/c0$a;

    invoke-direct {p1}, Lv3/c0$a;-><init>()V

    invoke-virtual {p1, p2}, Lv3/c0$a;->q(Lv3/z;)Lv3/c0$a;

    move-result-object p1

    iget p2, v2, Lb4/k;->b:I

    invoke-virtual {p1, p2}, Lv3/c0$a;->g(I)Lv3/c0$a;

    move-result-object p1

    iget-object p2, v2, Lb4/k;->c:Ljava/lang/String;

    invoke-virtual {p1, p2}, Lv3/c0$a;->n(Ljava/lang/String;)Lv3/c0$a;

    move-result-object p1

    invoke-virtual {v0}, Lv3/u$a;->d()Lv3/u;

    move-result-object p2

    invoke-virtual {p1, p2}, Lv3/c0$a;->l(Lv3/u;)Lv3/c0$a;

    move-result-object p1

    return-object p1

    :cond_3
    new-instance p1, Ljava/net/ProtocolException;

    const-string p2, "Expected \':status\' header not present"

    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
