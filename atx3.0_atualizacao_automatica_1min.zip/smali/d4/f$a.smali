.class public final Ld4/f$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:Z

.field private final b:Lz3/e;

.field public c:Ljava/net/Socket;

.field public d:Ljava/lang/String;

.field public e:Li4/d;

.field public f:Li4/c;

.field private g:Ld4/f$c;

.field private h:Ld4/l;

.field private i:I


# direct methods
.method public constructor <init>(ZLz3/e;)V
    .locals 1

    .line 1
    const-string v0, "taskRunner"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Ld4/f$a;->a:Z

    iput-object p2, p0, Ld4/f$a;->b:Lz3/e;

    sget-object p1, Ld4/f$c;->b:Ld4/f$c;

    iput-object p1, p0, Ld4/f$a;->g:Ld4/f$c;

    sget-object p1, Ld4/l;->b:Ld4/l;

    iput-object p1, p0, Ld4/f$a;->h:Ld4/l;

    return-void
.end method


# virtual methods
.method public final a()Ld4/f;
    .locals 1

    .line 1
    new-instance v0, Ld4/f;

    invoke-direct {v0, p0}, Ld4/f;-><init>(Ld4/f$a;)V

    return-object v0
.end method

.method public final b()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld4/f$a;->a:Z

    return v0
.end method

.method public final c()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->d:Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "connectionName"

    invoke-static {v0}, Lg3/k;->o(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final d()Ld4/f$c;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->g:Ld4/f$c;

    return-object v0
.end method

.method public final e()I
    .locals 1

    .line 1
    iget v0, p0, Ld4/f$a;->i:I

    return v0
.end method

.method public final f()Ld4/l;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->h:Ld4/l;

    return-object v0
.end method

.method public final g()Li4/c;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->f:Li4/c;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "sink"

    invoke-static {v0}, Lg3/k;->o(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final h()Ljava/net/Socket;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->c:Ljava/net/Socket;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "socket"

    invoke-static {v0}, Lg3/k;->o(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final i()Li4/d;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->e:Li4/d;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "source"

    invoke-static {v0}, Lg3/k;->o(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final j()Lz3/e;
    .locals 1

    .line 1
    iget-object v0, p0, Ld4/f$a;->b:Lz3/e;

    return-object v0
.end method

.method public final k(Ld4/f$c;)Ld4/f$a;
    .locals 1

    .line 1
    const-string v0, "listener"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ld4/f$a;->n(Ld4/f$c;)V

    return-object p0
.end method

.method public final l(I)Ld4/f$a;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Ld4/f$a;->o(I)V

    return-object p0
.end method

.method public final m(Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$a;->d:Ljava/lang/String;

    return-void
.end method

.method public final n(Ld4/f$c;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$a;->g:Ld4/f$c;

    return-void
.end method

.method public final o(I)V
    .locals 0

    .line 1
    iput p1, p0, Ld4/f$a;->i:I

    return-void
.end method

.method public final p(Li4/c;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$a;->f:Li4/c;

    return-void
.end method

.method public final q(Ljava/net/Socket;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$a;->c:Ljava/net/Socket;

    return-void
.end method

.method public final r(Li4/d;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/f$a;->e:Li4/d;

    return-void
.end method

.method public final s(Ljava/net/Socket;Ljava/lang/String;Li4/d;Li4/c;)Ld4/f$a;
    .locals 1

    .line 1
    const-string v0, "socket"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "peerName"

    invoke-static {p2, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "source"

    invoke-static {p3, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sink"

    invoke-static {p4, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ld4/f$a;->q(Ljava/net/Socket;)V

    invoke-virtual {p0}, Ld4/f$a;->b()Z

    move-result p1

    if-eqz p1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v0, Lw3/d;->i:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x20

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const-string p1, "MockWebServer "

    invoke-static {p1, p2}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-virtual {p0, p1}, Ld4/f$a;->m(Ljava/lang/String;)V

    invoke-virtual {p0, p3}, Ld4/f$a;->r(Li4/d;)V

    invoke-virtual {p0, p4}, Ld4/f$a;->p(Li4/c;)V

    return-object p0
.end method
