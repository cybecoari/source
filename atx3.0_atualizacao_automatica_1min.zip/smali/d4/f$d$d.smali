.class public final Ld4/f$d$d;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f$d;->g(ZLd4/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Z

.field final synthetic g:Ld4/f$d;

.field final synthetic h:Z

.field final synthetic i:Ld4/m;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLd4/f$d;ZLd4/m;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$d$d;->e:Ljava/lang/String;

    iput-boolean p2, p0, Ld4/f$d$d;->f:Z

    iput-object p3, p0, Ld4/f$d$d;->g:Ld4/f$d;

    iput-boolean p4, p0, Ld4/f$d$d;->h:Z

    iput-object p5, p0, Ld4/f$d$d;->i:Ld4/m;

    invoke-direct {p0, p1, p2}, Lz3/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 3

    .line 1
    iget-object v0, p0, Ld4/f$d$d;->g:Ld4/f$d;

    iget-boolean v1, p0, Ld4/f$d$d;->h:Z

    iget-object v2, p0, Ld4/f$d$d;->i:Ld4/m;

    invoke-virtual {v0, v1, v2}, Ld4/f$d;->o(ZLd4/m;)V

    const-wide/16 v0, -0x1

    return-wide v0
.end method
