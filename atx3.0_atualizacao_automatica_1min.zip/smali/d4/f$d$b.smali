.class public final Ld4/f$d$b;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f$d;->b(ZIILjava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Z

.field final synthetic g:Ld4/f;

.field final synthetic h:Ld4/i;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLd4/f;Ld4/i;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$d$b;->e:Ljava/lang/String;

    iput-boolean p2, p0, Ld4/f$d$b;->f:Z

    iput-object p3, p0, Ld4/f$d$b;->g:Ld4/f;

    iput-object p4, p0, Ld4/f$d$b;->h:Ld4/i;

    invoke-direct {p0, p1, p2}, Lz3/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 4

    .line 1
    :try_start_0
    iget-object v0, p0, Ld4/f$d$b;->g:Ld4/f;

    invoke-virtual {v0}, Ld4/f;->W()Ld4/f$c;

    move-result-object v0

    iget-object v1, p0, Ld4/f$d$b;->h:Ld4/i;

    invoke-virtual {v0, v1}, Ld4/f$c;->b(Ld4/i;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    sget-object v1, Le4/m;->a:Le4/m$a;

    invoke-virtual {v1}, Le4/m$a;->g()Le4/m;

    move-result-object v1

    iget-object v2, p0, Ld4/f$d$b;->g:Ld4/f;

    invoke-virtual {v2}, Ld4/f;->U()Ljava/lang/String;

    move-result-object v2

    const-string v3, "Http2Connection.Listener failure for "

    invoke-static {v3, v2}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x4

    invoke-virtual {v1, v2, v3, v0}, Le4/m;->j(Ljava/lang/String;ILjava/lang/Throwable;)V

    :try_start_1
    iget-object v1, p0, Ld4/f$d$b;->h:Ld4/i;

    sget-object v2, Ld4/b;->d:Ld4/b;

    invoke-virtual {v1, v2, v0}, Ld4/i;->d(Ld4/b;Ljava/io/IOException;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_0
    const-wide/16 v0, -0x1

    return-wide v0
.end method
