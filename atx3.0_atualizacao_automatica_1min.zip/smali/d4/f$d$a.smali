.class public final Ld4/f$d$a;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f$d;->o(ZLd4/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Z

.field final synthetic g:Ld4/f;

.field final synthetic h:Lg3/r;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLd4/f;Lg3/r;)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$d$a;->e:Ljava/lang/String;

    iput-boolean p2, p0, Ld4/f$d$a;->f:Z

    iput-object p3, p0, Ld4/f$d$a;->g:Ld4/f;

    iput-object p4, p0, Ld4/f$d$a;->h:Lg3/r;

    invoke-direct {p0, p1, p2}, Lz3/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 3

    .line 1
    iget-object v0, p0, Ld4/f$d$a;->g:Ld4/f;

    invoke-virtual {v0}, Ld4/f;->W()Ld4/f$c;

    move-result-object v0

    iget-object v1, p0, Ld4/f$d$a;->g:Ld4/f;

    iget-object v2, p0, Ld4/f$d$a;->h:Lg3/r;

    iget-object v2, v2, Lg3/r;->a:Ljava/lang/Object;

    check-cast v2, Ld4/m;

    invoke-virtual {v0, v1, v2}, Ld4/f$c;->a(Ld4/f;Ld4/m;)V

    const-wide/16 v0, -0x1

    return-wide v0
.end method
