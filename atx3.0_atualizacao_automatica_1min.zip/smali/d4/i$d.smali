.class public final Ld4/i$d;
.super Li4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "d"
.end annotation


# instance fields
.field final synthetic m:Ld4/i;


# direct methods
.method public constructor <init>(Ld4/i;)V
    .locals 1

    .line 1
    const-string v0, "this$0"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Ld4/i$d;->m:Ld4/i;

    invoke-direct {p0}, Li4/a;-><init>()V

    return-void
.end method


# virtual methods
.method public final A()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Li4/a;->u()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ld4/i$d;->v(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object v0

    throw v0
.end method

.method protected v(Ljava/io/IOException;)Ljava/io/IOException;
    .locals 2

    .line 1
    new-instance v0, Ljava/net/SocketTimeoutException;

    const-string v1, "timeout"

    invoke-direct {v0, v1}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    if-eqz p1, :cond_0

    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    :cond_0
    return-object v0
.end method

.method protected z()V
    .locals 2

    .line 1
    iget-object v0, p0, Ld4/i$d;->m:Ld4/i;

    sget-object v1, Ld4/b;->n:Ld4/b;

    invoke-virtual {v0, v1}, Ld4/i;->f(Ld4/b;)V

    iget-object v0, p0, Ld4/i$d;->m:Ld4/i;

    invoke-virtual {v0}, Ld4/i;->g()Ld4/f;

    move-result-object v0

    invoke-virtual {v0}, Ld4/f;->p0()V

    return-void
.end method
