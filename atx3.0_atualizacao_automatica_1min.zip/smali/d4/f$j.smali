.class public final Ld4/f$j;
.super Lz3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld4/f;-><init>(Ld4/f$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Ld4/f;

.field final synthetic g:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ld4/f;J)V
    .locals 0

    .line 1
    iput-object p1, p0, Ld4/f$j;->e:Ljava/lang/String;

    iput-object p2, p0, Ld4/f$j;->f:Ld4/f;

    iput-wide p3, p0, Ld4/f$j;->g:J

    const/4 p2, 0x2

    const/4 p3, 0x0

    const/4 p4, 0x0

    invoke-direct {p0, p1, p4, p2, p3}, Lz3/a;-><init>(Ljava/lang/String;ZILg3/g;)V

    return-void
.end method


# virtual methods
.method public f()J
    .locals 9

    .line 1
    iget-object v0, p0, Ld4/f$j;->f:Ld4/f;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Ld4/f$j;->f:Ld4/f;

    invoke-static {v1}, Ld4/f;->k(Ld4/f;)J

    move-result-wide v1

    iget-object v3, p0, Ld4/f$j;->f:Ld4/f;

    invoke-static {v3}, Ld4/f;->j(Ld4/f;)J

    move-result-wide v3

    const/4 v5, 0x1

    const/4 v6, 0x0

    cmp-long v7, v1, v3

    if-gez v7, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Ld4/f$j;->f:Ld4/f;

    invoke-static {v1}, Ld4/f;->j(Ld4/f;)J

    move-result-wide v1

    iget-object v3, p0, Ld4/f$j;->f:Ld4/f;

    const-wide/16 v7, 0x1

    add-long/2addr v1, v7

    invoke-static {v3, v1, v2}, Ld4/f;->C(Ld4/f;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    :goto_0
    monitor-exit v0

    iget-object v0, p0, Ld4/f$j;->f:Ld4/f;

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ld4/f;->b(Ld4/f;Ljava/io/IOException;)V

    const-wide/16 v0, -0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v0, v6, v5, v6}, Ld4/f;->z0(ZII)V

    iget-wide v0, p0, Ld4/f$j;->g:J

    :goto_1
    return-wide v0

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method
