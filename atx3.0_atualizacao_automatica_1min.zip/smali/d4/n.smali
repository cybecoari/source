.class public final Ld4/n;
.super Ljava/io/IOException;
.source "SourceFile"


# instance fields
.field public final a:Ld4/b;


# direct methods
.method public constructor <init>(Ld4/b;)V
    .locals 1

    .line 1
    const-string v0, "errorCode"

    invoke-static {p1, v0}, Lg3/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "stream was reset: "

    invoke-static {v0, p1}, Lg3/k;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Ld4/n;->a:Ld4/b;

    return-void
.end method
