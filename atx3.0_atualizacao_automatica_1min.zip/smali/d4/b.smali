.class public final enum Ld4/b;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld4/b$a;
    }
.end annotation


# static fields
.field public static final b:Ld4/b$a;

.field public static final enum c:Ld4/b;

.field public static final enum d:Ld4/b;

.field public static final enum f:Ld4/b;

.field public static final enum h:Ld4/b;

.field public static final enum j:Ld4/b;

.field public static final enum k:Ld4/b;

.field public static final enum l:Ld4/b;

.field public static final enum m:Ld4/b;

.field public static final enum n:Ld4/b;

.field public static final enum o:Ld4/b;

.field public static final enum p:Ld4/b;

.field public static final enum q:Ld4/b;

.field public static final enum r:Ld4/b;

.field public static final enum s:Ld4/b;

.field private static final synthetic t:[Ld4/b;


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ld4/b;

    const-string v1, "NO_ERROR"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->c:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "PROTOCOL_ERROR"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->d:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "INTERNAL_ERROR"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->f:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "FLOW_CONTROL_ERROR"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->h:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "SETTINGS_TIMEOUT"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->j:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "STREAM_CLOSED"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->k:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "FRAME_SIZE_ERROR"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->l:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "REFUSED_STREAM"

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->m:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "CANCEL"

    const/16 v2, 0x8

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->n:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "COMPRESSION_ERROR"

    const/16 v2, 0x9

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->o:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "CONNECT_ERROR"

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->p:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "ENHANCE_YOUR_CALM"

    const/16 v2, 0xb

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->q:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "INADEQUATE_SECURITY"

    const/16 v2, 0xc

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->r:Ld4/b;

    new-instance v0, Ld4/b;

    const-string v1, "HTTP_1_1_REQUIRED"

    const/16 v2, 0xd

    invoke-direct {v0, v1, v2, v2}, Ld4/b;-><init>(Ljava/lang/String;II)V

    sput-object v0, Ld4/b;->s:Ld4/b;

    invoke-static {}, Ld4/b;->a()[Ld4/b;

    move-result-object v0

    sput-object v0, Ld4/b;->t:[Ld4/b;

    new-instance v0, Ld4/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ld4/b$a;-><init>(Lg3/g;)V

    sput-object v0, Ld4/b;->b:Ld4/b$a;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Ld4/b;->a:I

    return-void
.end method

.method private static final synthetic a()[Ld4/b;
    .locals 3

    .line 1
    const/16 v0, 0xe

    new-array v0, v0, [Ld4/b;

    const/4 v1, 0x0

    sget-object v2, Ld4/b;->c:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x1

    sget-object v2, Ld4/b;->d:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x2

    sget-object v2, Ld4/b;->f:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x3

    sget-object v2, Ld4/b;->h:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    sget-object v2, Ld4/b;->j:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x5

    sget-object v2, Ld4/b;->k:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    sget-object v2, Ld4/b;->l:Ld4/b;

    aput-object v2, v0, v1

    const/4 v1, 0x7

    sget-object v2, Ld4/b;->m:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0x8

    sget-object v2, Ld4/b;->n:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0x9

    sget-object v2, Ld4/b;->o:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0xa

    sget-object v2, Ld4/b;->p:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0xb

    sget-object v2, Ld4/b;->q:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0xc

    sget-object v2, Ld4/b;->r:Ld4/b;

    aput-object v2, v0, v1

    const/16 v1, 0xd

    sget-object v2, Ld4/b;->s:Ld4/b;

    aput-object v2, v0, v1

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Ld4/b;
    .locals 1

    .line 1
    const-class v0, Ld4/b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Ld4/b;

    return-object p0
.end method

.method public static values()[Ld4/b;
    .locals 1

    .line 1
    sget-object v0, Ld4/b;->t:[Ld4/b;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ld4/b;

    return-object v0
.end method


# virtual methods
.method public final b()I
    .locals 1

    .line 1
    iget v0, p0, Ld4/b;->a:I

    return v0
.end method
